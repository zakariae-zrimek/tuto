export interface stepperModel {
  value: number;
  label: string;
  disabled?: boolean;
}
