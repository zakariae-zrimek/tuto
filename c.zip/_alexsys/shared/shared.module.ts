import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { InputComponent } from "./components/input/input.component";
import { SelectComponent } from "./components/select/select.component";
import { MultiSelectComponent } from "./components/multi-select/multi-select.component";
import { TreeSelectComponent } from "./components/tree-select/tree-select.component";
import { CheckboxComponent } from "./components/checkox/checkbox.component";
import { RadioComponent } from "./components/radio/radio.component";
import { ButtonComponent } from "./components/button/button.component";
import { InputPasswordComponent } from "./components/input-password/input-password.component";
import { InputMaskComponent } from "./components/input-mask/input-mask.component";
import { CardComponent } from "./partials/card/card.component";
import { StepperComponent } from "./partials/stepper/stepper.component";
import { AccordionComponent } from "./partials/accordion/accordion.component";

import { FieldErrorComponent } from "./partials/field-error/field-error.component";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { PasswordModule } from "primeng/password";
import { DividerModule } from "primeng/divider";
import { SplashScreenComponent } from "./partials/splash-screen/splash-screen.component";
import { ChangeLanguageComponent } from "./partials/change-language/change-language.component";
import { SelectModule } from "primeng/select";
import { SwitchButtonComponent } from "./components/switch-button/switch-button.component";
import { ToggleSwitchModule } from "primeng/toggleswitch";
import { ButtonModule } from "primeng/button";
import { IconFieldModule } from "primeng/iconfield";
import { InputIconModule } from "primeng/inputicon";
import { InputIconComponent } from "./components/input-icon/input-icon.component";
import { CalendarComponent } from "./components/calendar/calendar.component";
import { DatePickerModule } from "primeng/datepicker";
import { CalendarTimeComponent } from "./components/calendar-time/calendar-time.component";
import { CalendarRangeComponent } from "./components/calendar-range/calendar-range.component";
import { RadioButtonModule } from "primeng/radiobutton";
import { ButtonIconOnlyComponent } from "./components/button-icon-only/button-icon-only.component";
import { MenuModule } from "primeng/menu";
import { DrawerModule } from "primeng/drawer";
import { BadgeModule } from "primeng/badge";
import { AvatarModule } from "primeng/avatar";
import { AccordionModule } from "primeng/accordion";
import { InputTextModule } from "primeng/inputtext";
import { StepperModule } from "primeng/stepper";
import { AlexsysStepTplDirective } from "./directives/alexsys-step-tpl.directive";
import { HasPermissionDirective } from "./directives/has-permission.directive";
import { ConfirmDialogComponent } from "./partials/confirm-dialog/confirm-dialog.component";
import { ConfirmDialogModule } from "primeng/confirmdialog";
import { CardModule } from "primeng/card";
import { TableWrapperComponent } from "./partials/table/table-wrapper/table-wrapper.component";
import { TableHeaderComponent } from "./partials/table/table-header/table-header.component";
import { TableBodyComponent } from "./partials/table/table-body/table-body.component";
import { TableFooterComponent } from "./partials/table/table-footer/table-footer.component";
import { TableRowComponent } from "./partials/table/table-row/table-row.component";
import { TableHeadComponent } from "./partials/table/table-head/table-head.component";
import { TableCellComponent } from "./partials/table/table-cell/table-cell.component";
import { TableCaptionComponent } from "./partials/table/table-caption/table-caption.component";
import { MultiSelectModule } from "primeng/multiselect";
import { TreeSelectModule } from "primeng/treeselect";
import { CheckboxModule } from "primeng/checkbox";
import { InputMaskModule } from "primeng/inputmask";
import { DataTableComponent } from "./partials/dataTable/data-table.component";
import { ThreeDotMenuComponent } from "./components/three-dot-menu/three-dot-menu.component";
import { StatusBadgeComponent } from "./components/status-badge/status-badge.component";
import { CompoundTableComponent } from "./partials/compound-table/compound-table.component";
import { DialogWrapperComponent } from "./components/dialog-wrapper/dialog-wrapper.component";
import { DialogModule } from "primeng/dialog";
import { TabsComponent } from "./components/tabs/tabs.component";
// import { TabViewModule } from "primeng/tabview";
import { Tab } from "primeng/tabs";
import { TabsModule } from "primeng/tabs";
import { SectionHeaderComponent } from "./partials/section-header/section-header.component";
import { FilterPanelComponent } from "./partials/filter-panel/filter-panel.component";
import { PaginationComponent } from "./partials/pagination/pagination.component";
import { ListTableComponent } from "./partials/list-table/list-table.component";
import { OverlayPanelModule } from "primeng/overlaypanel";
import { DatepickerComponent } from "./components/datepicker/datepicker.component";
import { SwitchControlComponent } from "./components/switch-control/switch-control.component";
import { FileInputComponent } from "./components/file-input/file-input.component";
import { InputSwitchModule } from "primeng/inputswitch";
import { TooltipModule } from "primeng/tooltip";
import { ColumnVisibilityDialogComponent } from "./partials/column-visibility-dialog/column-visibility-dialog.component";
import { ActionRendererComponent } from "./partials/expandable-table/action-renderer/action-renderer.component";
import { ExpandableTableComponent } from "./partials/expandable-table/expandable-table.component";
import { ExpandableCardsComponent } from "./partials/expandable-cards/expandable-cards.component";
import { ConfirmSelectionModalComponent } from "./partials/confirm-selection-modal/confirm-selection-modal.component";
import { TableLoadingStateComponent } from "./partials/table-loading-state/table-loading-state.component";
import { FileViewerComponent } from "./partials/file-viewer/file-viewer.component";
import { FilterDrawerComponent } from "./partials/filter-drawer/filter-drawer.component";
import { DocViewerModalComponent } from "./components/doc-viewer-modal/doc-viewer-modal.component";
import { DocumentCountBadgeComponent } from "./components/document-count-badge/document-count-badge.component";
import { DocumentsModalComponent } from "./partials/documents-modal/documents-modal.component";
import { EngagementsModalComponent } from "../../pages/traitement-actes/engagements-modal/engagements-modal.component";
import { NotePaiementModalComponent } from "../../pages/traitement-actes/note-paiement-modal/note-paiement-modal.component";
@NgModule({
  declarations: [
    InputComponent,
    SelectComponent,
    MultiSelectComponent,
    TreeSelectComponent,
    CheckboxComponent,
    RadioComponent,
    ButtonComponent,
    InputPasswordComponent,
    InputMaskComponent,
    CardComponent,
    StepperComponent,
    AccordionComponent,
    FieldErrorComponent,
    SplashScreenComponent,
    ChangeLanguageComponent,
    SwitchButtonComponent,
    InputIconComponent,
    CalendarComponent,
    CalendarTimeComponent,
    CalendarRangeComponent,
    ButtonIconOnlyComponent,
    AlexsysStepTplDirective,
    HasPermissionDirective,
    ConfirmDialogComponent,
    TableWrapperComponent,
    TableHeaderComponent,
    TableBodyComponent,
    TableFooterComponent,
    TableRowComponent,
    TableHeadComponent,
    TableCellComponent,
    TableCaptionComponent,
    DataTableComponent,
    ThreeDotMenuComponent,
    CompoundTableComponent,
    StatusBadgeComponent,
    DialogWrapperComponent,
    TabsComponent,
    SectionHeaderComponent,
    FilterPanelComponent,
    PaginationComponent,
    ListTableComponent,
    DatepickerComponent,
    FieldErrorComponent,
    SwitchControlComponent,
    FileInputComponent,
    ColumnVisibilityDialogComponent,
    ActionRendererComponent,
    ExpandableTableComponent,
    ExpandableCardsComponent,
    ConfirmSelectionModalComponent,
    TableLoadingStateComponent,
    FilterDrawerComponent,
    DocViewerModalComponent,
    EngagementsModalComponent,
    NotePaiementModalComponent,
    FileViewerComponent,
    DocumentCountBadgeComponent,
    DocumentsModalComponent,
  ],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    FormsModule,
    PasswordModule,
    DividerModule,
    SelectModule,
    ToggleSwitchModule,
    ButtonModule,
    IconFieldModule,
    InputIconModule,
    DatePickerModule,
    RadioButtonModule,
    DrawerModule,
    MenuModule,
    BadgeModule,
    AvatarModule,
    AccordionModule,
    InputTextModule,
    StepperModule,
    ConfirmDialogModule,
    CardModule,
    MultiSelectModule,
    TreeSelectModule,
    CheckboxModule,
    InputMaskModule,
    MenuModule,
    DialogModule,
    // TabViewModule,
    Tab,
    TabsModule,
    OverlayPanelModule,
    InputSwitchModule,
    TooltipModule,
  ],
  exports: [
    ReactiveFormsModule,
    MenuModule,
    BadgeModule,
    AvatarModule,
    DrawerModule,
    InputComponent,
    InputPasswordComponent,
    SplashScreenComponent,
    ChangeLanguageComponent,
    SelectComponent,
    SwitchButtonComponent,
    ButtonComponent,
    InputIconComponent,
    CalendarComponent,
    CalendarTimeComponent,
    RadioComponent,
    ButtonIconOnlyComponent,
    AccordionComponent,
    StepperComponent,
    AlexsysStepTplDirective,
    HasPermissionDirective,
    ConfirmDialogComponent,
    CardComponent,
    MultiSelectComponent,
    TreeSelectComponent,
    CheckboxComponent,
    CalendarRangeComponent,
    InputMaskComponent,
    DataTableComponent,
    ThreeDotMenuComponent,
    CompoundTableComponent,
    StatusBadgeComponent,
    DialogWrapperComponent,
    TabsComponent,
    SectionHeaderComponent,
    FilterPanelComponent,
    PaginationComponent,
    ListTableComponent,
    DatepickerComponent,
    FieldErrorComponent,
    SwitchControlComponent,
    FileInputComponent,
    ColumnVisibilityDialogComponent,
    ActionRendererComponent,
    ExpandableTableComponent,
    ExpandableCardsComponent,
    ConfirmSelectionModalComponent,
    TableLoadingStateComponent,
    FileViewerComponent,
    DocumentCountBadgeComponent,
    FilterDrawerComponent,
    DocViewerModalComponent,
    DocumentsModalComponent,
    EngagementsModalComponent,
    NotePaiementModalComponent,
    ConfirmDialogModule,
  ],
})
export class SharedModule {}
