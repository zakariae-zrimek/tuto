import { Component, Input } from "@angular/core";
import { FormControl } from "@angular/forms";

@Component({
  selector: "alexsys-input-mask",
  standalone: false,
  templateUrl: "./input-mask.component.html",
  styleUrl: "./input-mask.component.scss",
})
export class InputMaskComponent {
  /** Label displayed above the input */
  @Input() label = '';

  /** Unique ID for input association with label */
  @Input() inputId: string = "input-mask-" + Math.random().toString(36).substring(2);

  /** Control from parent form */
  @Input() control!: FormControl;

  /** PrimeNG mask format (e.g. '99/99/9999' for dates, '(999) 999-9999' for phone, etc.) */
  @Input() mask = "";

  /** Placeholder text */
  @Input() placeholder = "";

  /** Whether field is required (adds * to label) */
  @Input() required = false;

  /** Whether input is disabled */
  @Input() disabled = false;

  /** Show validation icons */
  @Input() showValidationIcon = true;

  ngOnInit(): void {
    if (!this.control) {
      console.warn('⚠️ AlexsysInputMaskComponent: "control" input is required.');
    }
  }
}
