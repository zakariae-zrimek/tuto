import { Component, EventEmitter, Input, Output } from '@angular/core';

@Component({
  selector: "alexsys-calendar-range",
  standalone: false,
  templateUrl: "./calendar-range.component.html",
  styleUrl: "./calendar-range.component.scss",
})
export class CalendarRangeComponent {
  @Input() label = "Select Date Range";
  @Input() placeholder = "Choose range";
  @Input() showIcon = true;

  // Holds the selected range [startDate, endDate]
  @Input() value: Date[] = [];

  @Output() valueChange = new EventEmitter<Date[]>();

  onSelectRange(range: Date[]) {
    this.value = range;
    this.valueChange.emit(this.value);
  }
}
