import { Component, Input } from "@angular/core";

@Component({
  selector: "alexsys-status-badge",
  standalone: false,
  template: `
    <span
      class="inline-flex items-center rounded-md px-2 py-0.5 text-xs font-medium"
      [ngClass]="resolvedClass"
    >
      {{ label }}
    </span>
  `,
})
export class StatusBadgeComponent {
  @Input() value!: any;

  @Input() className?: string;

  @Input() getClassFn!: (val: any) => string;
  @Input() labelFn?: (val: any) => string;

  get resolvedClass(): string {
    if (this.className) return this.className;
    if (this.getClassFn) return this.getClassFn(this.value);
    return "bg-gray-100 text-gray-800";
  }

  get label(): string {
    return this.labelFn ? this.labelFn(this.value) : String(this.value ?? "");
  }
}
