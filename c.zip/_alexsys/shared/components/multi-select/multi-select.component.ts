import { Component, Input } from "@angular/core";
import { FormControl } from "@angular/forms";

@Component({
  selector: "alexsys-multi-select",
  standalone: false,
  templateUrl: "./multi-select.component.html",
  styleUrl: "./multi-select.component.scss",
})
export class MultiSelectComponent<
  TOption extends Record<string, any> = any,
  TValue = any
> {
  // Selected values (ex: string[])
  @Input() control = new FormControl<TValue[]>([], { nonNullable: true });

  // Options list (ex: {label,value}[])
  @Input() items: TOption[] = [];

  @Input() label = "";
  @Input() inputId = "";
  @Input() placeholder = "";
  @Input() filter = false;
  @Input() loading = false;

  // Keys on the option object
  @Input() optionLabel!: Extract<keyof TOption, string>;
  @Input() optionValue!: Extract<keyof TOption, string>;

  @Input() required = false;
  @Input() showValidationIcon = false;
  @Input() disabled = false;

  // PrimeNG MultiSelect-specific
  @Input() showClear = true;
  @Input() display: "comma" | "chip" = "comma";
  @Input() maxSelectedLabels = 3;
}
