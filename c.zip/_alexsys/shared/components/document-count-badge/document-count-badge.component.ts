import { Component, EventEmitter, Input, Output } from "@angular/core";

@Component({
  selector: "alexsys-document-count-badge",
  standalone: false,
  template: `
    <button
      type="button"
      class="inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-xs font-medium transition-all focus:outline-none"
      [ngClass]="count > 0 ? activeClass : emptyClass"
      [title]="count > 0 ? count + ' document(s) — cliquez pour voir' : 'Aucun document'"
      [disabled]="count === 0"
      (click)="count > 0 ? clicked.emit() : null"
    >
      <i class="pi pi-file" style="font-size: 11px;"></i>
      <span>{{ count }}</span>
    </button>
  `,
})
export class DocumentCountBadgeComponent {
  @Input() count = 0;
  @Output() clicked = new EventEmitter<void>();

  readonly activeClass =
    "border-blue-200 bg-blue-50 text-blue-700 shadow-sm cursor-pointer hover:border-blue-400 hover:bg-blue-100 hover:shadow-md";

  readonly emptyClass =
    "border-gray-200 bg-gray-50 text-gray-400 cursor-default opacity-60";
}
