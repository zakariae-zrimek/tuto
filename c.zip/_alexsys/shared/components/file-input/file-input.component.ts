import { Component, Input, ViewChild, ElementRef } from "@angular/core";
import { FormControl } from "@angular/forms";

@Component({
  selector: "alexsys-file-input",
  standalone: false,
  templateUrl: "./file-input.component.html",
  styleUrl: "./file-input.component.scss",
})
export class FileInputComponent {
  @Input() control: FormControl<File | null> = new FormControl<File | null>(null);
  @Input() label = "";
  @Input() inputId = "";
  @Input() required = false;
  @Input() disabled = false;
  @Input() accept = ".pdf,.doc,.docx";
  @Input() buttonLabel = "Choisir un fichier";
  @Input() helper = "PDF, DOC, DOCX";

  @ViewChild("fileInput") fileInput!: ElementRef<HTMLInputElement>;

  openPicker() {
    if (this.disabled) return;
    this.fileInput.nativeElement.click();
  }

  onNativeChange(ev: Event) {
    const input = ev.target as HTMLInputElement;
    const f = input.files?.[0] ?? null;
    input.value = ""; // allow re-select same file
    this.control.setValue(f);
    this.control.markAsDirty();
    this.control.markAsTouched();
  }

  get fileName(): string {
    return this.control.value?.name || "Aucun fichier sélectionné";
  }
}
