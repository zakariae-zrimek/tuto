import { Component, Input, Output, EventEmitter, TemplateRef } from "@angular/core";

@Component({
  selector: "alexsys-dialog-wrapper",
  standalone: false,
  templateUrl: "./dialog-wrapper.component.html",
  styleUrl: "./dialog-wrapper.component.scss",
})
export class DialogWrapperComponent {
  @Input() visible = false;
  @Input() headerTemplate?: TemplateRef<any>;
  @Input() footerTemplate?: TemplateRef<any>;
  @Input() modal = true;
  @Input() resizable = false;
  @Input() draggable = true;
  @Input() width = "auto";
  @Input() minWidth = "360px";
  @Input() maxWidth = "92vw";
  @Input() closable = true;
  @Input() contentStyle: Record<string, string> = {};

  get dialogStyle(): Record<string, string> {
    return { width: this.width, minWidth: this.minWidth, maxWidth: this.maxWidth };
  }

  /** Built-in header — used when no headerTemplate is provided */
  @Input() title?: string;
  @Input() subtitle?: string;
  /** PrimeIcons class e.g. "pi-paperclip" */
  @Input() icon?: string;
  /** Accent colour for the icon badge: "indigo" | "blue" | "emerald" | "amber" | "rose" */
  @Input() iconColor: "indigo" | "blue" | "emerald" | "amber" | "rose" = "indigo";

  @Output() visibleChange = new EventEmitter<boolean>();

  hide() {
    this.visible = false;
    this.visibleChange.emit(false);
  }

  get hasBuiltInHeader(): boolean {
    return !this.headerTemplate && !!this.title;
  }
}
