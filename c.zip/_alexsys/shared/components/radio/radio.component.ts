import { Component, Input } from "@angular/core";
import { FormControl } from "@angular/forms";

interface RadioType {
  label: string;
  name: string; // should be a safe id
  value: string;
  icon?: string;
}

@Component({
  selector: "alexsys-radio",
  standalone: false,
  templateUrl: "./radio.component.html",
  styleUrl: "./radio.component.scss",
})
export class RadioComponent {
  @Input() label = "";
  @Input() control = new FormControl<any>("");
  @Input() items: RadioType[] = [];

  // NEW
  @Input() groupName = "alexsys-radio";
}
