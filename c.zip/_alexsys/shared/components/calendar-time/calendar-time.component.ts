/* eslint-disable @typescript-eslint/no-explicit-any */
import { Component, Input } from "@angular/core";
import { FormControl } from "@angular/forms";

@Component({
  selector: "alexsys-calendar-time",
  standalone: false,
  templateUrl: "./calendar-time.component.html",
  styleUrl: "./calendar-time.component.scss",
})
export class CalendarTimeComponent {
  @Input() control = new FormControl<any>("");
  @Input() label = "";
  @Input() inputId = "";
  @Input() placeholder = "";
  @Input() value: any;
  @Input() required = false;
  @Input() disabled = false;
  @Input() showValidationIcon = false;
  @Input() showButtonBar = false;
  @Input() hourFormat: "12" | "24" = "24";
}
