import {
  ChangeDetectorRef,
  Component,
  ElementRef,
  OnDestroy,
  OnInit,
  ViewChild,
} from "@angular/core";
import { DomSanitizer, SafeHtml } from "@angular/platform-browser";
import { Subscription } from "rxjs";
import { DocViewerService } from "../../../../services/doc-viewer.service";

@Component({
  selector: "alexsys-doc-viewer-modal",
  standalone: false,
  templateUrl: "./doc-viewer-modal.component.html",
  styleUrls: ["./doc-viewer-modal.component.scss"],
})
export class DocViewerModalComponent implements OnInit, OnDestroy {
  @ViewChild("docxContainer") docxContainer?: ElementRef<HTMLDivElement>;

  visible = false;
  filename = "";
  loading = false;
  error = "";
  safeHtml: SafeHtml = "";
  sheetNames: string[] = [];
  activeSheet = "";

  private pendingBlob: Blob | null = null;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  private workbook: any = null;
  private sub = new Subscription();

  constructor(
    private readonly docViewerService: DocViewerService,
    private readonly cdr: ChangeDetectorRef,
    private readonly sanitizer: DomSanitizer,
  ) {}

  ngOnInit(): void {
    this.sub.add(
      this.docViewerService.open$.subscribe(({ blob, filename }) => {
        this.openFile(blob, filename);
      }),
    );
  }

  ngOnDestroy(): void {
    this.sub.unsubscribe();
  }

  get ext(): string {
    return (this.filename || "").split(".").pop()?.toLowerCase() ?? "";
  }

  get isSpreadsheet(): boolean {
    return this.ext === "xlsx" || this.ext === "xls";
  }

  onDialogShow(): void {
    if (!this.pendingBlob || this.isSpreadsheet) return;
    const blob = this.pendingBlob;
    this.pendingBlob = null;
    this.renderDocx(blob);
  }

  selectSheet(name: string): void {
    this.activeSheet = name;
    this.renderSheet(name);
  }

  close(): void {
    if (this.docxContainer?.nativeElement) {
      this.docxContainer.nativeElement.innerHTML = "";
    }
    this.visible = false;
    this.pendingBlob = null;
    this.workbook = null;
    this.safeHtml = "";
  }

  private openFile(blob: Blob, filename: string): void {
    this.filename = filename;
    this.safeHtml = "";
    this.sheetNames = [];
    this.activeSheet = "";
    this.error = "";
    this.loading = true;
    this.workbook = null;
    if (this.docxContainer?.nativeElement) {
      this.docxContainer.nativeElement.innerHTML = "";
    }

    this.visible = true;
    this.cdr.detectChanges();

    if (this.isSpreadsheet) {
      this.renderXlsx(blob);
    } else {
      // Rendering happens in onDialogShow() once p-dialog has mounted its content
      this.pendingBlob = blob;
    }
  }

  private renderDocx(blob: Blob): void {
    import("docx-preview").then(({ renderAsync }) => {
      const container = this.docxContainer?.nativeElement;
      if (!container) {
        this.error = "Viewer unavailable";
        this.loading = false;
        this.cdr.detectChanges();
        return;
      }
      renderAsync(blob, container, undefined, { inWrapper: false })
        .then(() => {
          this.loading = false;
          this.cdr.detectChanges();
        })
        .catch(() => {
          this.error = "Failed to render document";
          this.loading = false;
          this.cdr.detectChanges();
        });
    });
  }

  private renderXlsx(blob: Blob): void {
    import("xlsx").then((XLSX) => {
      blob.arrayBuffer().then((buf) => {
        try {
          this.workbook = XLSX.read(new Uint8Array(buf), { type: "array" });
          this.sheetNames = this.workbook.SheetNames;
          this.activeSheet = this.sheetNames[0];
          this.renderSheet(this.activeSheet);
        } catch {
          this.error = "Failed to render spreadsheet";
          this.loading = false;
          this.cdr.detectChanges();
        }
      });
    });
  }

  private renderSheet(sheetName: string): void {
    import("xlsx").then((XLSX) => {
      const sheet = this.workbook.Sheets[sheetName];
      const html = XLSX.utils.sheet_to_html(sheet);
      const match = html.match(/<table[\s\S]*<\/table>/i);
      const tableHtml = match ? match[0] : html;
      this.safeHtml = this.sanitizer.bypassSecurityTrustHtml(tableHtml);
      this.loading = false;
      this.cdr.detectChanges();
    });
  }
}
