import { Component, Input } from "@angular/core";

@Component({
  selector: "alexsys-custom-tabs",
  templateUrl: "./tabs..component.html",
  styleUrls: ["./tabs.component.scss"],
  standalone: false,
})
export class TabsComponent {
  // Tabs array
  @Input() tabs: { value: string; label: string; content: string | any; icon?: string }[] = [];

  // Active value (PrimeNG’s new Tabs API uses string values instead of index)
  @Input() activeValue = "";

  // Dynamic grid style for equal width headers
  get gridStyle() {
    return {
      "grid-template-columns": `repeat(${this.tabs.length}, 1fr)`,
    };
  }
}
