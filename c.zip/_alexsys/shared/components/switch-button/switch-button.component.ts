import { Component } from "@angular/core";

@Component({
  selector: "alexsys-switch-button",
  standalone: false,
  templateUrl: "./switch-button.component.html",
  styleUrl: "./switch-button.component.scss",
})
export class SwitchButtonComponent {
  checked = false;
  amberSwitch = {
    handle: {
      borderRadius: "4px",
    },
    colorScheme: {
      light: {
        root: {
          checkedBackground: "{amber.500}",
          checkedHoverBackground: "{amber.600}",
          borderRadius: "4px",
        },
        handle: {
          checkedBackground: "{amber.50}",
          checkedHoverBackground: "{amber.100}",
        },
      },
    },
  };
}
