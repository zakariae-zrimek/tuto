/* eslint-disable @typescript-eslint/no-explicit-any */
import { Component, Input, HostListener } from "@angular/core";
import { FormControl } from "@angular/forms";

@Component({
  selector: "alexsys-input",
  standalone: false,
  templateUrl: "./input.component.html",
  styleUrl: "./input.component.scss",
})
export class InputComponent {
  @Input() control = new FormControl<any>("");
  @Input() label = "";
  @Input() inputId = "";
  @Input() type = "text";
  @Input() placeholder = "";
  @Input() value: any;
  @Input() required = false;
  @Input() disabled = false;
  @Input() showValidationIcon = false;
  /** Lorsque true, bloque les virgules et les points (nombres entiers uniquement). */
  @Input() integer = false;

  onWheel(event: WheelEvent): void {
    if (this.type === "number") {
      (event.target as HTMLInputElement).blur();
    }
  }

  onKeydown(event: KeyboardEvent): void {
    if (this.type !== "number") return;
    // Toujours bloquer : e/E (notation scientifique), + et -
    if (["e", "E", "+", "-"].includes(event.key)) {
      event.preventDefault();
      return;
    }
    // Pour les entiers, bloquer aussi le séparateur décimal
    if (this.integer && [".", ","].includes(event.key)) {
      event.preventDefault();
    }
  }

  onPaste(event: ClipboardEvent): void {
    if (this.type !== "number") return;
    const text = event.clipboardData?.getData("text") ?? "";
    const pattern = this.integer ? /^\d+$/ : /^\d*\.?\d*$/;
    if (!pattern.test(text)) {
      event.preventDefault();
    }
  }
}
