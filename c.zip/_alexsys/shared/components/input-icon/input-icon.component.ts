/* eslint-disable @typescript-eslint/no-explicit-any */
import { Component, Input } from "@angular/core";
import { FormControl } from "@angular/forms";

@Component({
  selector: "alexsys-input-icon",
  standalone: false,
  templateUrl: "./input-icon.component.html",
  styleUrl: "./input-icon.component.scss",
})
export class InputIconComponent {
  @Input() control = new FormControl<any>("");
  @Input() label = "";
  @Input() inputId = "";
  @Input() type = "text";
  @Input() placeholder = "";
  @Input() icon = "";
  @Input() iconPosition: "left" | "right" = "left";
  @Input() value: any;
  @Input() required = false;
  @Input() disabled = false;
  @Input() showValidationIcon = false;
}
