import { Component, Input } from "@angular/core";
import { FormControl } from "@angular/forms";

@Component({
  selector: "alexsys-calendar",
  standalone: false,
  templateUrl: "./calendar.component.html",
  styleUrl: "./calendar.component.scss",
})
export class CalendarComponent {
  @Input() control = new FormControl<string | null>("");
  @Input() label = "";
  @Input() inputId = "";
  @Input() type = "text";
  @Input() placeholder = "";
  @Input() value: string | Date | null = null;
  @Input() required = false;
  @Input() disabled = false;
  @Input() showValidationIcon = false;
  @Input() dateFormat = "mm/dd/yy";
  @Input() minDate: Date | null = null;
  @Input() maxDate: Date | null = null;
  @Input() showButtonBar = false;
  @Input() appendTo: any = null;
}
