import { Component, Input, Output, EventEmitter } from "@angular/core";
import { ButtonSeverity } from "primeng/button";

@Component({
  selector: "alexsys-button",
  standalone: false,
  templateUrl: "./button.component.html",
  styleUrl: "./button.component.scss",
})
export class ButtonComponent {
  @Input() label = "";
  @Input() icon = "";
  @Input() iconPos: "left" | "right" = "left";
  @Input() loading = false;
  @Input() severity: ButtonSeverity = "primary";
  @Input() type: "button" | "submit" = "button";
  @Input() outlined = false;
  @Input() disabled = false;
  @Input() badge = "";
  @Input() badgeSeverity: ButtonSeverity = "info";
  @Input() size: "sm" | "md" | "lg" = "md";
  @Input() variant:
    | "default"
    | "destructive"
    | "outline"
    | "outline-primary"
    | "secondary"
    | "ghost"
    | "link" = "default";

  @Input() className = "";
  @Input() style?: Partial<CSSStyleDeclaration>;

  // NEW
  @Input() fullWidth = false;

  @Output() clicked = new EventEmitter<void>();

  handleClick() {
    this.clicked.emit();
  }

  get buttonClasses() {
    const base =
      "inline-flex items-center justify-center gap-2 rounded-md text-sm font-medium transition-colors focus:outline-none focus:ring-2 focus:ring-offset-2 disabled:pointer-events-none disabled:opacity-50";
    const sizeClasses = {
      sm: "h-9 px-3",
      md: "h-10 px-4",
      lg: "h-11 px-8",
      icon: "h-10 w-10",
    };
    const variantClasses = {
      default: "bg-primary text-white hover:bg-primary/90",
      destructive: "bg-red-600 text-white hover:bg-red-700",
      // outline: "border border-gray-300 bg-white hover:bg-gray-50",
      secondary: "bg-gray-200 text-gray-800 hover:bg-gray-300",
      ghost: "bg-transparent hover:bg-gray-100",
      link: "text-blue-600 underline hover:text-blue-700",
      outline: "border border-gray-300 bg-white hover:bg-gray-50",
      "outline-primary": "!border !border-primary !bg-white !text-primary hover:!bg-primary/5",

    };

    return `${base} ${sizeClasses[this.size]} ${variantClasses[this.variant]} ${this.fullWidth ? "w-full" : "w-auto"
      }`;
  }
}
