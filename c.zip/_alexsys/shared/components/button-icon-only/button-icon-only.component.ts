import { Component, EventEmitter, Input, Output } from "@angular/core";
import { ButtonSeverity } from "primeng/button";

@Component({
  selector: "alexsys-button-icon-only",
  standalone: false,
  templateUrl: "./button-icon-only.component.html",
  styleUrl: "./button-icon-only.component.scss",
})
export class ButtonIconOnlyComponent {
  @Input() icon = "";
  @Input() rounded = false;
  @Input() outlined = false;
  @Input() raised = false;
  @Input() text = false;
  @Input() severity: ButtonSeverity = "primary";

  @Output() clicked = new EventEmitter<Event>();

  handleClick(event: Event) {
    this.clicked.emit(event);
  }
}
