import { Component, EventEmitter, Input, Output, ViewChild } from "@angular/core";
import { MenuItem } from "primeng/api";
import { OverlayPanel } from "primeng/overlaypanel";

@Component({
  selector: "alexsys-three-dot-menu",
  templateUrl: "./three-dot-menu.component.html",
  standalone: false,
  styleUrls: ["./three-dot-menu.component.scss"],
})
export class ThreeDotMenuComponent {
  @Input() items: MenuItem[] = [];
  @Output() select = new EventEmitter<string>();

  @ViewChild("panel") panel!: OverlayPanel;

  toggleMenu(event: MouseEvent) {
    event.preventDefault();
    event.stopPropagation();
    this.panel.toggle(event);
  }

  onItemClick(event: MouseEvent, item: MenuItem) {
    event.preventDefault();
    event.stopPropagation();

    const id = (item as any)?.data?.id as string | undefined;
    if (id) this.select.emit(id);

    if (item.command) {
      item.command({ originalEvent: event, item });
    }

    this.panel.hide();
  }
}
