import { Injectable, OnDestroy } from "@angular/core";
import { MenuItem } from "primeng/api";

export interface Action {
  label: string;
  icon?: string;
  handler: (row: any) => void;
  visible?: (row: any) => boolean; // optional visibility function
}

@Injectable({
  providedIn: "root",
})
export class ActionMenuService implements OnDestroy {
  private actionDefs: Record<string, Action[]> = {};
  private actionMenuCache = new Map<string, MenuItem[]>();

  /**
   * Register actions for a single entity
   */
  registerActions(entity: string, actions: Action[]): void {
    this.actionDefs[entity] = actions;
  }

  /**
   * Register multiple entities at once
   */
  registerAll(actionMap: Record<string, Action[]>): void {
    Object.entries(actionMap).forEach(([entity, actions]) => {
      this.registerActions(entity, actions);
    });
  }

  /**
   * Get cached menu for a row + entity
   */
  getCachedActionMenu(row: any, entity: string): MenuItem[] {
    const key = this.makeCacheKey(row, entity);

    if (!this.actionMenuCache.has(key)) {
      const menu = this.getActionMenu(row, entity);
      this.actionMenuCache.set(key, menu);
    }

    return this.actionMenuCache.get(key) ?? [];
  }

  /**
   * Build MenuItems dynamically
   */
  private getActionMenu(row: any, entity: string): MenuItem[] {
    const actions = this.actionDefs[entity] || [];
    return actions
      .filter(action => (action.visible ? action.visible(row) : true)) // check visibility
      .map(action => ({
        label: action.label,
        icon: action.icon,
        command: () => action.handler(row),
      }));
  }

  /**
   * Generate a unique cache key for a row + entity
   */
  private makeCacheKey(row: any, entity: string): string {
    if (row && typeof row === "object") {
      return `${entity}-${row.id ?? this.hash(JSON.stringify(row))}`;
    }
    // if row is primitive (string/number)
    return `${entity}-${row}`;
  }

  /**
   * Simple hash function for objects without ID
   */
  private hash(str: string): number {
    let h = 0;
    for (let i = 0; i < str.length; i++) {
      h = Math.imul(31, h) + str.charCodeAt(i) || 0;
    }
    return h;
  }

  /**
   * Clear cache and definitions
   */
  clear(): void {
    this.actionMenuCache.clear();
    this.actionDefs = {};
  }

  ngOnDestroy(): void {
    this.clear();
  }
}
