import { Component, Input } from "@angular/core";
import { FormControl } from "@angular/forms";
import { TreeNode } from "primeng/api";

@Component({
  selector: "alexsys-tree-select",
  standalone: false,
  templateUrl: "./tree-select.component.html",
  styleUrl: "./tree-select.component.scss",
})
export class TreeSelectComponent {
  @Input() control: FormControl = new FormControl();
  @Input() nodes: TreeNode[] = [];
  @Input() label = "";
  @Input() inputId = "";
  @Input() placeholder = "";
  @Input() filter = false;
  @Input() loading = false;
  @Input() optionLabel = "label";
  @Input() optionValue = "key";
  @Input() required = false;
  @Input() showValidationIcon = false;
  @Input() disabled = false;
}
