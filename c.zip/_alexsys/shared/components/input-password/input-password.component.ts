import { Component, Input } from "@angular/core";
import { FormControl } from "@angular/forms";

@Component({
  selector: "alexsys-input-password",
  standalone: false,
  templateUrl: "./input-password.component.html",
  styleUrl: "./input-password.component.scss",
})
export class InputPasswordComponent {
  @Input() control: FormControl = new FormControl("");
  @Input() label = "";
  @Input() inputId = "";
  @Input() placeholder = "";
  @Input() required = false;
  @Input() icon = "";
  @Input() showValidationIcon = false;
  @Input() toggleMask = false;
  @Input() feedback = false;
  @Input() template = false;
}
