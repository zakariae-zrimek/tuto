import { Component, Input } from '@angular/core';
import { FormControl } from '@angular/forms';

@Component({
  selector: "alexsys-checkbox",
  standalone: false,
  templateUrl: "./checkbox.component.html",
  styleUrl: "./checkbox.component.scss",
})
export class CheckboxComponent {
  @Input() control: FormControl = new FormControl(false);
  @Input() label = "";
  @Input() inputId = "";
  @Input() required = false;
  @Input() disabled = false;
  @Input() showValidationIcon = false;
}
