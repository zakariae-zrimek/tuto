import { Component, Input } from "@angular/core";
import { FormControl } from "@angular/forms";

@Component({
    selector: "alexsys-datepicker",
    standalone: false,
    templateUrl: "./datepicker.component.html",
    styleUrl: "./datepicker.component.scss",
})
export class DatepickerComponent {
    @Input() control: FormControl<Date | null> = new FormControl<Date | null>(null);

    @Input() label = "";
    @Input() inputId = "";
    @Input() required = false;

    @Input() disabled = false;
    @Input() showValidationIcon = false;

    @Input() placeholder = "jj/mm/aaaa";
    @Input() dateFormat = "dd/mm/yy";
    @Input() appendTo: "body" | null = "body";
    @Input() readonlyInput = true;

    // NEW
    @Input() minDate: Date | null = null;
    @Input() maxDate: Date | null = null;
}
