import { Component, Input } from "@angular/core";
import { FormControl } from "@angular/forms";

@Component({
  selector: "alexsys-switch-control",
  standalone: false,
  templateUrl: "./switch-control.component.html",
  styleUrls: ["./switch-control.component.scss"],
})
export class SwitchControlComponent {
  private _control?: FormControl<boolean>;

  @Input()
  set control(v: FormControl<boolean> | null | undefined) {
    this._control = v ?? undefined;
  }

  get control(): FormControl<boolean> {
    return this._control ?? new FormControl(false, { nonNullable: true });
  }

  @Input() disabled = false;
  @Input() label = "";

  get isDisabled(): boolean {
    return this.disabled || this.control.disabled;
  }

  get isOn(): boolean {
    return !!this.control.value;
  }

  toggle(): void {
    if (this.isDisabled) return;
    this.control.setValue(!this.isOn);
    this.control.markAsDirty();
    this.control.markAsTouched();
  }

  onKeydown(event: KeyboardEvent): void {
    if (event.key === " " || event.key === "Enter") {
      event.preventDefault();
      this.toggle();
    }
  }
}
