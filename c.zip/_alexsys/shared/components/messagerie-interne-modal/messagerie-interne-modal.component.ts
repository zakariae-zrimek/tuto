import {
  AfterViewChecked,
  ChangeDetectionStrategy,
  ChangeDetectorRef,
  Component,
  ElementRef,
  OnDestroy,
  OnInit,
  ViewChild,
  signal,
} from "@angular/core";
import { NavigationStart, Router } from "@angular/router";
import { Subject } from "rxjs";
import { filter, takeUntil } from "rxjs/operators";
import { MessagerieWebSocketService, MessageWebSocketEvent } from "../../../../services/messagerie-websocket.service";
import { CommonModule } from "@angular/common";
import { FormsModule } from "@angular/forms";
import { DynamicDialogConfig, DynamicDialogRef } from "primeng/dynamicdialog";
import { ButtonModule } from "primeng/button";
import { ProgressSpinnerModule } from "primeng/progressspinner";

import {
  MessagerieInterneHttpService,
  MessageResponse,
  ReferenceType,
  SendMessageRequest,
  UnreadSenderSummaryItem,
} from "../../../../services/messagerie-interne-http.service";
import { InternalUsersHttpService } from "../../../../services/internalUser-http.service";
import { UserProfileDto } from "../../../../services/types/users.types";
import { AuthService } from "../../../../modules/auth/services/auth.service";

export interface MessagerieInterneModalData {
  referenceType: ReferenceType;
  referenceId: string;
  referenceLabel: string;
  /** Code prestataire of the reception — used to fetch prestataire users */
  prestataireCode?: string | null;
  /** Acte reference passed to notifications only — not stored on the message */
  acteReference?: string | null;
  /** When set, only these role codes appear in the sidebar (e.g. ['ROLE_SAL']) */
  allowedRoles?: string[];
  /**
   * When true, clicking a role immediately opens a broadcast thread to the whole role
   * (no individual user selection step). Use for prestataire → SAL messages.
   */
  forceBroadcast?: boolean;
}

const ROLES: { code: string; label: string; icon: string }[] = [
  { code: "ROLE_SAL", label: "SAL", icon: "pi-users" },
  { code: "ROLE_SBCC", label: "SBCC", icon: "pi-briefcase" },
  { code: "ROLE_SBC", label: "SBC", icon: "pi-building" },
  { code: "ROLE_CSBC", label: "CSBC", icon: "pi-shield" },
  { code: "ROLE_PRESTATAIRE", label: "Prestataire", icon: "pi-wrench" },
  { code: "ROLE_DS", label: "DS", icon: "pi-chart-bar" },
  { code: "ROLE_SG", label: "SG", icon: "pi-cog" },
  { code: "ROLE_PRESIDENT", label: "Président", icon: "pi-star" },
  { code: "ROLE_CA", label: "CA", icon: "pi-sitemap" },
  { code: "ROLE_SIGNATAIRE", label: "Signataire", icon: "pi-pencil" },
];

@Component({
  selector: "alexsys-messagerie-interne-modal",
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    ButtonModule,
    ProgressSpinnerModule,
  ],
  templateUrl: "./messagerie-interne-modal.component.html",
  styleUrls: ["./messagerie-interne-modal.component.scss"],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class MessagerieInterneModalComponent implements OnInit, AfterViewChecked, OnDestroy {
  @ViewChild("messagesContainer") private messagesContainer!: ElementRef<HTMLElement>;

  get roles(): { code: string; label: string; icon: string }[] {
    if (!this.data?.allowedRoles?.length) return ROLES;
    return ROLES.filter(r => this.data.allowedRoles!.includes(r.code));
  }

  data!: MessagerieInterneModalData;
  currentUserId: string = "";
  currentUserRole: string | null = null;

  // Selection state
  selectedRole = signal<string | null>(null);
  selectedUser = signal<UserProfileDto | null>(null);
  broadcastRole = signal<{ code: string; label: string } | null>(null);

  // Data
  usersForRole = signal<UserProfileDto[]>([]);
  messages = signal<MessageResponse[]>([]);

  // Unread counts per role-code / keycloakUserId
  unreadByRole = signal<Record<string, number>>({});
  unreadByUser = signal<Record<string, number>>({});

  // Loading flags
  usersLoading = signal(false);
  messagesLoading = signal(false);
  sending = signal(false);

  // Edit / delete state
  editingMessageId = signal<number | null>(null);
  confirmDeleteId = signal<number | null>(null);
  editDraft = "";
  savingEdit = signal(false);
  deletingId = signal<number | null>(null);

  // Compose
  draftContent = "";

  private shouldScrollToBottom = false;
  private destroy$ = new Subject<void>();
  private ws = new MessagerieWebSocketService();

  constructor(
    private config: DynamicDialogConfig,
    private ref: DynamicDialogRef,
    private messagerie: MessagerieInterneHttpService,
    private internalUsers: InternalUsersHttpService,
    private auth: AuthService,
    private cdr: ChangeDetectorRef,
    private router: Router,
  ) {
    this.router.events.pipe(
      filter(e => e instanceof NavigationStart),
      takeUntil(this.destroy$),
    ).subscribe(() => this.ref.close());
  }

  ngOnInit(): void {
    this.data = this.config.data as MessagerieInterneModalData;
    this.currentUserId = this.auth.getCurrentKeycloakUserId() ?? "";
    this.currentUserRole = this.auth.getActiveRole();
    this.loadInboxSummary();
    this.connectWebSocket();
  }

  ngAfterViewChecked(): void {
    if (this.shouldScrollToBottom) {
      this.scrollToBottom();
      this.shouldScrollToBottom = false;
    }
  }

  // ── WebSocket ─────────────────────────────────────────────────────────────

  private connectWebSocket(): void {
    const token = this.auth.tokens()?.accessToken;
    if (!token) return;
    this.ws.connect(this.data.referenceType, this.data.referenceId, token);
    this.ws.events$.pipe(takeUntil(this.destroy$)).subscribe((event) => this.handleWsEvent(event));
  }

  private handleWsEvent(event: MessageWebSocketEvent): void {
    if (event.type === "NEW" && event.payload) {
      const msg = event.payload;
      // Skip if we already appended this message optimistically (own sent message)
      if (this.messages().some((m) => m.id === msg.id)) return;
      // Only append if it belongs to the currently open thread
      if (!this.isInCurrentThread(msg)) return;
      this.messages.update((list) => [...list, msg]);
      this.shouldScrollToBottom = true;
      // Auto-mark as read if received while thread is open (only if we are the intended recipient)
      if (msg.senderKeycloakUserId !== this.currentUserId && this.isAddressedToMe(msg)) {
        this.messagerie.markAsRead(msg.id).subscribe();
      }
      this.cdr.markForCheck();
    } else if (event.type === "EDIT" && event.payload) {
      const updated = event.payload;
      this.messages.update((list) => list.map((m) => (m.id === updated.id ? updated : m)));
      this.cdr.markForCheck();
    } else if (event.type === "DELETE" && event.messageId != null) {
      this.messages.update((list) => list.filter((m) => m.id !== event.messageId));
      this.cdr.markForCheck();
    }
  }

  private isInCurrentThread(msg: MessageResponse): boolean {
    const user = this.selectedUser();
    const broadcast = this.broadcastRole();

    if (broadcast) {
      // Broadcast thread: outgoing to this role, or incoming from this role
      return (
        (msg.senderKeycloakUserId === this.currentUserId &&
          msg.receiverType === "ROLE" &&
          this.matchRole(msg.receiverRole, broadcast.code)) ||
        this.matchRole(msg.senderRole, broadcast.code)
      );
    }

    if (user) {
      // Per-user thread: direct exchange or colleague messages
      return (
        (msg.receiverType === "USER" && (
          (msg.senderKeycloakUserId === this.currentUserId && msg.receiverKeycloakUserId === user.keycloakUserId) ||
          (msg.senderKeycloakUserId === user.keycloakUserId && msg.receiverKeycloakUserId === this.currentUserId) ||
          (this.matchRole(msg.senderRole, this.currentUserRole) && msg.receiverKeycloakUserId === user.keycloakUserId)
        )) ||
        (msg.receiverType === "ROLE" && (
          msg.senderKeycloakUserId === user.keycloakUserId ||
          msg.senderKeycloakUserId === this.currentUserId ||
          this.matchRole(msg.senderRole, this.currentUserRole)
        ))
      );
    }

    return false;
  }

  // ── Inbox summary ─────────────────────────────────────────────────────────

  private loadInboxSummary(): void {
    this.messagerie
      .getUnreadSenderSummary(this.data.referenceType, this.data.referenceId, this.currentUserRole)
      .subscribe({
        next: (items: UnreadSenderSummaryItem[]) => {
          const byUser: Record<string, number> = {};
          const byRole: Record<string, number> = {};
          for (const item of items) {
            byUser[item.senderKeycloakUserId] = (byUser[item.senderKeycloakUserId] ?? 0) + item.count;
            if (item.senderRole) {
              const roleCode = item.senderRole.startsWith("ROLE_") ? item.senderRole : `ROLE_${item.senderRole}`;
              byRole[roleCode] = (byRole[roleCode] ?? 0) + item.count;
            }
          }
          this.unreadByUser.set(byUser);
          this.unreadByRole.set(byRole);
          this.cdr.markForCheck();
        },
      });
  }

  // ── Role ─────────────────────────────────────────────────────────────────

  selectRole(roleCode: string): void {
    if (this.selectedRole() === roleCode && !this.data.forceBroadcast) return;
    this.selectedRole.set(roleCode);
    this.selectedUser.set(null);
    this.broadcastRole.set(null);
    this.messages.set([]);
    this.usersForRole.set([]);
    this.usersLoading.set(true);
    this.editingMessageId.set(null);
    this.confirmDeleteId.set(null);

    const users$ =
      roleCode === "ROLE_PRESTATAIRE" && this.data.prestataireCode
        ? this.internalUsers.getByPrestataireCode(this.data.prestataireCode)
        : this.internalUsers.getByRole(roleCode);

    users$.subscribe({
      next: (users) => {
        const filtered = users.filter((u) => u.keycloakUserId !== this.currentUserId);
        this.usersForRole.set(filtered);

        // Recompute role badge from per-user counts (fallback when senderRole was null in DB)
        const roleTotalFromUsers = filtered.reduce(
          (sum, u) => sum + (this.unreadByUser()[u.keycloakUserId] ?? 0),
          0
        );
        if (roleTotalFromUsers > 0) {
          const byRole = { ...this.unreadByRole() };
          byRole[roleCode] = roleTotalFromUsers;
          this.unreadByRole.set(byRole);
        }

        this.usersLoading.set(false);

        // Auto-enter broadcast mode when forceBroadcast is set
        if (this.data.forceBroadcast) {
          this.selectBroadcast(roleCode);
        }

        this.cdr.markForCheck();
      },
      error: () => {
        this.usersLoading.set(false);
        this.cdr.markForCheck();
      },
    });
  }

  // ── User / Thread ─────────────────────────────────────────────────────────

  selectUser(user: UserProfileDto): void {
    this.selectedUser.set(user);
    this.broadcastRole.set(null);
    this.editingMessageId.set(null);
    this.confirmDeleteId.set(null);
    this.loadThread();
  }

  selectBroadcast(roleCode: string): void {
    const r = ROLES.find(r => r.code === roleCode);
    this.broadcastRole.set({ code: roleCode, label: r?.label ?? roleCode.replace('ROLE_', '') });
    this.selectedUser.set(null);
    this.editingMessageId.set(null);
    this.confirmDeleteId.set(null);
    this.loadThread();
  }

  private loadThread(): void {
    this.messagesLoading.set(true);
    this.messagerie
      .getContext(this.data.referenceType, this.data.referenceId, 0, 500, this.currentUserRole)
      .subscribe({
        next: (page) => {
          const user = this.selectedUser();
          const broadcast = this.broadcastRole();

          if (broadcast) {
            const roleCode = broadcast.code;
            const thread = page.content.filter(
              (m) =>
                // Outgoing: current user's messages addressed to this role
                (m.senderKeycloakUserId === this.currentUserId &&
                  m.receiverType === 'ROLE' &&
                  this.matchRole(m.receiverRole, roleCode)) ||
                // Incoming: any message from a member of that role
                this.matchRole(m.senderRole, roleCode)
            );
            this.messages.set(thread);
            this.messagesLoading.set(false);
            this.shouldScrollToBottom = true;
            thread
              .filter((m) => !m.read && m.senderKeycloakUserId !== this.currentUserId && this.isAddressedToMe(m))
              .forEach((m) => this.messagerie.markAsRead(m.id).subscribe());
            this.cdr.markForCheck();
            return;
          }

          if (!user) return;

          const thread = page.content.filter(
            (m) =>
              // Direct USER messages between current user and selected user
              (m.receiverType === 'USER' && (
                (m.senderKeycloakUserId === this.currentUserId && m.receiverKeycloakUserId === user.keycloakUserId) ||
                (m.senderKeycloakUserId === user.keycloakUserId && m.receiverKeycloakUserId === this.currentUserId) ||
                // Colleague's direct message to the selected user
                (this.matchRole(m.senderRole, this.currentUserRole) && m.receiverKeycloakUserId === user.keycloakUserId)
              )) ||
              // ROLE broadcasts from current user, selected user, or a colleague
              (m.receiverType === 'ROLE' && (
                m.senderKeycloakUserId === user.keycloakUserId ||
                m.senderKeycloakUserId === this.currentUserId ||
                this.matchRole(m.senderRole, this.currentUserRole)
              ))
          );
          this.messages.set(thread);
          this.messagesLoading.set(false);
          this.shouldScrollToBottom = true;

          // Mark unread messages from this user as read (only if we are the intended recipient)
          thread
            .filter((m) => !m.read && m.senderKeycloakUserId === user.keycloakUserId && this.isAddressedToMe(m))
            .forEach((m) => this.messagerie.markAsRead(m.id).subscribe());

          // Optimistically clear badges
          const userUnread = this.unreadByUser()[user.keycloakUserId] ?? 0;
          if (userUnread > 0) {
            const roleCode = this.selectedRole();
            if (roleCode) {
              const byRole = { ...this.unreadByRole() };
              const newRoleCount = Math.max(0, (byRole[roleCode] ?? 0) - userUnread);
              if (newRoleCount === 0) delete byRole[roleCode];
              else byRole[roleCode] = newRoleCount;
              this.unreadByRole.set(byRole);
            }
            const byUser = { ...this.unreadByUser() };
            delete byUser[user.keycloakUserId];
            this.unreadByUser.set(byUser);
          }

          this.cdr.markForCheck();
        },
        error: () => {
          this.messagesLoading.set(false);
          this.cdr.markForCheck();
        },
      });
  }

  // ── Send ──────────────────────────────────────────────────────────────────

  send(): void {
    const user = this.selectedUser();
    const broadcast = this.broadcastRole();
    if ((!user && !broadcast) || !this.draftContent.trim() || this.sending()) return;
    this.sending.set(true);
    const base = {
      content: this.draftContent.trim(),
      referenceType: this.data.referenceType,
      referenceId: this.data.referenceId,
      referenceLabel: this.data.referenceLabel,
      ...(this.data.acteReference ? { acteReference: this.data.acteReference } : {}),
    };
    const request: SendMessageRequest = broadcast
      ? { ...base, receiverType: "ROLE", receiverRole: broadcast.code, senderRole: this.currentUserRole ?? undefined }
      : { ...base, receiverType: "USER", receiverKeycloakUserId: user!.keycloakUserId, senderRole: this.currentUserRole ?? undefined };
    this.messagerie.send(request).subscribe({
      next: (msg) => {
        // WS echo may have already appended this message — deduplicate by ID
        if (!this.messages().some((m) => m.id === msg.id)) {
          this.messages.update((list) => [...list, msg]);
        }
        this.draftContent = "";
        this.sending.set(false);
        this.shouldScrollToBottom = true;
        this.cdr.markForCheck();
      },
      error: () => {
        this.sending.set(false);
        this.cdr.markForCheck();
      },
    });
  }

  onEnter(ev: KeyboardEvent): void {
    if (ev.key === "Enter" && !ev.shiftKey) {
      ev.preventDefault();
      this.send();
    }
  }

  // ── Edit ──────────────────────────────────────────────────────────────────

  startEdit(msg: MessageResponse): void {
    this.editingMessageId.set(msg.id);
    this.editDraft = msg.content;
    this.confirmDeleteId.set(null);
  }

  cancelEdit(): void {
    this.editingMessageId.set(null);
    this.editDraft = "";
  }

  saveEdit(): void {
    const id = this.editingMessageId();
    if (!id || !this.editDraft.trim() || this.savingEdit()) return;
    this.savingEdit.set(true);
    this.messagerie.updateMessage(id, this.editDraft.trim()).subscribe({
      next: (updated) => {
        // Update immediately; WS EDIT echo is idempotent (same data)
        this.messages.update((list) => list.map((m) => (m.id === id ? updated : m)));
        this.editingMessageId.set(null);
        this.editDraft = "";
        this.savingEdit.set(false);
        this.cdr.markForCheck();
      },
      error: () => {
        this.savingEdit.set(false);
        this.cdr.markForCheck();
      },
    });
  }

  // ── Delete ────────────────────────────────────────────────────────────────

  confirmDelete(id: number): void {
    this.confirmDeleteId.set(id);
    this.editingMessageId.set(null);
  }

  cancelDelete(): void {
    this.confirmDeleteId.set(null);
  }

  executeDelete(id: number): void {
    if (this.deletingId()) return;
    this.deletingId.set(id);
    this.messagerie.deleteMessage(id).subscribe({
      next: () => {
        // Remove immediately; WS DELETE echo is idempotent (already gone)
        this.messages.update((list) => list.filter((m) => m.id !== id));
        this.confirmDeleteId.set(null);
        this.deletingId.set(null);
        this.cdr.markForCheck();
      },
      error: () => {
        this.confirmDeleteId.set(null);
        this.deletingId.set(null);
        this.cdr.markForCheck();
      },
    });
  }

  // ── Helpers ───────────────────────────────────────────────────────────────

  isMine(msg: MessageResponse): boolean {
    return msg.senderKeycloakUserId === this.currentUserId;
  }

  /** True when the message is from a colleague of the same role (not the current user). */
  isColleague(msg: MessageResponse): boolean {
    return !this.isMine(msg) && this.matchRole(msg.senderRole, this.currentUserRole);
  }

  /** True when the current user is the intended recipient (can legitimately call markAsRead). */
  private isAddressedToMe(msg: MessageResponse): boolean {
    if (msg.receiverType === 'ROLE') return true;
    return msg.receiverKeycloakUserId === this.currentUserId;
  }

  private matchRole(a: string | null | undefined, b: string | null | undefined): boolean {
    if (!a || !b) return false;
    const norm = (r: string) => r.startsWith('ROLE_') ? r : 'ROLE_' + r;
    return norm(a) === norm(b);
  }

  roleLabel(code: string): string {
    return ROLES.find((r) => r.code === code)?.label ?? code;
  }

  unreadForRole(code: string): number {
    return this.unreadByRole()[code] ?? 0;
  }

  unreadForUser(userId: string): number {
    return this.unreadByUser()[userId] ?? 0;
  }

  userDisplayName(u: UserProfileDto): string {
    return `${u.firstName} ${u.lastName}`.trim() || u.email;
  }

  ngOnDestroy(): void {
    this.ws.disconnect();
    this.destroy$.next();
    this.destroy$.complete();
  }

  close(): void {
    this.ref.close();
  }

  private scrollToBottom(): void {
    try {
      const el = this.messagesContainer?.nativeElement;
      if (el) el.scrollTop = el.scrollHeight;
    } catch {}
  }
}
