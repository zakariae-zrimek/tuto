/* eslint-disable @typescript-eslint/no-explicit-any */
import { Component, Input } from "@angular/core";
import { FormControl } from "@angular/forms";

@Component({
  selector: "alexsys-select",
  standalone: false,
  templateUrl: "./select.component.html",
  styleUrl: "./select.component.scss",
})
export class SelectComponent<T> {
  @Input() control = new FormControl<any>("");
  @Input() items: T[] = [];
  @Input() label = "";
  @Input() inputId = "";
  @Input() placeholder = "";
  @Input() filter = false;
  @Input() loading = false;

  // @Input({ required: true }) optionLabel!: Extract<keyof T, string>;
  // @Input({ required: true }) optionValue!: Extract<keyof T, string>;
  @Input() optionLabel!: string;
  @Input() optionValue!: string;

  @Input() selectedValue: T | undefined;
  @Input() required = false;
  @Input() disabled = false;
  @Input() showValidationIcon = false;
  @Input() filterFunction?: (item: any, filterText: string) => boolean;
}
