import { Injectable } from "@angular/core";

export type ColumnVisibilityMap = Record<string, boolean>; // columnId -> visible

export type ColumnVisibilityState = Record<string, ColumnVisibilityMap>; // tableKey/groupKey -> map

export type ColumnPrefsScope = {
  userKey: string;   // keycloakUserId
  screenKey: string; // "traitement-actes"
};

type StorageShapeV1 = {
  v: 1;
  updatedAt: string; // ISO
  state: ColumnVisibilityState;
};

@Injectable({ providedIn: "root" })
export class TableColumnPrefsService {
  private readonly prefix = "alexsys:table-column-prefs";

  /** Build storage key: per user + screen. */
  private storageKey(scope: ColumnPrefsScope): string {
    const u = (scope.userKey || "anonymous").trim();
    const s = (scope.screenKey || "global").trim();
    return `${this.prefix}:v1:${u}:${s}`;
  }

  /**
   * Reads stored prefs (if any). Returns null if none or corrupted.
   * This function is intentionally defensive: prefs should never break the UI.
   */
  read(scope: ColumnPrefsScope): ColumnVisibilityState | null {
    try {
      const raw = localStorage.getItem(this.storageKey(scope));
      if (!raw) return null;

      const parsed = JSON.parse(raw) as StorageShapeV1;
      if (!parsed || parsed.v !== 1 || typeof parsed.state !== "object") return null;

      return parsed.state ?? null;
    } catch {
      return null;
    }
  }

  /**
   * Writes complete prefs state (all table groups).
   * Caller is responsible for building the state shape.
   */
  write(scope: ColumnPrefsScope, state: ColumnVisibilityState): void {
    const payload: StorageShapeV1 = {
      v: 1,
      updatedAt: new Date().toISOString(),
      state: state ?? {},
    };

    try {
      localStorage.setItem(this.storageKey(scope), JSON.stringify(payload));
    } catch {
      // ignore quota / private mode errors; UI must still work
    }
  }

  /** Deletes all prefs for this user+screen. */
  reset(scope: ColumnPrefsScope): void {
    try {
      localStorage.removeItem(this.storageKey(scope));
    } catch {
      // ignore
    }
  }

  /**
   * Returns the effective visibility map for one table/group:
   * - if no saved prefs: all columns visible by default
   * - if saved prefs exist: merge with current columns
   *   - new columns default to visible
   *   - missing/removed columns are ignored
   *
   * Why: configs evolve over time; old stored prefs must not hide newly added columns silently.
   */
  getEffectiveVisibilityForGroup(
    scope: ColumnPrefsScope,
    groupKey: string,
    columnIds: string[],
    visibleByDefault = true
  ): ColumnVisibilityMap {
    const saved = this.read(scope);
    const group = saved?.[groupKey] ?? {};

    const out: ColumnVisibilityMap = {};
    for (const colId of columnIds) {
      const v = group[colId];
      out[colId] = typeof v === "boolean" ? v : visibleByDefault;
    }
    return out;
  }

  /**
   * Upserts one group visibility map into persisted state.
   * Keeps other groups untouched.
   */
  upsertGroup(
    scope: ColumnPrefsScope,
    groupKey: string,
    visibility: ColumnVisibilityMap
  ): void {
    const current = this.read(scope) ?? {};
    const next: ColumnVisibilityState = {
      ...current,
      [groupKey]: { ...(visibility ?? {}) },
    };
    this.write(scope, next);
  }

  /**
   * Builds a default state for a set of groups and column ids.
   * Useful for "Réinitialiser" and first-time initialization.
   */
  buildDefaultState(groups: Array<{ groupKey: string; columnIds: string[] }>): ColumnVisibilityState {
    const state: ColumnVisibilityState = {};
    for (const g of groups) {
      const map: ColumnVisibilityMap = {};
      for (const colId of g.columnIds) map[colId] = true;
      state[g.groupKey] = map;
    }
    return state;
  }
}
