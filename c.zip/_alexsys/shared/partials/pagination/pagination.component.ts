import { Component, EventEmitter, Input, Output } from "@angular/core";

@Component({
  selector: "alexsys-pagination",
  standalone: false,
  templateUrl: "./pagination.component.html",
})
export class PaginationComponent {
  @Input() total = 0;
  @Input() pageIndex = 0; // 0-based
  @Input() pageSize = 5;
  @Input() currentCount = 0;

  @Output() pageIndexChange = new EventEmitter<number>();

  get totalPages(): number {
    return Math.max(1, Math.ceil(this.total / this.pageSize));
  }

  prev(): void {
    if (this.pageIndex > 0) this.pageIndexChange.emit(this.pageIndex - 1);
  }

  next(): void {
    if (this.pageIndex < this.totalPages - 1) this.pageIndexChange.emit(this.pageIndex + 1);
  }
}
