import { Component } from "@angular/core";

@Component({
  selector: "alexsys-card",
  standalone: false,
  templateUrl: "./card.component.html",
  styleUrl: "./card.component.scss",
})
export class CardComponent {}
