import {
  ChangeDetectorRef,
  Component,
  ElementRef,
  EventEmitter,
  HostListener,
  Input,
  OnChanges,
  OnDestroy,
  Output,
  SimpleChanges,
  ViewChild,
} from "@angular/core";
import { DomSanitizer, SafeResourceUrl } from "@angular/platform-browser";
import { Subject } from "rxjs";
import { catchError, takeUntil } from "rxjs/operators";
import { of } from "rxjs";
import { DocumentsHttpService } from "../../../../services/documents-http.service";
import { FileDownloadService } from "../../../../services/file-download.service";
import { renderAsync } from "docx-preview";
import * as XLSX from "xlsx";

export interface FileViewerInput {
  documentId: number;
  fileName: string;
  originalName?: string;
}

type ViewerMode = "iframe" | "image" | "docx" | "unsupported" | null;

@Component({
  selector: "alexsys-file-viewer",
  standalone: false,
  templateUrl: "./file-viewer.component.html",
  styleUrl: "./file-viewer.component.scss",
})
export class FileViewerComponent implements OnChanges, OnDestroy {
  @Input() visible = false;
  @Output() visibleChange = new EventEmitter<boolean>();

  @Input() documentId: number | null = null;
  @Input() fileName = "";
  @Input() originalName = "";

  @ViewChild("docxContainer") private docxContainerRef?: ElementRef<HTMLElement>;

  // ── State ──────────────────────────────────────────────────────────────
  isLoading = false;
  error: string | null = null;
  viewerMode: ViewerMode = null;
  safeUrl: SafeResourceUrl | null = null;

  private docxBlob: Blob | null = null;
  private blobUrl: string | null = null;
  private originalBlobUrl: string | null = null;
  private readonly destroy$ = new Subject<void>();

  constructor(
    private docsHttp: DocumentsHttpService,
    private sanitizer: DomSanitizer,
    private cdr: ChangeDetectorRef,
    private fileDownload: FileDownloadService
  ) {}

  ngOnChanges(changes: SimpleChanges): void {
    if (changes["visible"]) {
      if (this.visible && this.documentId != null) {
        this.lockScroll(true);
        this.loadFile();
      } else if (!this.visible) {
        this.lockScroll(false);
        this.resetState();
      }
    }
    if (changes["documentId"] && this.visible && this.documentId != null) {
      this.loadFile();
    }
  }

  ngOnDestroy(): void {
    this.lockScroll(false);
    this.revokeBlobUrl();
    this.destroy$.next();
    this.destroy$.complete();
  }

  @HostListener("document:keydown.escape")
  onEscape(): void {
    if (this.visible) this.close();
  }

  // ── Load ────────────────────────────────────────────────────────────────
  private loadFile(): void {
    this.isLoading = true;
    this.error = null;
    this.viewerMode = null;
    this.safeUrl = null;
    this.docxBlob = null;
    this.revokeBlobUrl();

    this.docsHttp
      .preview(this.documentId!)
      .pipe(
        catchError(() => {
          this.error =
            "Impossible de charger le fichier. Vérifiez votre connexion ou téléchargez-le.";
          this.isLoading = false;
          return of(null);
        }),
        takeUntil(this.destroy$)
      )
      .subscribe(response => {
        if (!response) return;
        const blob = response.body!;
        const contentType = response.headers.get("content-type") ?? blob.type ?? "";
        this.resolveViewer(blob, contentType).then(() => {
          this.isLoading = false;
          this.cdr.detectChanges(); // let Angular render the *ngIf container

          if (this.viewerMode === "docx" && this.docxBlob) {
            this.renderDocx(this.docxBlob);
          }
        });
      });
  }

  // ── Viewer resolution ────────────────────────────────────────────────────
  private async resolveViewer(blob: Blob, contentType: string): Promise<void> {
    const ct = contentType.toLowerCase();
    const ext = this.ext;

    // Always keep the raw blob URL for download
    this.setOriginalBlobUrl(blob);

    // PDF
    if (ct.includes("pdf") || ext === "pdf") {
      this.viewerMode = "iframe";
      this.setBlobUrl(blob);
      return;
    }

    // Images
    if (
      ct.startsWith("image/") ||
      ["jpg", "jpeg", "png", "gif", "bmp", "webp", "svg"].includes(ext)
    ) {
      this.viewerMode = "image";
      this.setBlobUrl(blob);
      return;
    }

    // Plain text / HTML / CSV / XML
    if (ct.includes("text/") || ["txt", "csv", "html", "xml"].includes(ext)) {
      this.viewerMode = "iframe";
      this.setBlobUrl(blob);
      return;
    }

    // DOCX / DOC → docx-preview renders directly into the DOM container
    if (ct.includes("wordprocessingml") || ct.includes("msword") || ["doc", "docx"].includes(ext)) {
      this.docxBlob = blob;
      this.viewerMode = "docx";
      return;
    }

    // XLSX / XLS → xlsx → HTML blob → iframe
    if (ct.includes("spreadsheetml") || ct.includes("ms-excel") || ["xls", "xlsx"].includes(ext)) {
      try {
        const arrayBuffer = await blob.arrayBuffer();
        const workbook = XLSX.read(arrayBuffer, { type: "array" });
        const images = await this.extractXlsxImages(arrayBuffer);
        const htmlBlob = new Blob([this.workbookToHtml(workbook, images)], { type: "text/html" });
        this.viewerMode = "iframe";
        this.setBlobUrl(htmlBlob);
      } catch (err) {
        console.error("[FileViewer] XLSX conversion failed:", err);
        this.viewerMode = "unsupported";
      }
      return;
    }

    // Anything else (PPT, ZIP, …)
    this.viewerMode = "unsupported";
  }

  // ── DOCX rendering via docx-preview ──────────────────────────────────────
  private renderDocx(blob: Blob): void {
    if (!this.docxContainerRef) return;
    const container = this.docxContainerRef.nativeElement;

    renderAsync(blob, container, undefined, {
      className: "docx",
      inWrapper: true, // wraps pages in a document-viewer shell
      ignoreWidth: false,
      ignoreHeight: false,
      ignoreFonts: false,
      breakPages: true, // show page breaks visually
      ignoreLastRenderedPageBreak: true,
      experimental: true,
      trimXmlDeclaration: true,
      useBase64URL: true,
    })
      .then(() => {
        this.cdr.detectChanges();
      })
      .catch(err => {
        console.error("[FileViewer] DOCX render failed:", err);
        this.viewerMode = "unsupported";
        this.docxBlob = null;
        this.cdr.detectChanges();
      });
  }

  // ── XLSX HTML wrapper ─────────────────────────────────────────────────────
  private workbookToHtml(wb: XLSX.WorkBook, images: string[] = []): string {
    const names = wb.SheetNames;
    const tabs = names
      .map(
        (n, i) =>
          `<button onclick="show(${i})" id="t${i}" style="padding:5px 14px;border:none;cursor:pointer;border-radius:4px 4px 0 0;font-size:12px;background:${i === 0 ? "#3b82f6" : "#e5e7eb"};color:${i === 0 ? "#fff" : "#374151"}">${n}</button>`
      )
      .join(" ");

    const sheets = names
      .map((n, i) => {
        const html = XLSX.utils.sheet_to_html(wb.Sheets[n]);
        return `<div id="s${i}" style="display:${i === 0 ? "block" : "none"}">${html}</div>`;
      })
      .join("");

    const imagesHtml =
      images.length > 0
        ? `<div style="display:flex;flex-wrap:wrap;gap:8px;padding:8px 12px;border-bottom:1px solid #e5e7eb;background:#fafafa;">
               ${images.map(src => `<img src="${src}" style="max-height:72px;max-width:200px;object-fit:contain;" />`).join("")}
             </div>`
        : "";

    return `<!DOCTYPE html><html><head><meta charset="UTF-8"><style>
          *{box-sizing:border-box}
          body{font-family:Arial,sans-serif;font-size:12px;margin:0;background:#fff}
          .tabs{padding:8px 10px 0;background:#f9fafb;border-bottom:2px solid #e5e7eb;display:flex;gap:4px;overflow-x:auto}
          .content{padding:12px;overflow:auto}
          table{border-collapse:collapse}
          td,th{border:1px solid #d1d5db;padding:4px 8px;white-space:nowrap}
          th{background:#f3f4f6;font-weight:600}
          tr:nth-child(even) td{background:#f9fafb}
        </style></head><body>
          ${imagesHtml}
          <div class="tabs">${tabs}</div>
          <div class="content">${sheets}</div>
          <script>
            function show(i){
              var total=${names.length};
              for(var j=0;j<total;j++){
                document.getElementById('s'+j).style.display=j===i?'block':'none';
                var btn=document.getElementById('t'+j);
                btn.style.background=j===i?'#3b82f6':'#e5e7eb';
                btn.style.color=j===i?'#fff':'#374151';
              }
            }
          </script>
        </body></html>`;
  }

  // ── Extract embedded images from XLSX (ZIP) archive ───────────────────────
  /**
   * An XLSX file is a ZIP archive. Images are stored under xl/media/.
   * We walk the ZIP central directory, locate image entries, decompress them
   * (deflate-raw via the browser's DecompressionStream API), and return
   * data URLs suitable for <img src="..."> usage.
   */
  private async extractXlsxImages(buffer: ArrayBuffer): Promise<string[]> {
    const bytes = new Uint8Array(buffer);
    const view = new DataView(buffer);
    const results: string[] = [];

    // 1. Locate the End Of Central Directory record (signature 0x06054b50)
    let eocd = -1;
    const searchStart = Math.max(0, bytes.length - 65558); // max comment = 65535 bytes
    for (let i = bytes.length - 22; i >= searchStart; i--) {
      if (view.getUint32(i, true) === 0x06054b50) {
        eocd = i;
        break;
      }
    }
    if (eocd < 0) return results; // not a valid ZIP

    const cdOffset = view.getUint32(eocd + 16, true);
    let pos = cdOffset;

    // 2. Walk Central Directory entries
    while (pos + 46 <= bytes.length) {
      if (view.getUint32(pos, true) !== 0x02014b50) break; // PK\x01\x02

      const compMethod = view.getUint16(pos + 10, true);
      const compSize = view.getUint32(pos + 20, true);
      const uncompSize = view.getUint32(pos + 24, true);
      const fnLen = view.getUint16(pos + 28, true);
      const extraLen = view.getUint16(pos + 30, true);
      const commentLen = view.getUint16(pos + 32, true);
      const lhOffset = view.getUint32(pos + 42, true);
      const entryName = new TextDecoder().decode(bytes.subarray(pos + 46, pos + 46 + fnLen));

      if (/^xl\/media\/.+\.(jpe?g|png|gif|bmp)$/i.test(entryName)) {
        // 3. Read Local File Header to find actual data start
        const lhFnLen = view.getUint16(lhOffset + 26, true);
        const lhExtraLen = view.getUint16(lhOffset + 28, true);
        const dataStart = lhOffset + 30 + lhFnLen + lhExtraLen;

        let imgBytes: Uint8Array | null = null;

        if (compMethod === 0) {
          // Stored — no compression
          imgBytes = bytes.subarray(dataStart, dataStart + uncompSize);
        } else if (compMethod === 8) {
          // Deflated — decompress with browser's DecompressionStream
          try {
            const ds = new DecompressionStream("deflate-raw");
            const writer = ds.writable.getWriter();
            const reader = ds.readable.getReader();
            writer.write(bytes.subarray(dataStart, dataStart + compSize));
            writer.close();
            const chunks: Uint8Array[] = [];
            while (true) {
              const { value, done } = await reader.read();
              if (done) break;
              if (value) chunks.push(value);
            }
            const total = chunks.reduce((s, c) => s + c.length, 0);
            imgBytes = new Uint8Array(total);
            let off = 0;
            for (const c of chunks) {
              imgBytes.set(c, off);
              off += c.length;
            }
          } catch {
            // decompression failed — skip this entry
          }
        }

        if (imgBytes) {
          const mimeExt = entryName.toLowerCase().endsWith(".png")
            ? "png"
            : entryName.toLowerCase().endsWith(".gif")
              ? "gif"
              : "jpeg";
          // Build base64 in chunks to avoid call-stack overflow on large images
          let binary = "";
          const chunk = 8192;
          for (let i = 0; i < imgBytes.length; i += chunk) {
            binary += String.fromCharCode(
              ...imgBytes.subarray(i, Math.min(i + chunk, imgBytes.length))
            );
          }
          results.push(`data:image/${mimeExt};base64,${btoa(binary)}`);
        }
      }

      pos += 46 + fnLen + extraLen + commentLen;
    }

    return results;
  }

  private setBlobUrl(blob: Blob): void {
    this.blobUrl = URL.createObjectURL(blob);
    this.safeUrl = this.sanitizer.bypassSecurityTrustResourceUrl(this.blobUrl);
  }

  private setOriginalBlobUrl(blob: Blob): void {
    if (this.originalBlobUrl) {
      URL.revokeObjectURL(this.originalBlobUrl);
    }
    this.originalBlobUrl = URL.createObjectURL(blob);
  }

  // ── Actions ─────────────────────────────────────────────────────────────
  download(): void {
    const url = this.originalBlobUrl ?? this.blobUrl;
    if (!url) return;
    this.fileDownload.downloadFromObjectUrl(url, this.displayName);
  }

  openInNewTab(): void {
    if (this.blobUrl) window.open(this.blobUrl, "_blank");
  }

  close(): void {
    this.visibleChange.emit(false);
  }

  onOverlayClick(e: MouseEvent): void {
    if ((e.target as HTMLElement).classList.contains("fv__overlay")) {
      this.close();
    }
  }

  // ── Helpers ─────────────────────────────────────────────────────────────
  get displayName(): string {
    return this.originalName || this.fileName || "Document";
  }

  get ext(): string {
    const name = this.originalName || this.fileName || "";
    const parts = name.split(".");
    return parts.length > 1 ? parts[parts.length - 1].toLowerCase() : "";
  }

  get fileTypeInfo(): { icon: string; color: string; label: string } {
    const e = this.ext;
    if (e === "pdf") return { icon: "pi pi-file", color: "#ef4444", label: "PDF" };
    if (["doc", "docx"].includes(e)) return { icon: "pi pi-file", color: "#3b82f6", label: "Word" };
    if (["xls", "xlsx"].includes(e))
      return { icon: "pi pi-file", color: "#22c55e", label: "Excel" };
    if (["ppt", "pptx"].includes(e)) return { icon: "pi pi-file", color: "#f97316", label: "PPT" };
    if (["jpg", "jpeg", "png", "gif", "webp", "svg"].includes(e))
      return { icon: "pi pi-image", color: "#a855f7", label: "Image" };
    if (["zip", "rar", "7z"].includes(e))
      return { icon: "pi pi-file", color: "#6b7280", label: "ZIP" };
    if (["txt", "csv"].includes(e)) return { icon: "pi pi-file", color: "#0ea5e9", label: "Text" };
    return { icon: "pi pi-file", color: "#6b7280", label: e.toUpperCase() || "Fichier" };
  }

  get canOpenNewTab(): boolean {
    return this.viewerMode === "iframe" || this.viewerMode === "image";
  }

  private resetState(): void {
    this.isLoading = false;
    this.error = null;
    this.viewerMode = null;
    this.safeUrl = null;
    this.docxBlob = null;
    this.revokeBlobUrl();
  }

  private revokeBlobUrl(): void {
    if (this.blobUrl) {
      URL.revokeObjectURL(this.blobUrl);
      this.blobUrl = null;
    }
    if (this.originalBlobUrl) {
      URL.revokeObjectURL(this.originalBlobUrl);
      this.originalBlobUrl = null;
    }
  }

  private lockScroll(lock: boolean): void {
    document.body.style.overflow = lock ? "hidden" : "";
  }
}
