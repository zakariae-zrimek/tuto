import { Component, EventEmitter, Input, Output } from "@angular/core";
import { PageAction } from "../listing/listing.types";

@Component({
  selector: "alexsys-section-header",
  standalone: false,
  templateUrl: "./section-header.component.html",
})
export class SectionHeaderComponent {
  @Input() title = "";
  @Input() actions: PageAction[] = [];

  @Output() action = new EventEmitter<string>();

  onAction(id: string) {
    this.action.emit(id);
  }

  btnVariant(a: PageAction) {
    // keep it simple and consistent
    if (a.variant === "primary") return "default";
    if (a.variant === "outline") return "outline";
    if (a.variant === "ghost") return "ghost";
    return "secondary";
  }
}
