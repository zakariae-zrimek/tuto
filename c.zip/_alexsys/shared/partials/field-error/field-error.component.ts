import { Component, Input } from "@angular/core";
import { AbstractControl } from "@angular/forms";

@Component({
  selector: "alexsys-field-error",
  standalone: false,
  templateUrl: "./field-error.component.html",
  styleUrl: "./field-error.component.scss",
})
export class FieldErrorComponent {
  @Input() control: AbstractControl | null = null;

  get errorMessage(): string | null {
    if (!this.control?.errors || !this.control?.touched) return null;

    const errors = this.control.errors;

    if (errors["required"]) return "Ce champ est requis.";
    if (errors["minlength"])
      return `Minimum ${errors["minlength"].requiredLength} caractères requis.`;
    if (errors["maxlength"])
      return `Maximum ${errors["maxlength"].requiredLength} caractères autorisés.`;
    if (errors["email"]) return "Adresse e-mail invalide.";
    if (errors["pattern"]) return "Format invalide.";
    if (errors["min"]) return `La valeur doit être ≥ ${errors["min"].min}.`;
    if (errors["max"]) return `La valeur doit être ≤ ${errors["max"].max}.`;

    // Validateurs métier personnalisés
    if (errors["montantRequis"]) return "Le montant doit être supérieur à 0.";
    if (errors["montantNegatif"]) return "Le montant ne peut pas être négatif.";
    if (errors["ttcInferieurHt"]) return "Le montant TTC doit être supérieur ou égal au montant HT.";
    if (errors["pourcentageInvalide"]) return "Le pourcentage doit être compris entre 0 et 100.";
    if (errors["entierRequis"]) return "Veuillez saisir un nombre entier (sans décimale).";
    if (errors["champVide"]) return "Ce champ ne peut pas être vide ou contenir uniquement des espaces.";
    if (errors["minActeDate"]) return "La date doit être postérieure ou égale à la date de début de l'acte.";
    if (errors["dateCoherence"]) return "La date de fin doit être postérieure à la date de début.";
    if (errors["duplicate"]) return "Une ou plusieurs lignes sont déjà affectées à une autre réception.";
    if (errors["sommePourcentages"]) return "La somme des pourcentages dépasse 100 %. Veuillez ajuster les valeurs.";
    if (errors["valeurCautionRequise"]) return "La valeur de caution doit être supérieure à 0.";
    if (errors["dureeMin"]) return "La durée doit être d'au moins 1.";

    return "Champ invalide.";
  }
}
