export type Align = "left" | "center" | "right";
export type FilterType = "search" | "select" | "dateRange";
export type CellType = "text" | "badge" | "list" | "count" | "links" | "actions";

export interface SelectOption<V = any> {
    label: string;
    value: any;
}

export type MenuAction<T> =
    | { separator: true }
    | { id: string; label: string; icon?: string; visible?: (row: T) => boolean; disabled?: (row: T) => boolean };


export interface FilterDefBase {
    key: string;
    label: string;
    placeholder?: string;
    widthClass?: string; // tailwind helper per field (optional)
}

export interface SearchFilterDef extends FilterDefBase {
    type: "search";
    debounceMs?: number; // default to 500
}

export interface SelectFilterDef<V = any> extends FilterDefBase {
    type: "select";
    options: SelectOption<V>[];
}

export interface DateRangeFilterDef extends FilterDefBase {
    type: "dateRange";
    placeholderFrom?: string;
    placeholderTo?: string;
}

export type FilterDef = SearchFilterDef | SelectFilterDef<any> | DateRangeFilterDef;

export interface PageAction {
    id: string;
    label: string;
    icon?: string;
    variant?: "primary" | "secondary" | "outline" | "ghost" | "outline-primary";
    disabled?: boolean;
}

export interface RowActionDef<T> {
    id: string;
    label: string;
    icon?: string;
    visible?: (row: T) => boolean;
    disabled?: (row: T) => boolean;
}

export interface TableColumnDef<T> {
    header: string;
    key?: keyof T & string; // simple field
    valueGetter?: (row: T) => any; // computed
    cellType?: CellType;
    width?: string;
    align?: Align;

    // formatting
    formatter?: (value: any, row: T) => string;

    // badge
    badgeClassFn?: (value: any, row: T) => string;

    // links
    linkActionId?: string;

    // actions
    actions?: {
        view?: boolean;
        edit?: boolean;
        menu?: RowActionDef<T>[];
    };
    id?: string;
    hideable?: boolean;
    visibleByDefault?: boolean;
}

export interface TableActionEvent<T> {
    id: string;
    row: T;
    payload?: any;
}
