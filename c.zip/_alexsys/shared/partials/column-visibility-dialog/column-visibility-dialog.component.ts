import {
  ChangeDetectionStrategy,
  Component,
  EventEmitter,
  Input,
  OnChanges,
  Output,
  SimpleChanges,
} from "@angular/core";
import {
  ColumnGroupDef,
  ColumnVisibilityState,
} from "./column-visibility-dialog.types";
import {
  ColumnPrefsScope,
  TableColumnPrefsService,
} from "../../services/table-column-prefs.service";

type GroupVm = {
  groupKey: string;
  label: string;
  open: boolean;
  columnIds: string[];
};

@Component({
  selector: "alexsys-column-visibility-dialog",
  templateUrl: "./column-visibility-dialog.component.html",
  standalone : false,
  styleUrls: ["./column-visibility-dialog.component.scss"],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ColumnVisibilityDialogComponent implements OnChanges {
  /** Required: groups = actes/receptions/pvs/factures */
  @Input({ required: true }) groups: ColumnGroupDef[] = [];

  /** Required: { userKey: keycloakUserId, screenKey: "traitement-actes" } */
  @Input({ required: true }) scope!: ColumnPrefsScope;

  /**
   * If you want the parent to control open/close via dialog-wrapper,
   * you can set this. Otherwise ignore and just use the component inside your wrapper.
   */
  @Input() visible = true;

  @Output() cancel = new EventEmitter<void>();
  @Output() apply = new EventEmitter<ColumnVisibilityState>();

  /** Working copy (edited in dialog, applied only on Apply) */
  state: ColumnVisibilityState = {};

  /** Snapshot for "Annuler" behavior (restore) */
  private initialState: ColumnVisibilityState = {};

  groupVm: GroupVm[] = [];

  constructor(private prefs: TableColumnPrefsService) {}

  ngOnChanges(changes: SimpleChanges): void {
    if (changes["groups"] || changes["scope"]) {
      this.rebuildVmAndLoadState();
    }
  }

  private rebuildVmAndLoadState(): void {
    // Build VM first (stable ordering)
    this.groupVm = (this.groups ?? []).map((g) => ({
      groupKey: g.groupKey,
      label: g.label,
      open: false,
      columnIds: (g.columns ?? []).map((c) => c.id),
    }));

    // Load persisted state and merge with current columns
    const persisted = this.prefs.read(this.scope) ?? {};
    const next: ColumnVisibilityState = {};

    for (const g of this.groupVm) {
      next[g.groupKey] = this.prefs.getEffectiveVisibilityForGroup(
        this.scope,
        g.groupKey,
        g.columnIds,
        true
      );
      // If persisted had extra columns that no longer exist, they’re dropped here.
    }

    this.state = this.cloneState(next);
    this.initialState = this.cloneState(next);
  }

  // UI helpers
  toggleGroup(groupKey: string): void {
    const g = this.groupVm.find((x) => x.groupKey === groupKey);
    if (g) g.open = !g.open;
  }

  isChecked(groupKey: string, columnId: string): boolean {
    return !!this.state?.[groupKey]?.[columnId];
  }

  setChecked(groupKey: string, columnId: string, checked: boolean): void {
    const group = (this.state[groupKey] ??= {});
    group[columnId] = checked;
  }

  visibleCount(groupKey: string): number {
    const group = this.state[groupKey] ?? {};
    return Object.values(group).filter(Boolean).length;
  }

  totalCount(groupKey: string): number {
    return Object.keys(this.state[groupKey] ?? {}).length;
  }

  // Group actions
  selectAllInGroup(groupKey: string): void {
    const group = this.state[groupKey];
    if (!group) return;
    for (const k of Object.keys(group)) group[k] = true;
  }

  deselectAllInGroup(groupKey: string): void {
    const group = this.state[groupKey];
    if (!group) return;
    for (const k of Object.keys(group)) group[k] = false;
  }

  // Global actions
  selectAll(): void {
    for (const g of Object.keys(this.state)) this.selectAllInGroup(g);
  }

  resetToDefault(): void {
    // Default = all visible for current columns
    const defaults = this.prefs.buildDefaultState(
      this.groupVm.map((g) => ({ groupKey: g.groupKey, columnIds: g.columnIds }))
    );
    this.state = this.cloneState(defaults);
  }

  onCancel(): void {
    // restore initial and notify
    this.state = this.cloneState(this.initialState);
    this.cancel.emit();
  }

  onApply(): void {
    // Persist full state for this screen/user
    this.prefs.write(this.scope, this.state);
    this.initialState = this.cloneState(this.state);
    this.apply.emit(this.state);
  }

  private cloneState(s: ColumnVisibilityState): ColumnVisibilityState {
    const out: ColumnVisibilityState = {};
    for (const g of Object.keys(s ?? {})) out[g] = { ...(s[g] ?? {}) };
    return out;
  }

  // Convenience for template
  columnsOf(groupKey: string) {
    return this.groups.find((g) => g.groupKey === groupKey)?.columns ?? [];
  }
}
