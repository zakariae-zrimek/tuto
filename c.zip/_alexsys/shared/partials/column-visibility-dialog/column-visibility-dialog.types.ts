import { ColumnDef } from "../expandable-table/expandable-table.types";

export type ColumnVisibilityMap = Record<string, boolean>; // columnId -> visible

export type ColumnGroupDef<T = any> = {
  groupKey: string; // "actes" | "receptions" | ...
  label: string;    // displayed label
  columns: ColumnDef<T>[];
};

export type ColumnVisibilityState = Record<string, ColumnVisibilityMap>; // groupKey -> map

export type ColumnVisibilityDialogResult = {
  applied: boolean;
  state: ColumnVisibilityState;
};
