import { Component, EventEmitter, Input, OnChanges, Output, SimpleChanges } from "@angular/core";
import { MenuItem } from "primeng/api";
import { TableActionEvent, TableColumnDef } from "../listing/listing.types";

@Component({
    selector: "alexsys-list-table",
    standalone: false,
    templateUrl: "./list-table.component.html",
})
export class ListTableComponent<T extends Record<string, any>> implements OnChanges {
    @Input() columns: TableColumnDef<T>[] = [];
    @Input() rows: T[] = [];

    @Input() enableColumnChooser = false;
    @Input() columnChooserLabel = "Colonnes";
    @Input() persistKey?: string; // optional for later localStorage

    @Output() action = new EventEmitter<TableActionEvent<T>>();
    @Input() emptyMessage = "Aucune donnée à afficher.";

    visibleColumnIds = new Set<string>();
    chooserItems: MenuItem[] = [];

    ngOnChanges(changes: SimpleChanges): void {
        if (changes["columns"]) {
            this.initColumnVisibility();
            this.buildChooserItems();
        }
    }

    get visibleColumns(): TableColumnDef<T>[] {
        if (!this.enableColumnChooser) return this.columns;
        return this.columns.filter(c => this.visibleColumnIds.has(this.colId(c)));
    }

    private initColumnVisibility(): void {
        if (!this.enableColumnChooser) return;

        this.visibleColumnIds.clear();

        for (const c of this.columns) {
            const isAction = c.cellType === "actions";
            const hideable = c.hideable ?? !isAction; // actions column not hideable by default
            const visible = c.visibleByDefault ?? true;

            if (!hideable) {
                this.visibleColumnIds.add(this.colId(c));
            } else if (visible) {
                this.visibleColumnIds.add(this.colId(c));
            }
        }
    }

    private buildChooserItems(): void {
        if (!this.enableColumnChooser) {
            this.chooserItems = [];
            return;
        } this.chooserItems = this.columns.map(col => {
            const id = this.colId(col);
            const isAction = col.cellType === "actions";
            const hideable = col.hideable ?? !isAction;

            return {
                label: col.header,
                // PrimeNG menu supports checkbox-like items by using `items` with custom template or `p-menu` isn't ideal.
                // We'll use overlay panel with p-checkbox in template instead (cleaner).
                // So this is unused if you choose OverlayPanel solution.
            };
        });
    }
    showAllColumns(): void {
        for (const c of this.columns) {
            if (this.isHideable(c)) this.toggleColumn(c, true);
        }
    }
    hideAllColumns(): void {
        // keep at least one non-action column visible
        const hideable = this.columns.filter(c => this.isHideable(c));
        const keepOne = hideable.find(c => c.cellType !== "actions") ?? hideable[0];

        for (const c of hideable) {
            const mustKeep = keepOne && this.colId(c) === this.colId(keepOne);
            this.toggleColumn(c, !mustKeep ? false : true);
        }
    }



    colId(col: TableColumnDef<T>): string {
        return col.id || col.key || col.header;
    }

    isChecked(col: TableColumnDef<T>): boolean {
        return this.visibleColumnIds.has(this.colId(col));
    }

    isHideable(col: TableColumnDef<T>): boolean {
        const isAction = col.cellType === "actions";
        return col.hideable ?? !isAction;
    }

    toggleColumn(col: TableColumnDef<T>, checked: boolean): void {
        const id = this.colId(col);

        if (!this.isHideable(col)) return;

        if (checked) this.visibleColumnIds.add(id);
        else this.visibleColumnIds.delete(id);
    }

    getValue(col: TableColumnDef<T>, row: T): any {
        if (col.valueGetter) return col.valueGetter(row);
        if (col.key) return row[col.key];
        return null;
    }

    alignClass(col: TableColumnDef<T>): string {
        const a = col.align ?? "left";
        if (a === "center") return "text-center";
        if (a === "right") return "text-right";
        return "text-left";
    }

    toMenuItems(col: TableColumnDef<T>, row: T): MenuItem[] {
        const defs = col.actions?.menu ?? [];

        return defs
            .map(d => {
                // separator row
                if ((d as any).separator) {
                    return { separator: true } as MenuItem;
                }

                // normal action row
                const action = d as any;

                if (action.visible && !action.visible(row)) return null;

                return {
                    label: action.label,
                    icon: action.icon,
                    disabled: action.disabled ? action.disabled(row) : false,
                    data: { id: action.id },
                } as MenuItem;
            })
            .filter((x): x is MenuItem => !!x);
    }


    emit(id: string, row: T, payload?: any) {
        this.action.emit({ id, row, payload });
    }
    badgeClass(col: TableColumnDef<T>, row: T): string {
        const v = this.getValue(col, row);
        return col.badgeClassFn ? col.badgeClassFn(v, row) : "bg-gray-100 text-gray-800";
    }

}
