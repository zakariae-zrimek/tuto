import { Component, Input } from "@angular/core";
import { SplashScreenService } from "./splash-screen.service";

@Component({
  selector: "alexsys-splash-screen",
  templateUrl: "./splash-screen.component.html",
  styleUrls: ["./splash-screen.component.scss"],
  standalone: false,
})
export class SplashScreenComponent {
  constructor(public splash: SplashScreenService) {}

  // Optional customization without changing how the service works
  @Input() title = "Chargement en cours...";
  @Input() subtitle = "Merci de patienter quelques instants.";
}
