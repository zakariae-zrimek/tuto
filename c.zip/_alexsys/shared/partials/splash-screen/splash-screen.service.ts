import { Injectable } from "@angular/core";
import { BehaviorSubject } from "rxjs";
import { finalize, Observable } from "rxjs";

@Injectable({ providedIn: "root" })
export class SplashScreenService {
  visibleSubject = new BehaviorSubject<boolean>(true);
  visible$ = this.visibleSubject.asObservable();
  private pendingCount = 1;

  show(): void {
    this.pendingCount += 1;
    this.visibleSubject.next(true);
  }

  hide(): void {
    this.pendingCount = Math.max(0, this.pendingCount - 1);
    this.visibleSubject.next(this.pendingCount > 0);
  }

  track<T>(source$: Observable<T>): Observable<T> {
    this.show();
    return source$.pipe(finalize(() => this.hide()));
  }
}
