import { Component, Input, TemplateRef } from "@angular/core";

export interface TableCellContext<T> {
  $implicit: T[keyof T]; // the cell value
  row: T; // the full row
}

export interface TableColumn<T> {
  field: keyof T & string;
  header: string;
  template?: TemplateRef<TableCellContext<T>>;
}

@Component({
  selector: "alexsys-data-table",
  standalone: false,
  templateUrl: "./data-table.component.html",
})
export class DataTableComponent<T> {
  @Input() columns: TableColumn<T>[] = [];
  @Input() data: T[] = [];
  @Input() loading = false;
  @Input() loadingLabel = "Chargement en cours...";
  @Input() expandable = false;
  // 🔹 Important: Use `null` instead of `undefined`
  @Input() rowTemplate: TemplateRef<{ row: T }> | null = null;
  @Input() emptyMessage = "Aucune donnée à afficher.";

  expandedRow: T | null = null;

  toggleRow(row: T) {
    this.expandedRow = this.expandedRow === row ? null : row;
  }
}
