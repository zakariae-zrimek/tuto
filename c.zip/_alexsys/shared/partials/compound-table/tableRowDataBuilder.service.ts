// row-builder.service.ts
import { Injectable } from "@angular/core";
import {
  TableRow,
  ExpandedRowContent,
  ExpansionRule,
  DropdownItem,
  TableColumn,
} from "./compound-table.types";

@Injectable({ providedIn: "root" })
export class TableRowDataBuilderService {
  /**
   * Creates a TableRow<T> from raw data based on rules
   * @param data Row data
   * @param rules Expansion rules
   * @param mainColumns Optional: columns for main table
   */
  createRow<T>(data: T, rules: ExpansionRule[] = [], mainColumns?: TableColumn<T>[]): TableRow<T> {
    const row: TableRow<T> = {
      id: (data as { id?: string | number }).id,
      data,
      expandable: false,
      expanded: false,
    };

    // Assign main table columns if provided
    // Assign main table columns if provided
    if (mainColumns) {
      (row as any).columns = mainColumns;

      // ✅ Initialize header & row functions for "select" column if present
      mainColumns.forEach(col => {
        if (col.key === "select" && col.selectable) {
          // Optional: attach default noop functions if none provided
          col.selectable.headerCheckboxFn = col.selectable.headerCheckboxFn ?? (() => false);
          col.selectable.onHeaderCheckboxToggle =
            col.selectable.onHeaderCheckboxToggle ?? (() => {});
          col.selectable.rowCheckboxStateFn = col.selectable.rowCheckboxStateFn ?? (() => false);
          col.selectable.onRowCheckboxToggle = col.selectable.onRowCheckboxToggle ?? (() => {});
        }
      });
    }

    const dropdownItems: DropdownItem<unknown>[] = [];

    for (const rule of rules) {
      const childData = (data as any)[rule.key];
      if (!childData) continue;

      // Handle array children
      if (Array.isArray(childData)) {
        const rows = this.createRows(childData, rule.children ?? []);

        const tableContent: ExpandedRowContent<any> = {
          type: "table",
          columns: rule.columns ?? this.buildDefaultColumns(childData),
          rows,
        };

        if (rule.type === "dropdown") {
          dropdownItems.push({
            title: rule.title ?? rule.key,
            expanded: false,
            showRowCount: rule.showRowCount,
            content: tableContent,
            header: rule.header,
          });
        } else {
          row.expandedContent = tableContent;
          row.expandable = true;
        }
      }

      // Handle component child
      else if (rule.type === "component" && rule.component) {
        const compContent: ExpandedRowContent<any> = {
          type: "component",
          component: rule.component,
          context: rule.context,
        };
        row.expandedContent = compContent;
        row.expandable = true;
      }
    }

    if (dropdownItems.length) {
      row.expandedContent = { type: "dropdown", items: dropdownItems };
      row.expandable = true;
    }

    return row;
  }

  createRows<T>(
    data: T[],
    rules: ExpansionRule[] = [],
    mainColumns?: TableColumn<T>[]
  ): TableRow<T>[] {
    return data.map(item => this.createRow(item, rules, mainColumns));
  }

  private buildDefaultColumns<T extends object>(data: T[]): TableColumn<T>[] {
    const first = data[0];
    if (!first) return [];

    return Object.keys(first).map(key => ({
      key: key as keyof T,
      header: this.capitalize(key), // optional nicer label
      label: this.capitalize(key),
    }));
  }

  private capitalize(value: string): string {
    return value.charAt(0).toUpperCase() + value.slice(1);
  }
}
