import { Component, Input, Type, Injector, TemplateRef } from "@angular/core";
import {
  TableColumn,
  TableRow,
  ExpandedRowContent,
  DropdownItem,
  SpecialColumnKey,
} from "./compound-table.types";

@Component({
  selector: "alexsys-compound-table",
  templateUrl: "./compound-table.component.html",
  styleUrls: ["./compound-table.component.scss"],
  standalone: false,
})
export class CompoundTableComponent<T> {
  @Input() columns: TableColumn<T>[] = [];
  @Input() rows: TableRow<T>[] = [];
  /**
   * Optional template injected above the table.
   * Can be a filter section, action buttons, etc.
   */
  @Input() headerTemplate?: TemplateRef<any>;

  toggleRow(row: TableRow<T>) {
    row.expanded = !row.expanded;
  }

  toggleItem(item: DropdownItem<unknown>) {
    item.expanded = !item.expanded;
  }

  isDataKey(key: keyof T | SpecialColumnKey | unknown): key is keyof T & string {
    return key !== "expand" && key !== "actions";
  }

  isComponentContent(
    content: ExpandedRowContent<unknown> | undefined
  ): content is { type: "component"; component: Type<unknown>; context?: Injector } {
    return !!content && content.type === "component";
  }

  isTableContent(
    content: ExpandedRowContent<unknown>
  ): content is { type: "table"; columns: TableColumn<unknown>[]; rows: TableRow<unknown>[] } {
    return !!content && content.type === "table";
  }

  isDropdownContent(
    content: ExpandedRowContent<unknown>
  ): content is { type: "dropdown"; items: DropdownItem<unknown>[] } {
    return !!content && content.type === "dropdown";
  }
}
