import { TemplateRef, Type, Injector } from "@angular/core";

/** Context passed to cell templates that render a single cell value */
export interface CellTemplateContext<T> {
  $implicit: T[keyof T]; // the cell value
  row: T; // the full row data
}

/** Context passed to action templates that need the whole row */
export interface ActionTemplateContext<T> {
  $implicit: T; // the full row
  row: T; // the full row data
}

/** Special column keys that are not in the row data */
export type SpecialColumnKey = "expand" | "actions" | "select";

/** Column configuration */
export interface TableColumn<T> {
  /** Data key or special key */
  key: (keyof T & string) | SpecialColumnKey | unknown;
  header: string;
  width?: string;
  class?: string;
  /** Marks column as an action column */
  isAction?: boolean;
  /** Template for custom rendering of this column (data or actions) */
  cellTemplate?: TemplateRef<CellTemplateContext<T> | ActionTemplateContext<T>>;

  /** Or: declarative list of actions (inline buttons) */
  actions?: TableAction<T>[];
  /** Optional formatter for default text rendering */
  format?: (value: T[keyof T], row: T) => string | number;

  /** If true, renders a badge */
  isBadge?: boolean;

  /** Badge resolver function (if isBadge = true) */
  getClassFn?: (val: any) => string;

  selectable?: SelectColumn<T>;
}

export interface TableAction<T> {
  label: string;
  icon?: string;
  class?: string;
  visible?: (row: T) => boolean;
  onClick: (row: T) => void | Promise<void>;
}

/** One rendered row in the table */
export interface TableRow<T> {
  id?: string | number;
  data: T;
  expandable?: boolean;
  expanded?: boolean;
  expandedContent?: ExpandedRowContent<unknown>;
}

/** What appears when a row is expanded */
export type ExpandedRowContent<T> =
  | { type: "table"; columns: TableColumn<T>[]; rows: TableRow<T>[] }
  | { type: "dropdown"; items: DropdownItem<T>[] }
  | { type: "component"; component: Type<unknown>; context?: Injector };

/** Dropdown entry in expanded content */
export interface DropdownItem<T> {
  title: string;
  content: ExpandedRowContent<T>;
  expanded: boolean;
  showRowCount?: boolean;
  /** Optional custom header above table/component */
  header?: DropdownHeader;
}

export interface ExpansionRule {
  /** Key in the data object to look for (e.g. "children", "orders", etc.) */
  key: string;

  /** How this key should expand */
  type: "table" | "dropdown" | "component";

  /** Optional title (used for dropdown items) */
  title?: string;

  /** For type=table: which columns to show */
  columns?: TableColumn<any>[];

  /** For type=component: which component to render */
  component?: Type<unknown>;

  /** For type=component: optional injector context */
  context?: Injector;

  /** Nested expansion rules to apply inside child rows */
  children?: ExpansionRule[];

  /** Show number of rows in dropdown title */
  showRowCount?: boolean;

  /** Optional custom header for dropdowns */
  header?: DropdownHeader;
}

export interface SelectColumn<T> {
  /** Header checkbox */
  headerCheckboxFn?: () => boolean; // header checked state
  onHeaderCheckboxToggle?: (checked: boolean) => void; // header toggle event
  headerCheckboxDisabledFn?: () => boolean; // header disabled

  /** Row checkbox */
  rowCheckboxStateFn?: (row: T) => boolean; // row checked state
  onRowCheckboxToggle?: (row: T, checked: boolean) => void; // row toggle event
  rowCheckboxDisabledFn?: (row: T) => boolean; // row disabled
}

export interface DropdownHeader {
  /** Template for the header (Angular TemplateRef) */
  template?: TemplateRef<any>;

  /** Component for the header (Angular Component) */
  component?: Type<unknown>;

  /** Optional context to pass to the component/template */
  context?: any;
}
