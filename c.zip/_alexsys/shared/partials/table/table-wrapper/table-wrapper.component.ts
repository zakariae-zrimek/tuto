import { Component, Input } from "@angular/core";

@Component({
  selector: "alexsys-table-wrapper",
  standalone: false,
  templateUrl: "./table-wrapper.component.html",
  styleUrl: "./table-wrapper.component.scss",
})
export class TableWrapperComponent {
  /** classes applied to <table> */
  @Input() class = "";

  /** classes applied to the outer “card” wrapper */
  @Input() wrapperClass = "";
}
