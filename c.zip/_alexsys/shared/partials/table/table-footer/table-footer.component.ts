import { Component, Input } from '@angular/core';

@Component({
  selector: 'alexsys-table-footer',
  standalone: false,
  templateUrl: './table-footer.component.html',
  styleUrl: './table-footer.component.scss'
})
export class TableFooterComponent {
  @Input() class = "";
}
