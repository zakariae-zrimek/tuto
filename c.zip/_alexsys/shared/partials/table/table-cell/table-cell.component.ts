import { Component, Input } from '@angular/core';

@Component({
  selector: 'alexsys-table-cell',
  standalone: false,
  templateUrl: './table-cell.component.html',
  styleUrl: './table-cell.component.scss'
})
export class TableCellComponent {
  @Input() class = "";
  @Input() colspan: number | null = null;
}
