import { Component, Input } from "@angular/core";

type TableRowVariant = "body" | "header" | "detail";

@Component({
  selector: "alexsys-table-row",
  standalone: false,
  templateUrl: "./table-row.component.html",
  styleUrl: "./table-row.component.scss",
})
export class TableRowComponent {
  @Input() class = "";
  @Input() selected = false;
  @Input() variant: "body" | "header" | "detail" = "body";
  
  get classes(): string[] {
    const base: string[] = [];

    if (this.variant === "body") {
      base.push("border-b", "border-gray-200", "transition-colors", "hover:bg-gray-50");
    }

    if (this.selected) base.push("bg-gray-100");

    if (this.class) base.push(this.class);

    return base;
  }
}
