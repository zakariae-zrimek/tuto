import { Component, Input } from "@angular/core";

@Component({
  selector: "alexsys-table-header",
  standalone: false,
  templateUrl: "./table-header.component.html",
  styleUrl: "./table-header.component.scss",
})
export class TableHeaderComponent {
  @Input() class = "";
}
