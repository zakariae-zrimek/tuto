import { Component, Input } from '@angular/core';

@Component({
  selector: 'alexsys-table-head',
  standalone: false,
  templateUrl: './table-head.component.html',
  styleUrl: './table-head.component.scss'
})
export class TableHeadComponent {
  @Input() class = "";
}
