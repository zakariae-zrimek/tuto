import { Component, Input } from '@angular/core';

@Component({
  selector: 'alexsys-table-body',
  standalone: false,
  templateUrl: './table-body.component.html',
  styleUrl: './table-body.component.scss'
})
export class TableBodyComponent {
  @Input() class = "";
}
