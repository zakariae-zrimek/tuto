import {
  ChangeDetectionStrategy,
  ChangeDetectorRef,
  Component,
  ElementRef,
  EventEmitter,
  HostListener,
  Input,
  OnChanges,
  Output,
  SimpleChanges,
  inject,
} from "@angular/core";
import { ExpandableCardDef, CardExpandedChange } from "./expandable-cards.types";
import { TableCtx, RowKey } from "../expandable-table/expandable-table.types";

type LoadState = "idle" | "loading" | "loaded" | "error";

@Component({
  selector: "alexsys-expandable-cards",
  standalone: false,
  templateUrl: "./expandable-cards.component.html",
  styleUrls: ["./expandable-cards.component.scss"],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ExpandableCardsComponent implements OnChanges {
  private cdr = inject(ChangeDetectorRef);

  @Input({ required: true }) cards: ExpandableCardDef[] = [];
  @Input({ required: true }) ctx!: TableCtx;
  @Input() detailRefreshToken: unknown;

  /** Optional: if you want only one card open at a time */
  @Input() accordion = false;

  @Output() expandedChange = new EventEmitter<CardExpandedChange>();

  expanded = new Set<RowKey>();
  private state = new Map<RowKey, LoadState>();
  private data = new Map<RowKey, any>();
  private error = new Map<RowKey, any>();

  ngOnChanges(changes: SimpleChanges): void {
    if (changes["detailRefreshToken"] && !changes["detailRefreshToken"].firstChange) {
      this.clearLoadCache();
      this.reloadExpandedCards();
    }

    if (changes["cards"]) {
      // prune removed ids to avoid stale state after list changes
      const ids = new Set((this.cards ?? []).map((c) => c.id));
      for (const k of Array.from(this.expanded)) if (!ids.has(k)) this.expanded.delete(k);
      for (const k of Array.from(this.state.keys())) if (!ids.has(k)) this.state.delete(k);
      for (const k of Array.from(this.data.keys())) if (!ids.has(k)) this.data.delete(k);
      for (const k of Array.from(this.error.keys())) if (!ids.has(k)) this.error.delete(k);
    }
  }

  isExpanded(id: RowKey): boolean {
    return this.expanded.has(id);
  }

  canExpand(card: ExpandableCardDef): boolean {
    return card.canExpand !== false;
  }

  onAddClick(card: ExpandableCardDef, ev: MouseEvent): void {
    ev.stopPropagation();
    card.addAction?.();
  }

  toggle(card: ExpandableCardDef, ev?: Event): void {
    ev?.stopPropagation();
    if (!this.canExpand(card)) return;

    const id = card.id;

    if (this.accordion) {
      for (const other of Array.from(this.expanded)) {
        if (other !== id) {
          this.expanded.delete(other);
          this.expandedChange.emit({ id: other, expanded: false });
        }
      }
    }

    if (this.expanded.has(id)) {
      this.expanded.delete(id);
      this.expandedChange.emit({ id, expanded: false });
      return;
    }

    this.expanded.add(id);
    this.expandedChange.emit({ id, expanded: true });

    // Lazy load once
    if (card.loadOnExpand && !this.data.has(id) && this.state.get(id) !== "loading") {
      this.state.set(id, "loading");
      card.loadOnExpand(this.ctx).subscribe({
        next: (d) => {
          this.data.set(id, d);
          this.state.set(id, "loaded");
          this.cdr.markForCheck();
        },
        error: (e) => {
          this.error.set(id, e);
          this.state.set(id, "error");
          this.cdr.markForCheck();
        },
      });
    }
  }

  vm(id: RowKey): { state: LoadState; data?: any; error?: any } {
    return {
      state: this.state.get(id) ?? "idle",
      data: this.data.get(id),
      error: this.error.get(id),
    };
  }

  private clearLoadCache(): void {
    this.state.clear();
    // Keep data so card content templates stay alive during reload.
    // Clearing it destroys and recreates nested components, losing their expanded state.
    this.error.clear();
  }

  private reloadExpandedCards(): void {
    const cardsById = new Map((this.cards ?? []).map(card => [card.id, card]));
    for (const id of this.expanded) {
      const card = cardsById.get(id);
      if (!card?.loadOnExpand) continue;

      this.state.set(id, "loading");
      card.loadOnExpand(this.ctx).subscribe({
        next: (d) => {
          this.data.set(id, d);
          this.state.set(id, "loaded");
          this.cdr.markForCheck();
        },
        error: (e) => {
          this.error.set(id, e);
          this.state.set(id, "error");
          this.cdr.markForCheck();
        },
      });
    }
  }
}
