import { TemplateRef } from "@angular/core";
import { Observable } from "rxjs";
import { TableCtx, RowKey } from "../expandable-table/expandable-table.types";

export type CardKey = RowKey;

export type ExpandableCardDef<TData = any> = {
  id: CardKey;
  title: string;

  /** e.g. PV count / Facture count */
  count?: number;

  /** right chevron is always there, but you can disable expanding */
  canExpand?: boolean;

  /** Lazy load on first expand */
  loadOnExpand?: (ctx: TableCtx) => Observable<TData>;

  /** Content template */
  contentTpl: TemplateRef<{ ctx: TableCtx; data?: TData; card?: ExpandableCardDef<TData> }>;

  /** Optional: callback for the + add button shown beside the chevron */
  addAction?: () => void;
};

export type CardExpandedChange = {
  id: CardKey;
  expanded: boolean;
};
