import {
  Component,
  EventEmitter,
  Input,
  OnChanges,
  OnDestroy,
  Output,
  SimpleChanges,
} from '@angular/core';
import { Subscription } from 'rxjs';
import { DocumentDto } from '../../../../services/types/documents.types';
import { DocumentsHttpService } from '../../../../services/documents-http.service';
import { DocumentModalTab } from './documents-modal.types';

@Component({
  selector: 'alexsys-documents-modal',
  standalone: false,
  templateUrl: './documents-modal.component.html',
  styleUrl: './documents-modal.component.scss',
})
export class DocumentsModalComponent implements OnChanges, OnDestroy {

  @Input({ required: true }) visible = false;
  @Output() visibleChange = new EventEmitter<boolean>();

  /** Header title — e.g. "Documents" */
  @Input() title = 'Documents';

  /** Header subtitle — e.g. a ref code */
  @Input() subtitle?: string;

  /** Tab definitions: each tab declares its label and search params. */
  @Input() tabs: DocumentModalTab[] = [];

  // ── Runtime state ────────────────────────────────────────────────────────
  activeTabIndex = 0;
  documents: DocumentDto[] = [];
  loading = false;
  error = '';

  // Per-tab count cache so the badge stays visible when switching tabs
  tabCounts: number[] = [];

  // ── File viewer ──────────────────────────────────────────────────────────
  fileViewerVisible = false;
  fileViewerDocumentId: number | null = null;
  fileViewerFileName = '';
  fileViewerOriginalName = '';

  private subs = new Subscription();

  readonly skeletonRows = [1, 2, 3];

  constructor(private readonly docsHttp: DocumentsHttpService) {}

  // ── Lifecycle ─────────────────────────────────────────────────────────────

  ngOnChanges(changes: SimpleChanges): void {
    const visibleChange = changes['visible'];

    if (visibleChange?.currentValue === true && visibleChange?.previousValue === false) {
      this.activeTabIndex = 0;
      this.tabCounts = [];
      this.loadTab(0);
    } else if (visibleChange?.currentValue === false) {
      this.reset();
    }
  }

  ngOnDestroy(): void {
    this.subs.unsubscribe();
  }

  // ── Tab navigation ────────────────────────────────────────────────────────

  selectTab(index: number): void {
    if (this.activeTabIndex === index) return;
    this.activeTabIndex = index;
    this.loadTab(index);
  }

  // ── Actions ───────────────────────────────────────────────────────────────

  viewDoc(doc: DocumentDto): void {
    this.fileViewerDocumentId = doc.id;
    this.fileViewerFileName   = doc.fileName ?? '';
    this.fileViewerOriginalName = doc.originalName ?? '';
    this.fileViewerVisible    = true;
  }

  downloadDoc(doc: DocumentDto): void {
    this.subs.add(
      this.docsHttp.download(doc.id).subscribe(blob => {
        const url = URL.createObjectURL(blob);
        const a   = document.createElement('a');
        a.href     = url;
        a.download = doc.originalName ?? doc.fileName ?? `document-${doc.id}`;
        a.click();
        URL.revokeObjectURL(url);
      })
    );
  }

  close(): void {
    this.visibleChange.emit(false);
  }

  // ── Formatting helpers ────────────────────────────────────────────────────

  formatSize(bytes: number | null | undefined): string {
    if (!bytes || bytes <= 0) return '';
    if (bytes < 1_024)           return `${bytes} B`;
    if (bytes < 1_024 * 1_024)   return `${(bytes / 1_024).toFixed(1)} Ko`;
    return `${(bytes / (1_024 * 1_024)).toFixed(1)} Mo`;
  }

  formatTypeCode(code: string | null | undefined): string {
    if (!code) return '';
    return code
      .toLowerCase()
      .split('_')
      .map(w => w.charAt(0).toUpperCase() + w.slice(1))
      .join(' ');
  }

  // ── Private ───────────────────────────────────────────────────────────────

  private loadTab(index: number): void {
    const tab = this.tabs[index];
    if (!tab) return;

    this.loading   = true;
    this.error     = '';
    this.documents = [];

    // Cancel any in-flight request
    this.subs.unsubscribe();
    this.subs = new Subscription();

    this.subs.add(
      this.docsHttp.search(tab.query).subscribe({
        next: page => {
          this.documents            = page.content ?? [];
          this.tabCounts[index]     = this.documents.length;
          this.loading              = false;
        },
        error: () => {
          this.error   = 'Impossible de charger les documents.';
          this.loading = false;
        },
      })
    );
  }

  private reset(): void {
    this.documents      = [];
    this.tabCounts      = [];
    this.loading        = false;
    this.error          = '';
    this.activeTabIndex = 0;

    this.fileViewerVisible      = false;
    this.fileViewerDocumentId   = null;
    this.fileViewerFileName     = '';
    this.fileViewerOriginalName = '';

    this.subs.unsubscribe();
    this.subs = new Subscription();
  }
}
