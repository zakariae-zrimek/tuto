export interface DocumentModalTab {
  label: string;
  query: DocumentSearchParams;
}

export interface DocumentSearchParams {
  acteId?: number;
  acteRef?: string;
  receptionId?: number;
  receptionRef?: string;
  categoryCode?: string;
  typeCode?: string;
  entityTypeCode?: string;
  entityId?: number;
  prestataireCode?: string;
}
