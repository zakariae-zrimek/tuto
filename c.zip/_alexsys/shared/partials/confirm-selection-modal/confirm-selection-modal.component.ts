import {
  ChangeDetectionStrategy,
  Component,
  EventEmitter,
  Input,
  Output,
} from "@angular/core";

export type ConfirmTone = "neutral" | "primary" | "warning" | "danger";

@Component({
  selector: "alexsys-confirm-selection-modal",
  standalone: false,
  templateUrl: "./confirm-selection-modal.component.html",
  styleUrls: ["./confirm-selection-modal.component.scss"],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ConfirmSelectionModalComponent {
  @Input() visible = false;
  @Output() visibleChange = new EventEmitter<boolean>();

  // header
  @Input() title = "Confirmation";
  @Input() iconClass = "pi pi-question-circle"; // prime icon class (pi pi-...)
  @Input() tone: ConfirmTone = "primary";

  // body
  @Input() message = "Confirmer cette action ?";
  @Input() highlightLabel?: string; // e.g. "Facture"
  @Input() highlightValue?: string | number; // e.g. "FA-2026-001"

  // buttons
  @Input() confirmText = "Confirmer";
  @Input() cancelText = "Annuler";
  @Input() loading = false;

  // emits when user confirms
  @Output() confirm = new EventEmitter<void>();
  @Output() cancel = new EventEmitter<void>();

  close(): void {
    this.visible = false;
    this.visibleChange.emit(false);
  }

  onCancel(): void {
    if (this.loading) return;
    this.cancel.emit();
    this.close();
  }

  onConfirm(): void {
    if (this.loading) return;
    this.confirm.emit();
  }

  headerClass(): string {
    switch (this.tone) {
      case "danger":
        return "csm__header csm__header--danger";
      case "warning":
        return "csm__header csm__header--warning";
      case "neutral":
        return "csm__header csm__header--neutral";
      default:
        return "csm__header csm__header--primary";
    }
  }

  iconWrapClass(): string {
    switch (this.tone) {
      case "danger":
        return "csm__icon csm__icon--danger";
      case "warning":
        return "csm__icon csm__icon--warning";
      case "neutral":
        return "csm__icon csm__icon--neutral";
      default:
        return "csm__icon csm__icon--primary";
    }
  }
}
