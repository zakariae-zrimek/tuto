import { Component, EventEmitter, Input, OnDestroy, OnInit, Output } from "@angular/core";
import { FormControl, FormGroup } from "@angular/forms";
import { Subscription, debounceTime, distinctUntilChanged } from "rxjs";
import { FilterDef, SelectFilterDef } from "../listing/listing.types";

export interface FilterChip {
  key: string;
  label: string;
  displayValue: string;
}

@Component({
  selector: "alexsys-filter-panel",
  standalone: false,
  templateUrl: "./filter-panel.component.html",
  styleUrls: ["./filter-panel.component.scss"],
})
export class FilterPanelComponent implements OnInit, OnDestroy {
  @Input() title = "Filtres";
  @Input() filters: FilterDef[] = [];
  @Input() initialValue: Record<string, any> = {};

  @Output() valueChange = new EventEmitter<Record<string, any>>();

  form!: FormGroup;
  expanded = true;
  activeChips: FilterChip[] = [];
  private sub = new Subscription();

  private readonly mdCols: Record<number, string> = {
    1: "md:grid-cols-1",
    2: "md:grid-cols-2",
    3: "md:grid-cols-2",
    4: "md:grid-cols-3",
    5: "md:grid-cols-3",
  };

  private readonly lgCols: Record<number, string> = {
    1: "lg:grid-cols-1",
    2: "lg:grid-cols-2",
    3: "lg:grid-cols-3",
    4: "lg:grid-cols-4",
    5: "lg:grid-cols-5",
  };

  get gridClasses(): string[] {
    const n = this.filters?.length ?? 0;
    const cols = n <= 5 ? Math.max(1, n) : Math.min(5, Math.ceil(n / 2));
    return [
      "grid", "grid-cols-1",
      this.mdCols[Math.min(5, cols)],
      this.lgCols[cols],
      "gap-x-4", "gap-y-4", "items-end",
    ];
  }

  get hasActiveFilters(): boolean {
    return this.activeChips.length > 0;
  }

  ngOnInit(): void {
    const group: Record<string, FormControl> = {};
    for (const f of this.filters) {
      if (f.type === 'dateRange') {
        const init = this.initialValue[f.key] ?? {};
        group[f.key + '_from'] = new FormControl(init.from ?? null);
        group[f.key + '_to']   = new FormControl(init.to   ?? null);
      } else {
        group[f.key] = new FormControl(this.initialValue[f.key] ?? null);
      }
    }
    this.form = new FormGroup(group);

    for (const f of this.filters) {
      if (f.type === 'dateRange') {
        const fromCtrl = this.form.get(f.key + '_from') as FormControl;
        const toCtrl   = this.form.get(f.key + '_to')   as FormControl;
        this.sub.add(fromCtrl.valueChanges.pipe(distinctUntilChanged()).subscribe(() => this.emitValue()));
        this.sub.add(toCtrl.valueChanges.pipe(distinctUntilChanged()).subscribe(() => this.emitValue()));
      } else {
        const ctrl = this.form.get(f.key) as FormControl;
        if (f.type === 'search') {
          const ms = f.debounceMs ?? 500;
          this.sub.add(ctrl.valueChanges.pipe(debounceTime(ms), distinctUntilChanged()).subscribe(() => this.emitValue()));
        } else {
          this.sub.add(ctrl.valueChanges.pipe(distinctUntilChanged()).subscribe(() => this.emitValue()));
        }
      }
    }

    this.emitValue();
  }

  toggleExpanded(): void {
    this.expanded = !this.expanded;
  }

  removeChip(key: string, event: Event): void {
    event.stopPropagation();
    const f = this.filters.find(fi => fi.key === key);
    if (!f) return;
    if (f.type === 'dateRange') {
      this.form.get(key + '_from')?.setValue(null);
      this.form.get(key + '_to')?.setValue(null);
    } else {
      this.form.get(key)?.setValue(null);
    }
    this.refreshChips();
  }

  resetFilters(): void {
    if (!this.form) return;
    const empty: Record<string, null> = {};
    for (const f of this.filters) {
      if (f.type === 'dateRange') {
        empty[f.key + '_from'] = null;
        empty[f.key + '_to']   = null;
      } else {
        empty[f.key] = null;
      }
    }
    this.form.patchValue(empty, { emitEvent: true });
    this.form.markAsPristine();
    this.refreshChips();
  }

  private emitValue(): void {
    const raw = this.form.getRawValue() as Record<string, any>;
    const result: Record<string, any> = {};
    for (const f of this.filters) {
      if (f.type === 'dateRange') {
        result[f.key] = {
          from: raw[f.key + '_from'] ?? null,
          to:   raw[f.key + '_to']   ?? null,
        };
      } else {
        result[f.key] = raw[f.key];
      }
    }
    this.refreshChips();
    this.valueChange.emit(result);
  }

  private refreshChips(): void {
    if (!this.form) { this.activeChips = []; return; }
    const chips: FilterChip[] = [];
    const raw = this.form.getRawValue() as Record<string, any>;

    for (const f of this.filters) {
      if (f.type === 'dateRange') {
        const from = raw[f.key + '_from'];
        const to   = raw[f.key + '_to'];
        if (from || to) {
          const fromStr = from ? this.formatDate(from) : '…';
          const toStr   = to   ? this.formatDate(to)   : '…';
          chips.push({ key: f.key, label: f.label, displayValue: `${fromStr} – ${toStr}` });
        }
      } else if (f.type === 'select') {
        const v = raw[f.key];
        if (v !== null && v !== undefined && v !== '') {
          const opt = (f as SelectFilterDef).options.find(o => o.value === v);
          chips.push({ key: f.key, label: f.label, displayValue: opt?.label ?? String(v) });
        }
      } else {
        const v = raw[f.key];
        if (v !== null && v !== undefined && typeof v === 'string' && v.trim().length > 0) {
          chips.push({ key: f.key, label: f.label, displayValue: v });
        }
      }
    }
    this.activeChips = chips;
  }

  private formatDate(d: Date | string): string {
    if (!d) return '';
    const date = d instanceof Date ? d : new Date(d);
    return date.toLocaleDateString('fr-FR', { day: '2-digit', month: '2-digit', year: 'numeric' });
  }

  ngOnDestroy(): void {
    this.sub.unsubscribe();
  }
}
