import {
  Component,
  ContentChildren,
  Input,
  QueryList,
  AfterContentInit,
  Output,
  EventEmitter,
  OnChanges,
  SimpleChanges,
} from "@angular/core";
import { AccordionTabOpenEvent } from "primeng/accordion";
import { AlexsysStepTplDirective } from "../../directives/alexsys-step-tpl.directive";
import { accordionModel } from "../../models/accordion-model";

/**
 * Matches PrimeNG p-accordion value type:
 * - single: string | number
 * - multiple: string[] | number[]
 */
export type AccordionValue = string | number | string[] | number[];
export type AccordionFooterAction = {
  label: string;
  icon?: string;
  variant?: "default" | "destructive" | "outline" | "outline-primary" | "secondary" | "ghost" | "link";
  showWhen?: (tabValue: string | number) => boolean;
  disabledWhen?: (tabValue: string | number) => boolean;
  loadingWhen?: (tabValue: string | number) => boolean;
};


@Component({
  selector: "alexsys-accordion",
  standalone: false,
  templateUrl: "./accordion.component.html",
  styleUrl: "./accordion.component.scss",
})
export class AccordionComponent implements AfterContentInit, OnChanges {
  @Input() tabs: accordionModel[] = [];
  @Input() multiple = false;

  @Input() activeIndex: number | number[] = 0;

  // wrapper two-way binding
  @Input() value: AccordionValue = "1";
  @Output() valueChange = new EventEmitter<AccordionValue>();

  // internal for PrimeNG
  expanded: AccordionValue = "1";

  @ContentChildren(AlexsysStepTplDirective)
  tplQuery!: QueryList<AlexsysStepTplDirective>;

  private stepTplMap = new Map<string, AlexsysStepTplDirective>();

  ngOnChanges(changes: SimpleChanges): void {
    if (changes["value"] || changes["multiple"]) {
      const v = this.value;

      // If multiple mode, PrimeNG expects an array (string[] or number[])
      if (this.multiple) {
        if (Array.isArray(v)) {
          this.expanded = v;
        } else {
          // if user passes single in multiple mode, normalize to array
          this.expanded = typeof v === "number" ? ([v] as number[]) : ([String(v)] as string[]);
        }
      } else {
        // single mode expects scalar
        if (Array.isArray(v)) {
          this.expanded = v[0] ?? "1";
        } else {
          this.expanded = v ?? "1";
        }
      }
    }
  }

  ngAfterContentInit(): void {
    this.stepTplMap.clear();
    this.tplQuery.forEach(t => this.stepTplMap.set(String(t.step), t));
  }

  onExpandedChange(v: AccordionValue): void {
    this.expanded = v;
    this.value = v;
    this.valueChange.emit(v);
  }

  onOpen(event: AccordionTabOpenEvent) {
    this.activeIndex = event.index;
  }

  private currentSingleValue(): string | number | null {
    if (Array.isArray(this.expanded)) return this.expanded[0] ?? null;
    return this.expanded ?? null;
  }

  previous(): void {
    if (this.multiple) return;

    const cur = this.currentSingleValue();
    const i = this.tabs.findIndex(t => t.value === cur);
    if (i > 0) this.onExpandedChange(this.tabs[i - 1].value);
  }

  next(): void {
    if (this.multiple) return;

    const cur = this.currentSingleValue();
    const i = this.tabs.findIndex(t => t.value === cur);
    if (i >= 0 && i < this.tabs.length - 1) this.onExpandedChange(this.tabs[i + 1].value);
  }

  tplFor(stepValue: number | string) {
    return this.stepTplMap.get(String(stepValue))?.tpl;
  }

  @Input() footerAction?: AccordionFooterAction;
  @Output() footerActionClick = new EventEmitter<string | number>();

  showFooterAction(tabValue: string | number): boolean {
    if (!this.footerAction) return false;
    return this.footerAction.showWhen ? this.footerAction.showWhen(tabValue) : true;
  }

  footerActionDisabled(tabValue: string | number): boolean {
    if (!this.footerAction) return true;
    return this.footerAction.disabledWhen ? this.footerAction.disabledWhen(tabValue) : false;
  }

  footerActionLoading(tabValue: string | number): boolean {
    if (!this.footerAction) return false;
    return this.footerAction.loadingWhen ? this.footerAction.loadingWhen(tabValue) : false;
  }

  emitFooterAction(tabValue: string | number): void {
    if (this.footerActionDisabled(tabValue)) return;
    this.footerActionClick.emit(tabValue);
  }

}
