import { Component } from "@angular/core";
import { TranslationService } from "../../../core/i18n";

@Component({
  selector: "alexsys-change-language",
  standalone: false,
  templateUrl: "./change-language.component.html",
  styleUrl: "./change-language.component.scss",
})
export class ChangeLanguageComponent {
  selectedLanguage = "";
  constructor(private translationService: TranslationService) {
    this.selectedLanguage = this.translationService.getSelectedLanguage();
  }
  changeLanguage(event: Event) {
    const lang = (event.target as HTMLSelectElement)?.value;
    if (!lang) {
      return;
    }
    this.selectedLanguage = lang;
    // Call your translation service to change the language
    this.translationService.setLanguage(lang);
  }
}
