import {
  Component,
  AfterContentInit,
  Input,
  Output,
  EventEmitter,
  ContentChildren,
  QueryList,
} from "@angular/core";
import { AlexsysStepTplDirective } from "../../directives/alexsys-step-tpl.directive";
import { stepperModel } from "../../models/stepper-model";

@Component({
  selector: "alexsys-stepper",
  standalone: false,
  templateUrl: "./stepper.component.html",
  styleUrl: "./stepper.component.scss",
})
export class StepperComponent implements AfterContentInit {
  @Input() steps: stepperModel[] = [];
  @Input() currentStep = 1;
  @Input() linear = true;

  @Output() currentStepChange = new EventEmitter<number>();
  @Output() finished = new EventEmitter<void>();

  @ContentChildren(AlexsysStepTplDirective) tplQuery!: QueryList<AlexsysStepTplDirective>;
  stepTplMap = new Map<number | string, AlexsysStepTplDirective>();

  ngAfterContentInit(): void {
    this.tplQuery.forEach(t => this.stepTplMap.set(t.step, t));
  }

  onValueChange(v: number) {
    this.currentStep = v;
    this.currentStepChange.emit(v);
  }

  next() {
    if (this.currentStep < this.steps.length) this.onValueChange(this.currentStep + 1);
  }
  prev() {
    if (this.currentStep > 1) this.onValueChange(this.currentStep - 1);
  }
  complete() {
    this.finished.emit();
  }

  tplFor(stepValue: number | string) {
    return this.stepTplMap.get(stepValue.toString())?.tpl;
  }
}
