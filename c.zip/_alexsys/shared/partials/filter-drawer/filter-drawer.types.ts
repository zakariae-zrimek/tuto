import { SelectOption } from "../listing/listing.types";

type FilterDrawerFieldBase = {
  key: string;
  label: string;
  placeholder?: string;
};

export type FilterDrawerTextField = FilterDrawerFieldBase & {
  type: "text" | "search";
};

export type FilterDrawerSelectField = FilterDrawerFieldBase & {
  type: "select";
  options: SelectOption[];
};

/** Visual section separator — no form control, no value emitted. */
export type FilterDrawerSeparator = {
  type: "separator";
  key: string;
  label: string;
};

export type FilterDrawerField = FilterDrawerTextField | FilterDrawerSelectField | FilterDrawerSeparator;
