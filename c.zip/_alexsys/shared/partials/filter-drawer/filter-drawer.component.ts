import { Component, EventEmitter, Input, OnChanges, OnInit, Output, SimpleChanges } from "@angular/core";
import { FormControl, FormGroup } from "@angular/forms";
import { FilterDrawerField } from "./filter-drawer.types";

@Component({
  selector: "alexsys-filter-drawer",
  standalone: false,
  templateUrl: "./filter-drawer.component.html",
  styleUrls: ["./filter-drawer.component.scss"],
})
export class FilterDrawerComponent implements OnInit, OnChanges {
  @Input() visible = false;
  @Input() title = "Filtres";
  @Input() fields: FilterDrawerField[] = [];
  @Input() value: Record<string, any> = {};

  @Output() visibleChange = new EventEmitter<boolean>();
  @Output() apply = new EventEmitter<Record<string, any>>();
  @Output() reset = new EventEmitter<void>();

  form = new FormGroup({});

  ngOnInit(): void {
    this.rebuildForm();
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes["fields"] && !changes["fields"].firstChange) {
      this.rebuildForm();
      return;
    }

    if (changes["value"] && !changes["value"].firstChange) {
      this.patchFormValue();
    }
  }

  onApply(): void {
    this.apply.emit(this.form.getRawValue());
    this.close();
  }

  onReset(): void {
    const empty: Record<string, null> = {};
    for (const field of this.fields) {
      if (field.type !== "separator") empty[field.key] = null;
    }
    this.form.reset(empty);
    this.reset.emit();
  }

  close(): void {
    this.visibleChange.emit(false);
  }

  private rebuildForm(): void {
    const controls: Record<string, FormControl> = {};
    for (const field of this.fields) {
      if (field.type !== "separator") {
        controls[field.key] = new FormControl(this.value?.[field.key] ?? null);
      }
    }
    this.form = new FormGroup(controls);
  }

  private patchFormValue(): void {
    if (!this.form) {
      return;
    }

    const patch: Record<string, any> = {};
    for (const field of this.fields) {
      if (field.type !== "separator") {
        patch[field.key] = this.value?.[field.key] ?? null;
      }
    }
    this.form.patchValue(patch, { emitEvent: false });
  }
}
