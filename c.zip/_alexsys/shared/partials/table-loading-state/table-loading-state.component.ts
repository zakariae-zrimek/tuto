import { Component, Input } from "@angular/core";

@Component({
  selector: "alexsys-table-loading-state",
  standalone: false,
  templateUrl: "./table-loading-state.component.html",
  styleUrls: ["./table-loading-state.component.scss"],
})
export class TableLoadingStateComponent {
  @Input() label = "Chargement en cours...";
  @Input() iconClass = "pi pi-spin pi-spinner";
}
