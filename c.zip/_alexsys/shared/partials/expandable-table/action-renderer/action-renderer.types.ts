import { ActionDef, MenuItemDef, TableCtx } from "../expandable-table.types";

export type ResolvedAction<T> = ActionDef<T> & {
  _visible: boolean;
  _disabled: boolean;
};

export type ResolvedMenuItem<T> = MenuItemDef<T> & {
  _visible: boolean;
  _disabled: boolean;
};

/** Utility: resolve visibility/disabled flags consistently */
export function resolveActions<T>(
  ctx: TableCtx,
  row: T,
  actions: ActionDef<T>[] = []
): ResolvedAction<T>[] {
  return actions.map(a => ({
    ...a,
    _visible: a.visibleIf ? !!a.visibleIf(ctx, row) : true,
    _disabled: a.disabledIf ? !!a.disabledIf(ctx, row) : false,
  }));
}

export function resolveMenuItems<T>(
  ctx: TableCtx,
  row: T,
  items: MenuItemDef<T>[] = []
): ResolvedMenuItem<T>[] {
  return items.map(i => ({
    ...i,
    _visible: i.visibleIf ? !!i.visibleIf(ctx, row) : true,
    _disabled: i.disabledIf ? !!i.disabledIf(ctx, row) : false,
  }));
}
