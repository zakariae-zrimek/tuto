import {
  ChangeDetectionStrategy,
  Component,
  ElementRef,
  EventEmitter,
  HostListener,
  Input,
  Output,
} from "@angular/core";
import { ActionDef, MenuItemDef, TableCtx } from "../expandable-table.types";
import { resolveActions, resolveMenuItems } from "./action-renderer.types";

@Component({
  selector: "alexsys-action-renderer",
  standalone: false,
  templateUrl: "./action-renderer.component.html",
  styleUrls: ["./action-renderer.component.scss"],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ActionRendererComponent<T> {
  @Input({ required: true }) actions: ActionDef<T>[] = [];
  @Input({ required: true }) row!: T;
  @Input({ required: true }) ctx!: TableCtx;

  /** Render mode: inline row buttons or compact (icons). Parent decides. */
  @Input() density: "normal" | "compact" = "normal";

  @Output() actionClick = new EventEmitter<{ actionId: string; row: T }>();
  @Output() menuItemClick = new EventEmitter<{ itemId: string; row: T }>();

  // menu state (single menu open at a time inside this component instance)
  openMenuActionId: string | null = null;
  menuStyle: Record<string, string> = {};

  constructor(private host: ElementRef<HTMLElement>) {}

  get resolved() {
    return resolveActions(this.ctx, this.row, this.actions).filter((a) => a._visible);
  }

  resolvedMenuItems(action: ActionDef<T>): Array<MenuItemDef<T> & { _visible: boolean; _disabled: boolean }> {
    const items = action.menuItems ?? [];
    return resolveMenuItems(this.ctx, this.row, items).filter((i) => i._visible);
  }

  clickAction(a: ActionDef<T>, ev: MouseEvent): void {
    ev.stopPropagation();
    if (a.disabledIf?.(this.ctx, this.row)) return;
    if (a.kind === "menu") {
      this.toggleMenu(a.id, ev.currentTarget as HTMLElement);
      return;
    }
    this.actionClick.emit({ actionId: a.id, row: this.row });
  }

  clickMenuItem(actionId: string, item: MenuItemDef<T>, ev: MouseEvent): void {
    ev.stopPropagation();
    if (item.disabledIf?.(this.ctx, this.row)) return;

    this.openMenuActionId = null;
    this.menuItemClick.emit({ itemId: item.id, row: this.row });
  }

  toggleMenu(actionId: string, btn?: HTMLElement): void {
    if (this.openMenuActionId === actionId) {
      this.openMenuActionId = null;
      return;
    }
    this.openMenuActionId = actionId;
    if (btn) {
      this.positionMenu(btn);
    }
  }

  private positionMenu(btn: HTMLElement): void {
    const MENU_MAX_HEIGHT_PX = 300;
    const MENU_OFFSET_PX = 6;
    const rect = btn.getBoundingClientRect();
    const right = window.innerWidth - rect.right;

    // Use the nearest .tw wrapper's bottom to account for the pagination footer,
    // so the menu flips above when it would otherwise overlap or clip into the footer.
    const twEl = this.host.nativeElement.closest<HTMLElement>(".tw");
    const containerBottom = twEl
      ? Math.min(twEl.getBoundingClientRect().bottom, window.innerHeight)
      : window.innerHeight;
    const spaceBelow = containerBottom - rect.bottom;

    if (spaceBelow < MENU_MAX_HEIGHT_PX && rect.top > spaceBelow) {
      this.menuStyle = {
        position: "fixed",
        bottom: `${window.innerHeight - rect.top + MENU_OFFSET_PX}px`,
        right: `${right}px`,
      };
    } else {
      this.menuStyle = {
        position: "fixed",
        top: `${rect.bottom + MENU_OFFSET_PX}px`,
        right: `${right}px`,
      };
    }
  }

  closeMenu(): void {
    this.openMenuActionId = null;
  }

  /** Close dropdown when clicking outside */
  @HostListener("document:mousedown", ["$event"])
  onDocMouseDown(ev: MouseEvent) {
    if (!this.openMenuActionId) return;
    const target = ev.target as Node | null;
    if (!target) return;
    if (!this.host.nativeElement.contains(target)) this.closeMenu();
  }

  /** Close dropdown on Escape */
  @HostListener("document:keydown.escape")
  onEscape() {
    if (this.openMenuActionId) this.closeMenu();
  }

  // simple helpers for template
  isDisabled(a: ActionDef<T>): boolean {
    return a.disabledIf ? !!a.disabledIf(this.ctx, this.row) : false;
  }

  actionTooltip(a: ActionDef<T>): string {
    if (typeof a.tooltip === "function") return a.tooltip(this.ctx, this.row);
    return a.tooltip ?? a.label ?? "";
  }

  menuItemTooltip(item: MenuItemDef<T>): string {
    if (typeof item.tooltip === "function") return item.tooltip(this.ctx, this.row);
    return item.tooltip ?? item.label ?? "";
  }

  badgeCount(a: ActionDef<T>): number {
    return a.badge ? a.badge(this.ctx, this.row) : 0;
  }

  toneClass(tone?: ActionDef<T>["tone"]): string {
    switch (tone) {
      case "primary":
        return "tone-primary";
      case "secondary":
        return "tone-secondary";
      case "success":
        return "tone-success";
      case "warning":
        return "tone-warning";
      case "danger":
        return "tone-danger";
      default:
        return "tone-neutral";
    }
  }
}
