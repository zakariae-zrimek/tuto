import {
  ChangeDetectionStrategy,
  ChangeDetectorRef,
  Component,
  EventEmitter,
  Input,
  OnChanges,
  Output,
  SimpleChanges,
  TemplateRef,
} from "@angular/core";
import {
  ExpandableTableConfig,
  PageChange,
  PageState,
  RowKey,
  SortChangeEvent,
  SortState,
  TableActionEvent,
  TableCtx,
  TableMenuActionEvent,
} from "./expandable-table.types";
import { applyVisibilityMap, compareBasic } from "./expandable-table.utils";

type RowLoadState = "idle" | "loading" | "loaded" | "error";

@Component({
  selector: "alexsys-expandable-table",
  standalone: false,
  templateUrl: "./expandable-table.component.html",
  styleUrls: ["./expandable-table.component.scss"],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ExpandableTableComponent<T> implements OnChanges {
  @Input({ required: true }) config!: ExpandableTableConfig<T>;
  @Input({ required: true }) rows: T[] = [];
  @Input({ required: true }) ctx!: TableCtx;
  @Input() loading = false;
  @Input() loadingLabel = "Chargement en cours...";
  @Input() emptyMessage?: string;

  /**
   * Column visibility map for this tableKey/groupKey
   * (parent loads it from TableColumnPrefsService or dialog result)
   */
  @Input() columnVisibility?: Record<string, boolean>;

  /**
   * Server pagination input (optional).
   * - client mode: table ignores total and slices
   * - server mode: parent passes total + pageIndex + pageSize
   */
  @Input() page: PageState = { pageIndex: 0, pageSize: 10 };

  /**
   * Server sorting input (optional).
   * In client mode we manage local sort state.
   * In server mode parent controls sort state and table emits sortChange.
   */
  @Input() sort: SortState | null = null;
  @Input() detailRefreshToken: unknown;
  /** Increment this to mark all cached detail rows as stale — they will reload on next expand */
  @Input() staleToken: unknown;

  @Output() action = new EventEmitter<TableActionEvent<T>>();
  @Output() menuAction = new EventEmitter<TableMenuActionEvent<T>>();
  @Output() sortChange = new EventEmitter<SortChangeEvent>();
  @Output() pageChange = new EventEmitter<PageChange>();
  @Output() cannotExpand = new EventEmitter<T>();

  // expansion state
  expanded = new Set<RowKey>();
  private detailState = new Map<RowKey, RowLoadState>();
  private detailData = new Map<RowKey, any>();
  private detailError = new Map<RowKey, any>();
  private staleKeys = new Set<RowKey>();

  constructor(private readonly cdr: ChangeDetectorRef) {}

  ngOnChanges(changes: SimpleChanges): void {
    if (changes["detailRefreshToken"] && !changes["detailRefreshToken"].firstChange) {
      this.clearDetailCache();
      this.reloadExpandedRows();
    }
    if (changes["staleToken"] && !changes["staleToken"].firstChange) {
      // mark every cached key as stale — will reload on next expand
      for (const key of this.detailData.keys()) {
        this.staleKeys.add(key);
      }
    }
  }

  // -------- Derived --------

  get visibleColumns() {
    return applyVisibilityMap(this.config.columns, this.ctx, this.columnVisibility);
  }

  get showChevron(): boolean {
    return !!this.config.expand?.enabled && (this.config.expand?.showChevron ?? true);
  }

  get hasActions(): boolean {
    return !!(this.config.actions && this.config.actions.length);
  }

  get emptyStateMessage(): string {
    if (this.emptyMessage) return this.emptyMessage;
    const map: Record<string, string> = {
      pvs: "Aucun procès-verbal trouvé.",
      factures: "Aucune facture trouvée.",
      receptions: "Aucune réception trouvée.",
      "gestion-receptions": "Aucune réception trouvée.",
      "actes-achat": "Aucun acte d'achat trouvé.",
      actes: "Aucun acte trouvé.",
      "gestion-prestations": "Aucune prestation trouvée.",
      "signataire-prestations": "Aucune prestation à signer trouvée.",
      "signataire-receptions": "Aucune réception à signer trouvée.",
      sources: "Aucune source trouvée.",
      "demandes-remboursement": "Aucune demande de remboursement trouvée.",
      "mes-demandes-remboursement": "Aucune demande de remboursement trouvée.",
      "attestations-fiscales": "Aucune attestation fiscale trouvée.",
      "attestations-ras": "Aucune attestation RAS trouvée.",
      "attestations-rib": "Aucun RIB trouvé.",
      "attestations-reference": "Aucune attestation de référence trouvée.",
      "attestations-reference-ds": "Aucune attestation de référence trouvée.",
      "attestations-reference-sal": "Aucune attestation de référence trouvée.",
      "autres-documents": "Aucun document trouvé.",
      "tous-documents": "Aucun document trouvé.",
      "decompte-actes": "Aucun décompte trouvé.",
      "decompte-receptions": "Aucune réception de décompte trouvée.",
      "gestion-cautions-actes": "Aucune caution trouvée.",
      "gestion-cautions-final": "Aucune caution trouvée.",
      "gestion-cautions-retenue": "Aucune caution à retenir trouvée.",
      pa_actes: "Aucun acte trouvé.",
      pa_factures: "Aucune facture trouvée.",
      pa_pvs: "Aucun PV trouvé.",
      pa_paiements: "Aucun paiement trouvé.",
      pa_avance_flat: "Aucune avance trouvée.",
      "achat-par-caisse": "Aucun achat par caisse trouvé.",
      "demandes-suppression": "Aucune demande de suppression trouvée.",
      factures_physiques: "Aucune facture physique trouvée.",
      "gestion-ordres-service": "Aucun ordre de service trouvé.",
      prestataires: "Aucun prestataire trouvé.",
      "utilisateurs-prestataires": "Aucun utilisateur prestataire trouvé.",
    };
    const key = this.config?.tableKey ?? "";
    if (map[key]) return map[key];
    if (key.startsWith("reporting-")) return "Aucun résultat trouvé pour ce rapport.";
    if (key.startsWith("documents-prestataire-")) return "Aucun document trouvé.";
    return "Aucune donnée à afficher.";
  }

  get loadingColspan(): number {
    return this.visibleColumns.length + (this.hasActions ? 1 : 0) + (this.showChevron ? 1 : 0);
  }

  get effectiveSort(): SortState | null {
    // if parent passed sort, use it. else fall back to config initial.
    return this.sort ?? this.config.sorting?.initial ?? null;
  }

  get isClientSort(): boolean {
    return !!this.config.sorting?.enabled && this.config.sorting.mode === "client";
  }

  get isServerSort(): boolean {
    return !!this.config.sorting?.enabled && this.config.sorting.mode === "server";
  }

  get isClientPaging(): boolean {
    return !!this.config.pagination?.enabled && this.config.pagination.mode === "client";
  }

  get isServerPaging(): boolean {
    return !!this.config.pagination?.enabled && this.config.pagination.mode === "server";
  }

  get pageSizeOptions(): number[] {
    return this.config.pagination?.pageSizeOptions ?? [10, 20, 50];
  }

  get clientPage(): PageState {
    const initialPageSize = this.config.pagination?.initialPageSize ?? 10;
    return {
      pageIndex: this.page?.pageIndex ?? 0,
      pageSize: this.page?.pageSize ?? initialPageSize,
      total: this.rows.length,
    };
  }

  get displayedRows(): T[] {
    let data = [...(this.rows ?? [])];

    // client sort
    const s = this.effectiveSort;
    if (this.isClientSort && s) {
      const col = this.visibleColumns.find(c => c.id === s.columnId);
      if (col?.sortable) {
        data.sort((ra, rb) => {
          const va = col.value ? col.value(ra, this.ctx) : (ra as any)[col.id];
          const vb = col.value ? col.value(rb, this.ctx) : (rb as any)[col.id];
          return compareBasic(va, vb, s.dir);
        });
      }
    }

    // client paging
    if (this.isClientPaging) {
      const p = this.clientPage;
      const start = p.pageIndex * p.pageSize;
      return data.slice(start, start + p.pageSize);
    }

    return data;
  }

  trackByRow = (_: number, r: T) => this.config.rowKey(r);

  // -------- Row behavior --------

  rowDisabled(row: T): boolean {
    return this.config.rowBehavior?.isDisabled
      ? !!this.config.rowBehavior.isDisabled(this.ctx, row)
      : false;
  }

  //   rowClass(row: T): any {
  //     return this.config.rowBehavior?.rowClass ? this.config.rowBehavior.rowClass(this.ctx, row) : null;
  //   }
  rowClass(row: T): string {
    const v = this.config.rowBehavior?.rowClass
      ? this.config.rowBehavior.rowClass(this.ctx, row)
      : "";
    if (typeof v === "string") return v;
    return "";
  }

  // -------- Expansion --------

  canExpandRow(row: T): boolean {
    if (!this.config.expand?.enabled) return false;
    if (this.rowDisabled(row)) return false;
    const fn = this.config.expand.canExpand;
    return fn ? !!fn(this.ctx, row) : true;
  }

  isExpanded(row: T): boolean {
    return this.expanded.has(this.config.rowKey(row));
  }

  toggleExpand(row: T, ev?: MouseEvent): void {
    ev?.stopPropagation();
    const key = this.config.rowKey(row);
    if (!this.canExpandRow(row)) {
      this.cannotExpand.emit(row);
      return;
    }

    if (this.expanded.has(key)) {
      this.expanded.delete(key);
      // Clear cached detail so re-expanding always fetches fresh data.
      // Safe here because the detail template is no longer rendered.
      this.detailData.delete(key);
      this.detailState.delete(key);
      this.detailError.delete(key);
      this.cdr.markForCheck();
      return;
    }

    this.expanded.add(key);

    // load on first expand, or if marked stale by a notification
    const loader = this.config.expand?.loadOnExpand;
    const isStale = this.staleKeys.has(key);
    if (
      loader &&
      (isStale || !this.detailData.has(key)) &&
      this.detailState.get(key) !== "loading"
    ) {
      this.staleKeys.delete(key);
      this.detailState.set(key, "loading");
      this.cdr.markForCheck();
      loader(this.ctx, row).subscribe({
        next: data => {
          this.detailData.set(key, data);
          this.detailState.set(key, "loaded");
          this.cdr.markForCheck();
        },
        error: err => {
          this.detailError.set(key, err);
          this.detailState.set(key, "error");
          this.cdr.markForCheck();
        },
      });
    } else {
      this.cdr.markForCheck();
    }
  }

  detailTpl(): TemplateRef<any> | null {
    return (this.config.expand?.detailTpl ?? null) as any;
  }

  detailVm(row: T): { data?: any; state: RowLoadState; error?: any } {
    const key = this.config.rowKey(row);
    return {
      data: this.detailData.get(key),
      state: this.detailState.get(key) ?? "idle",
      error: this.detailError.get(key),
    };
  }

  // -------- Actions --------

  onActionClick(ev: { actionId: string; row: T }) {
    this.action.emit(ev);
  }

  onMenuItemClick(ev: { itemId: string; row: T }) {
    this.menuAction.emit({ actionId: ev.itemId, row: ev.row });
  }

  // -------- Sorting --------

  headerClick(colId: string): void {
    if (!this.config.sorting?.enabled) return;
    const col = this.visibleColumns.find(c => c.id === colId);
    if (!col?.sortable) return;

    const prev = this.effectiveSort;
    const next: SortState =
      !prev || prev.columnId !== colId
        ? { columnId: colId, dir: "asc" }
        : prev.dir === "asc"
          ? { columnId: colId, dir: "desc" }
          : { columnId: colId, dir: "asc" };

    if (this.isServerSort) {
      this.sortChange.emit(next);
    } else {
      // client sort: just emit for parent awareness if it wants; also set local via @Input fallback
      this.sortChange.emit(next);
      this.sort = next;
    }
  }

  // -------- Pagination --------

  setPageIndex(pageIndex: number) {
    const pageSize = this.page?.pageSize ?? this.config.pagination?.initialPageSize ?? 10;
    const next = { ...this.page, pageIndex, pageSize };
    this.pageChange.emit(next);
    this.page = next;
  }

  setPageSize(pageSize: number) {
    const next = { ...this.page, pageIndex: 0, pageSize };
    this.pageChange.emit(next);
    this.page = next;
  }

  totalPages(): number {
    const total = this.isServerPaging ? (this.page.total ?? 0) : this.rows.length;
    const size = this.page?.pageSize ?? 10;
    return Math.max(1, Math.ceil(total / size));
  }

  canPrev(): boolean {
    return (this.page?.pageIndex ?? 0) > 0;
  }

  canNext(): boolean {
    return (this.page?.pageIndex ?? 0) < this.totalPages() - 1;
  }

  private clearDetailCache(): void {
    this.detailState.clear();
    // Keep detailData so templates keep rendering the previous data while reloading.
    // Clearing it causes nested components (e.g. sub-tables inside detail templates) to be
    // destroyed and recreated on every refresh, losing their expanded state.
    this.detailError.clear();
    this.cdr.markForCheck();
  }

  private reloadExpandedRows(): void {
    const loader = this.config.expand?.loadOnExpand;
    if (!loader || this.expanded.size === 0) {
      return;
    }

    const rowsByKey = new Map<RowKey, T>(
      (this.rows ?? []).map(row => [this.config.rowKey(row), row])
    );
    for (const key of this.expanded) {
      const row = rowsByKey.get(key);
      if (!row) {
        continue;
      }

      this.detailState.set(key, "loading");
      loader(this.ctx, row).subscribe({
        next: data => {
          this.detailData.set(key, data);
          this.detailState.set(key, "loaded");
          this.cdr.markForCheck();
        },
        error: err => {
          this.detailError.set(key, err);
          this.detailState.set(key, "error");
          this.cdr.markForCheck();
        },
      });
    }
  }
}
