import { ColumnDef, SortDir, SortState, TableCtx } from "./expandable-table.types";

export function isColVisible<T>(col: ColumnDef<T>, ctx: TableCtx): boolean {
  return col.visibleIf ? !!col.visibleIf(ctx) : true;
}

export function applyVisibilityMap<T>(
  cols: ColumnDef<T>[],
  ctx: TableCtx,
  visibilityMap?: Record<string, boolean>
): ColumnDef<T>[] {
  return (cols ?? []).filter((c) => {
    if (!isColVisible(c, ctx)) return false;
    if (!visibilityMap) return true;
    const v = visibilityMap[c.id];
    return typeof v === "boolean" ? v : (c.visibleByDefault ?? true);
  });
}

export function nextSort(prev: SortState | null, columnId: string): SortState {
  if (!prev || prev.columnId !== columnId) return { columnId, dir: "asc" };
  if (prev.dir === "asc") return { columnId, dir: "desc" };
  // third click resets
  return { columnId, dir: "asc" };
}

export function compareBasic(a: any, b: any, dir: SortDir): number {
  // nulls last
  const an = a === null || a === undefined;
  const bn = b === null || b === undefined;
  if (an && bn) return 0;
  if (an) return 1;
  if (bn) return -1;

  // numeric
  if (typeof a === "number" && typeof b === "number") {
    return dir === "asc" ? a - b : b - a;
  }

  // date-like
  const da = a instanceof Date ? a.getTime() : NaN;
  const db = b instanceof Date ? b.getTime() : NaN;
  if (!Number.isNaN(da) && !Number.isNaN(db)) {
    return dir === "asc" ? da - db : db - da;
  }

  // string fallback
  const sa = String(a).toLowerCase();
  const sb = String(b).toLowerCase();
  if (sa < sb) return dir === "asc" ? -1 : 1;
  if (sa > sb) return dir === "asc" ? 1 : -1;
  return 0;
}
