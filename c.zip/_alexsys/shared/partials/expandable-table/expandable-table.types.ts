import { TemplateRef } from "@angular/core";
import { Observable } from "rxjs";

/** Minimal identity type for keys (trackBy, cache keys, etc.) */
export type RowKey = string | number;

/** Sorting */
export type SortDir = "asc" | "desc";
export type SortMode = "client" | "server";

export type SortState = {
    columnId: string;
    dir: SortDir;
};

/** Pagination */
export type PageState = {
    pageIndex: number; // 0-based
    pageSize: number;
    total?: number; // required for server pagination
};

export type TableAppearance = {
    headerClass?: string;
    tableClass?: string;

    // NEW: classes applied to the outer card wrapper
    wrapperClass?: string;

    dense?: boolean;
    striped?: boolean;
    headTextClass?: string;
};

export type PageChange = PageState;

/** Visibility and permissions context passed from parent (role, permissions, etc.) */
export type TableCtx = Record<string, any>;

/** Row style hook return type */
export type RowClass =
    | string
    | string[]
    | Record<string, boolean>
    | null
    | undefined;

/** Column definition */
export type ColumnDef<T> = {
    /** Stable key used for column visibility prefs */
    id: string;

    /** Header label (or already-translated text) */
    header: string;

    /** Optional width (e.g. "140px", "10rem") */
    width?: string;

    /** Align content */
    align?: "left" | "center" | "right";

    /** Enable sorting on this column */
    sortable?: boolean;

    /**
     * For server sorting: what key to send to API.
     * If omitted, defaults to id.
     */
    sortKey?: string;

    /** Default visibility (you want true by default) */
    visibleByDefault?: boolean;

    /** Column-level conditional rendering */
    visibleIf?: (ctx: TableCtx) => boolean;

    /** Simple field accessor (preferred for basic columns) */
    value?: (row: T, ctx: TableCtx) => any;

    /**
     * Advanced cell rendering (chips, icons, nested layout, etc.)
     * Template gets row + ctx.
     */
    cellTpl?: TemplateRef<{ row: T; ctx: TableCtx }>;

    /** Optional formatter on top of value() */
    formatter?: (value: any, row: T, ctx: TableCtx) => string;
};

/** Action renderer types */
export type ActionKind = "icon" | "button" | "menu" | "custom";

export type ActionDef<T> = {
    id: string;
    kind: ActionKind;

    label?: string; // for button or for tooltip
    icon?: string;  // whatever your icon system uses (e.g. "pi pi-ellipsis-v")
    tooltip?: string | ((ctx: TableCtx, row: T) => string);

    /** Visual style mapping to your design system */
    tone?: "primary" | "secondary" | "success" | "warning" | "danger" | "neutral";

    /** Conditional logic */
    visibleIf?: (ctx: TableCtx, row: T) => boolean;
    disabledIf?: (ctx: TableCtx, row: T) => boolean;

    /** For kind="menu" */
    menuItems?: MenuItemDef<T>[];

    /** For kind="custom" */
    tpl?: TemplateRef<{ row: T; ctx: TableCtx }>;

    /** Optional unread/notification badge count — shown as a red pill over the action */
    badge?: (ctx: TableCtx, row: T) => number;
};

export type MenuItemDef<T> = {
    id: string;
    label: string;
    icon?: string;
    tone?: ActionDef<T>["tone"];
    tooltip?: string | ((ctx: TableCtx, row: T) => string);
    visibleIf?: (ctx: TableCtx, row: T) => boolean;
    disabledIf?: (ctx: TableCtx, row: T) => boolean;
    separator?: boolean;
};

/** Expand behavior */
export type ExpandDef<T, DetailData = any> = {
    enabled?: boolean;

    /** show/hide chevron column entirely */
    showChevron?: boolean;

    /** row-level expand eligibility */
    canExpand?: (ctx: TableCtx, row: T) => boolean;

    /**
     * Lazy loader for expansion content.
     * Returned data is cached by rowKey inside the table unless parent changes data source scope.
     */
    loadOnExpand?: (ctx: TableCtx, row: T) => Observable<DetailData>;

    /**
     * Detail row template (receives row, ctx, and optional loaded data)
     * If loadOnExpand is used, template gets data once loaded.
     */
    detailTpl: TemplateRef<{ row: T; ctx: TableCtx; data?: DetailData }>;
};

/** Row behaviors */
export type RowBehaviorDef<T> = {
    /** disable row interactions */
    isDisabled?: (ctx: TableCtx, row: T) => boolean;

    /** custom row classes based on status/role/etc */
    rowClass?: (ctx: TableCtx, row: T) => RowClass;
};

/** Main table config */
export type ExpandableTableConfig<T> = {
    tableKey: string;

    /** Unique key extractor for caching + trackBy */
    rowKey: (row: T) => RowKey;

    columns: ColumnDef<T>[];

    /**
     * Actions shown in an Actions column. If omitted, no actions column.
     * Parent will handle actual click logic via output events.
     */
    actions?: ActionDef<T>[];

    /**
     * Optional: custom actions column header, otherwise "Actions"
     */
    actionsHeader?: string;

    /**
     * Expand behavior
     */
    expand?: ExpandDef<T, any>;

    /**
     * Sorting behavior
     */
    sorting?: {
        enabled: boolean;
        mode: SortMode;
        initial?: SortState;
    };

    /**
     * Pagination behavior.
     * - server: parent controls data/total; table emits pageChange
     * - client: table slices locally
     */
    pagination?: {
        enabled: boolean;
        mode: "client" | "server";
        pageSizeOptions?: number[];
        initialPageSize?: number;
    };

    /**
     * Visual options (your screenshot styling needs header class per table)
     */
    appearance?: TableAppearance;

    /**
     * Row behaviors (disabled + styling)
     */
    rowBehavior?: RowBehaviorDef<T>;
};

/** Events emitted by the table for parent orchestration */
export type TableActionEvent<T> = {
    actionId: string;
    row: T;
};

export type TableMenuActionEvent<T> = {
    actionId: string; // menu item id
    row: T;
};

export type SortChangeEvent = SortState | null;
