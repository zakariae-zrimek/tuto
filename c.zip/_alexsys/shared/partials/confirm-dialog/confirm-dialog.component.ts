import { Component, Input } from "@angular/core";

@Component({
  selector: "alexsys-confirm-dialog",
  standalone: false,
  templateUrl: "./confirm-dialog.component.html",
  styleUrl: "./confirm-dialog.component.scss",
})
export class ConfirmDialogComponent {
  @Input() closable = true;
  @Input() header = "";
  @Input() headerIcon = "pi pi-exclamation-triangle";
  @Input() iconColor = "text-white";
  @Input() acceptLabel = "";
  @Input() rejectLabel = "";
  @Input() withoutCancel = false;
  @Input() reverseButtons = false;
}
