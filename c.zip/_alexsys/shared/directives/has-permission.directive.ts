import {
  Directive,
  Input,
  OnDestroy,
  TemplateRef,
  ViewContainerRef,
  effect,
  inject,
} from "@angular/core";
import { PermissionService } from "../../../services/permission.service";
import { PermissionCode } from "../../../services/types/permissions";

/**
 * Structural directive for permission-based rendering.
 *
 * Usage:
 *   <div *hasPermission="PERM.ACTES_CREER">single code</div>
 *   <div *hasPermission="[PERM.ACTES_CREER, PERM.ACTES_MODIFIER]">any of these</div>
 *
 * Parent permissions cover all children automatically:
 *   User has "EF1" → passes check for "EF1-FCT2", "EF1-FCT2-S1", etc.
 *
 * The view is re-evaluated reactively whenever the user signal changes.
 */
@Directive({ selector: "[hasPermission]", standalone: false })
export class HasPermissionDirective implements OnDestroy {
  @Input("hasPermission") permission!: PermissionCode | string | (PermissionCode | string)[];

  private readonly permSvc = inject(PermissionService);
  private readonly tpl = inject(TemplateRef<unknown>);
  private readonly vcr = inject(ViewContainerRef);

  private rendered = false;
  private readonly cleanupEffect = effect(() => {
    this.update();
  });

  ngOnDestroy(): void {
    this.cleanupEffect.destroy();
  }

  private update(): void {
    const codes = Array.isArray(this.permission) ? this.permission : [this.permission];
    const hasAccess = codes.some(c => this.permSvc.has(c));

    if (hasAccess && !this.rendered) {
      this.vcr.createEmbeddedView(this.tpl);
      this.rendered = true;
    } else if (!hasAccess && this.rendered) {
      this.vcr.clear();
      this.rendered = false;
    }
  }
}
