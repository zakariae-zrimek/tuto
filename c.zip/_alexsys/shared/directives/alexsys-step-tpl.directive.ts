import { Directive, Input, TemplateRef } from "@angular/core";

@Directive({
  selector: "ng-template[alexsysStepperStep]",
  standalone: false,
})
export class AlexsysStepTplDirective {
  @Input("alexsysStepperStep") step!: number | string;
  constructor(public readonly tpl: TemplateRef<unknown>) {}
}
