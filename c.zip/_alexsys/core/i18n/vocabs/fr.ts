export const locale = {
  lang: "fr",
  data: {
    HOME: {
      welcome: "Bienvenue",
    },
  },
};
