import { Locale } from "../translation.service";

export const locale: Locale = {
  lang: "ar",
  data: {
    HOME: {
      welcome: "أهلا بك",
    },
  },
};
