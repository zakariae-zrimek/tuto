import { Locale } from "../translation.service";

export const locale: Locale = {
  lang: "tmz",
  data: {
    HOME: {
      welcome: "ⴰⵣⵓⵍ",
    },
  },
};
