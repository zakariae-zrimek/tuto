import { Injectable } from "@angular/core";
import { TranslateService } from "@ngx-translate/core";

export interface Locale {
  lang: string;
  data: Record<string, unknown>;
}

const LOCALIZATION_LOCAL_STORAGE_KEY = "language";

@Injectable({ providedIn: "root" })
export class TranslationService {
  private readonly langIds = new Set<string>();

  constructor(private readonly translate: TranslateService) {
    this.translate.setDefaultLang("fr");
  }

  loadTranslations(...locales: Locale[]): void {
    locales.forEach(({ lang, data }) => {
      this.translate.setTranslation(lang, data, true);
      this.langIds.add(lang);
    });

    this.translate.addLangs(Array.from(this.langIds));

    const selectedLang = this.getSelectedLanguage();
    this.translate.use(selectedLang);
    this.updateHtmlAttributes(selectedLang);
  }

  setLanguage(lang: string): void {
    if (!lang) return;

    this.translate.use(lang);
    localStorage.setItem(LOCALIZATION_LOCAL_STORAGE_KEY, lang);
    this.updateHtmlAttributes(lang);
  }

  getSelectedLanguage(): string {
    return localStorage.getItem(LOCALIZATION_LOCAL_STORAGE_KEY) ?? this.translate.getDefaultLang();
  }

  private updateHtmlAttributes(lang: string): void {
    const html = document.documentElement;
    html.setAttribute("lang", lang);
    html.setAttribute("dir", lang === "ar" ? "rtl" : "ltr");
  }
}
