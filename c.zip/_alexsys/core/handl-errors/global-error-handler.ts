import { ErrorHandler, Injectable, Injector } from "@angular/core";
import { HttpErrorResponse } from "@angular/common/http";
import { MessageService } from "primeng/api";

@Injectable()
export class GlobalErrorHandler implements ErrorHandler {
  constructor(private readonly injector: Injector) {}

  handleError(error: Error | HttpErrorResponse): void {
    // Chunk load failures happen when the app is still open after a new deployment
    // changes the bundle hashes. Prompt the user to refresh instead of showing a
    // generic error toast.
    if (this.isChunkLoadError(error)) {
      // Auto-reload once on chunk errors (new deployment changed bundle hashes).
      // Guard against infinite reload loops with a session flag.
      const FLAG = "chunk_reload_attempted";
      if (!sessionStorage.getItem(FLAG)) {
        sessionStorage.setItem(FLAG, "1");
        window.location.reload();
        return;
      }
      // Second failure: show the manual message so the user knows what's happening.
      const messageService = this.injector.get(MessageService);
      messageService.add({
        severity: "warn",
        summary: "Mise à jour disponible",
        detail: "Une nouvelle version de l'application est disponible. Veuillez actualiser la page.",
        life: 0,
      });
      return;
    }

    const messageService = this.injector.get(MessageService);

    if (error instanceof HttpErrorResponse) {
      this.handleHttpError(error, messageService);
    } else {
      this.handleClientError(error, messageService);
    }
  }

  private isChunkLoadError(error: Error | HttpErrorResponse): boolean {
    const msg = (error as Error)?.message ?? "";
    return (
      msg.includes("Failed to fetch dynamically imported module") ||
      msg.includes("Importing a module script failed") ||
      msg.includes("ChunkLoadError")
    );
  }

  private handleHttpError(error: HttpErrorResponse, messageService: MessageService): void {
    const detail = error.error?.message || error.message || "Une erreur serveur s'est produite.";
    messageService.add({
      severity: "error",
      summary: `Erreur ${error.status}`,
      detail,
      life: 6000,
    });
  }

  private handleClientError(error: Error, messageService: MessageService): void {
    messageService.add({
      severity: "error",
      summary: "Erreur inattendue",
      detail: error.message || "Une erreur s'est produite dans l'application.",
      life: 6000,
    });
  }
}
