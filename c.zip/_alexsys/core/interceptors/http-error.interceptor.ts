﻿import {
  HttpEvent,
  HttpInterceptor,
  HttpHandler,
  HttpRequest,
  HttpErrorResponse,
} from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Observable, throwError, timer } from "rxjs";
import { catchError, mergeMap, retryWhen } from "rxjs/operators";
import { MessageService } from "primeng/api";
import { SKIP_AUTH, SKIP_ERROR_TOAST } from "../../../modules/auth/services/auth-context";

@Injectable()
export class HttpErrorInterceptor implements HttpInterceptor {
  constructor(private readonly messageService: MessageService) {}

  intercept(req: HttpRequest<unknown>, next: HttpHandler): Observable<HttpEvent<unknown>> {
    const isAuthRefresh = req.url.includes("/auth/auth/refresh");
    const isAuthEndpoint =
      req.context.get(SKIP_AUTH) === true ||
      req.url.includes("/auth/auth/login") ||
      req.url.includes("/prestataire/register") ||
      isAuthRefresh;
    const skipErrorToast = req.context.get(SKIP_ERROR_TOAST);

    const stream = next.handle(req);

    if (isAuthRefresh) {
      return stream.pipe(
        catchError((error: HttpErrorResponse) => {
          if (!isAuthEndpoint && !skipErrorToast) this.handleError(error);
          return throwError(() => error);
        })
      );
    }

    return stream.pipe(
      retryWhen(errors =>
        errors.pipe(
          mergeMap((error: HttpErrorResponse, index) => {
            const attempt = index + 1;
            const retryable = !isAuthEndpoint && (error.status === 0 || error.status >= 500);
            if (!retryable || attempt > 2) {
              return throwError(() => error);
            }
            return timer(200);
          })
        )
      ),
      catchError((error: HttpErrorResponse) => {
        if (!isAuthEndpoint && !skipErrorToast) this.handleError(error);
        return throwError(() => error);
      })
    );
  }

  private handleError(error: HttpErrorResponse): void {
    let summary = "";
    let detail = "";
    const payload: any = error.error;
    const payloadMessage =
      typeof payload?.message === "string" && payload.message.trim()
        ? payload.message.trim()
        : typeof payload?.detail === "string" && payload.detail.trim()
          ? payload.detail.trim()
        : "";

    if (error.status === 0) {
      summary = "Serveur injoignable";
      detail = "Vérifiez votre connexion internet.";
    } else if (error.status >= 500) {
      summary = payloadMessage || "Erreur serveur";
      detail = payloadMessage ? "" : "Réessayez plus tard.";
    } else if (error.status === 401) {
      // Session expiry toast is shown once by AuthService; avoid spamming here.
      return;
    } else {
      // summary must be the top backend message, e.g. "Erreurs de validation métier"
      summary = payloadMessage || `Erreur ${error.status}`;

      // detail should contain the business message(s)
      const detailMsgs = Array.isArray(payload?.details)
        ? payload.details
            .map((d: any) => d?.message)
            .filter((m: any) => typeof m === "string" && m.trim())
        : [];

      if (detailMsgs.length) {
        detail = detailMsgs.join("\n");
      } else if (!payloadMessage && typeof payload === "string" && payload.trim()) {
        detail = payload.trim();
      } else {
        detail = "";
      }
    }

    this.messageService.add({
      severity: "error",
      summary,
      detail,
      life: 8000,
    });
  }
}
