import { Component } from "@angular/core";


@Component({
  selector: "alexsys-layout",
  standalone: false,
  templateUrl: "./layout.component.html",
  styleUrl: "./layout.component.scss",
})
export class LayoutComponent  {
}
