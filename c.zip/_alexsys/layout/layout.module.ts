import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { LayoutComponent } from "./layout.component";
import { ContentComponent } from "./components/content/content.component";
import { HeaderComponent } from "./components/header/header.component";
import { FooterComponent } from "./components/footer/footer.component";
import { SideBarComponent } from "./components/side-bar/side-bar.component";
import { ToolbarComponent } from "./components/toolbar/toolbar.component";
import { TopbarComponent } from "./components/topbar/topbar.component";
import { RouterModule, Routes } from "@angular/router";
import Routing from "../../pages/routing";

import { NotificationsInnerComponent } from "./extras/notifications-inner/notifications-inner.component";
import { UserInnerComponent } from "./extras/user-inner/user-inner.component";
import { ChatDrawerComponent } from "./drawers/chat-drawer/chat-drawer.component";
import { SharedModule } from "../shared/shared.module";
import { ChatInnerComponent } from "./extras/chat-inner/chat-inner.component";
import { UserDrawerComponent } from "./drawers/user-drawer/user-drawer.component";
import { PanelMenuModule } from "primeng/panelmenu";
import { ButtonModule } from "primeng/button";
import { TooltipModule } from "primeng/tooltip";
import { ToastModule } from "primeng/toast";
import { MessageService } from "primeng/api";
import { AsyncPipe } from "@angular/common";
// import { TabViewModule } from "primeng/tabview";

const routes: Routes = [
  {
    path: "",
    component: LayoutComponent,
    children: Routing,
  },
];
@NgModule({
  declarations: [
    LayoutComponent,
    ContentComponent,
    HeaderComponent,
    FooterComponent,
    SideBarComponent,
    ToolbarComponent,
    TopbarComponent,
    NotificationsInnerComponent,
    UserInnerComponent,
    ChatDrawerComponent,
    ChatInnerComponent,
    UserDrawerComponent,
  ],
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    SharedModule,
    PanelMenuModule,
    ButtonModule,
    TooltipModule,
    ToastModule,
    AsyncPipe,
    // TabViewModule,
  ],
  providers: [MessageService],
})
export class LayoutModule {}
