import { Injectable, computed, signal } from "@angular/core";
import { MenuItem } from "primeng/api";
import { UiRole } from "../../../modules/auth/services/auth.service";
import { PermissionService } from "../../../services/permission.service";
import { PERM } from "../../../services/types/permissions";

export interface SidebarItem {
  label: string;
  icon: string;
  path: string;
  role: UiRole;
}

export interface RoleMenuGroup {
  role: UiRole;
  label: string;
  items: SidebarItem[];
}

export const ROLE_LABELS: Record<UiRole, string> = {
  ROLE_CA: "Chargé d'affaires",
  ROLE_SAL: "Service Achats",
  ROLE_SIGNATAIRE: "Signataire",
  ROLE_PRESTATAIRE: "Prestataire",
  ROLE_SBCC: "SAFJ – Comptabilité",
  ROLE_SBC: "SAFJ – Paiement",
  ROLE_CSBC: "CSAFJ",
  ROLE_DFMG: "DAMGL",
  ROLE_DS: "Directeur Support",
  ROLE_SG: "Secrétariat Général",
  ROLE_PRESIDENT: "Président",
  ROLE_ADMIN_FACTURE: "Administration",
};

// ─────────────────────────────────────────────────────────────────────────────
// ROLE MENU ORDER
// Defines the display order of sidebar items per role.
// Must match PageTitlesService route keys exactly.
// Items not listed here fall to the end.
// ─────────────────────────────────────────────────────────────────────────────
const ROLE_MENU_ORDER: Partial<Record<UiRole, string[]>> = {
  ROLE_ADMIN_FACTURE: [
    "/dashboard",
    "/tracabilite-actions",
    "/tracabilite-interne",
    "/admin/utilisateurs",
    "/admin/roles",
    "/gestion-referentiel",
    "/tracabilite-actions",
    "/tracabilite-interne",
    "/admin/rappels",
  ],
  ROLE_SBC: [
    "/dashboard",
    "/traitement-actes",
    "/paiement-avance",
    "/demande-remboursement",
    "/soumettre-demande",
    "/achats-par-caisse",
    "/attestations",
  ],
  ROLE_PRESTATAIRE: [
    "/dashboard",
    "/traitement-actes",
    "/profile",
    "/demande-remboursement",
    "/attestations",
  ],
  ROLE_CA: [
    "/dashboard",
    "/gestion-prestations",
    "/ca-notifications",
    "/ca-historique-actions",
    "/demande-remboursement",
  ],
  ROLE_SAL: [
    "/dashboard",
    "/actes-achat",
    "/gestion-sources",
    "/gestion-ordres-service",
    "/traitement-factures-physiques",
    "/traitement-actes",
    "/gestion-decomptes",
    "/documents",
    "/gestion-cautions",
    "/gestion-prestataires",
    "/achats-par-caisse",
    "/paiement-avance",
    "/reporting",
    // "/tracabilite-actions",
    // "/tracabilite-interne",
    "/demande-remboursement",
  ],
  ROLE_SIGNATAIRE: [
    "/dashboard",
    "/signataire-prestations",
    "/documents",
    "/demande-remboursement",
  ],
  ROLE_DFMG: ["/dashboard", "/demande-remboursement"],
  ROLE_DS: [
    "/dashboard",
    "/traitement-actes",
    "/attestation-de-reference",
    "/gestion-decomptes",
    "/demande-remboursement",
    "/soumettre-demande",
  ],
  ROLE_PRESIDENT: [
    "/dashboard",
    "/traitement-actes",
    "/gestion-decomptes",
    "/demande-remboursement",
    "/soumettre-demande",
  ],
  ROLE_SG: [
    "/dashboard",
    "/traitement-actes",
    "/gestion-decomptes",
    "/demande-remboursement",
    "/soumettre-demande",
    "/gestion-cautions"
  ],
  ROLE_SBCC: [
    "/dashboard",
    "/traitement-actes",
    "/paiement-avance",
    "/demande-remboursement",
    "/attestations",
  ],
  ROLE_CSBC: [
    "/dashboard",
    "/traitement-actes",
    "/attestations",
    "/paiement-avance",
    "/soumettre-demande",
    "/demande-remboursement",
  ],
};

// ─────────────────────────────────────────────────────────────────────────────
// ALL POSSIBLE SIDEBAR ENTRIES
//
// Each entry declares:
//   roles[]    — which UiRoles this link belongs to (mirrors routing.ts data.roles)
//   permission — the EFx-FCTy "voir" code — both role AND permission must pass
//   alwaysShow — show for any authenticated user (Dashboard only)
// ─────────────────────────────────────────────────────────────────────────────
interface NavEntry {
  label: string;
  icon: string;
  path: string;
  roles?: UiRole[]; // which role groups this entry belongs to (mirrors routing.ts data.roles)
  permission?: string; // EFx-FCTy "voir" code — both role AND permission must pass
  alwaysShow?: boolean; // show for any authenticated user (Dashboard only)
}

const ALL_NAV_ENTRIES: NavEntry[] = [
  // Always visible
  { label: "Tableau de bord", icon: "pi pi-home", path: "/dashboard", alwaysShow: true },

  // EF1 — Actes d'Achat
  {
    label: "Gestion des Actes d'Achat",
    icon: "pi pi-shopping-cart",
    path: "/actes-achat",
    roles: ["ROLE_SAL"],
    permission: PERM.ACTES_VOIR,
  },

  // EF2 — Traitement des Actes
  {
    label: "Traitement des dossiers de paiement",
    icon: "pi pi-folder-open",
    path: "/traitement-actes",
    roles: [
      "ROLE_CA",
      "ROLE_SAL",
      "ROLE_PRESTATAIRE",
      "ROLE_SBCC",
      "ROLE_SBC",
      "ROLE_CSBC",
      "ROLE_DS",
      "ROLE_SG",
      "ROLE_PRESIDENT",
    ],
    permission: PERM.TRAITEMENT_VOIR,
  },

  // EF3 — Gestion Prestations (CA)
  {
    label: "Prestations à réceptionner",
    icon: "pi pi-list-check",
    path: "/gestion-prestations",
    roles: ["ROLE_CA"],
    permission: PERM.PRESTATIONS_VOIR,
  },

  // EF4 — Signataire
  {
    label: "Prestations à signer",
    icon: "pi pi-pen-to-square",
    path: "/signataire-prestations",
    roles: ["ROLE_SIGNATAIRE"],
    permission: PERM.SIGNATAIRE_VOIR,
  },

  // EF5 — Cautions
  {
    label: "Gestion des Cautions",
    icon: "pi pi-shield",
    path: "/gestion-cautions",
    roles: ["ROLE_SAL","ROLE_SG"],
    permission: PERM.CAUTIONS_VOIR,
  },

  // EF6 — Attestations
  {
    label: "Attestations",
    icon: "pi pi-verified",
    path: "/attestations",
    roles: ["ROLE_SBCC", "ROLE_CSBC", "ROLE_PRESTATAIRE", "ROLE_SBC"],
    permission: PERM.ATTESTATIONS_VOIR,
  },

  // EF7 — Documents
  {
    label: "Documents",
    icon: "pi pi-folder-open",
    path: "/documents",
    roles: ["ROLE_SAL"],
    permission: PERM.DOCUMENTS_VOIR,
  },

  // EF8 — Achats par Caisse
  {
    label: "Achats par caisse",
    icon: "pi pi-wallet",
    path: "/achats-par-caisse",
    roles: ["ROLE_SAL", "ROLE_SBC"],
    permission: PERM.CAISSE_VOIR,
  },

  // EF9 — Décomptes
  {
    label: "Gestion des décomptes",
    icon: "pi pi-file-check",
    path: "/gestion-decomptes",
    roles: ["ROLE_SAL", "ROLE_PRESTATAIRE", "ROLE_DS", "ROLE_SG", "ROLE_PRESIDENT"],
    permission: PERM.DECOMPTES_VOIR,
  },

  // EF10 — Sources
  {
    label: "Gestion des Sources",
    icon: "pi pi-database",
    path: "/gestion-sources",
    roles: ["ROLE_SAL"],
    permission: PERM.SOURCES_VOIR,
  },

  // EF11 — Factures Physiques
  {
    label: "Traitement facture physique",
    icon: "pi pi-file-edit",
    path: "/traitement-factures-physiques",
    roles: ["ROLE_SAL"],
    permission: PERM.FACT_PHYS_VOIR,
  },

  // EF12 — Paiement Avance
  {
    label: "Paiement à l'avance",
    icon: "pi pi-wallet",
    path: "/paiement-avance",
    roles: ["ROLE_SAL", "ROLE_CA", "ROLE_SBCC", "ROLE_SBC", "ROLE_CSBC"],
    permission: PERM.AVANCE_VOIR,
  },

  // EF13 — "Remboursement" (list + traitement page)
  //
  // Business rule: only the validators (SBC, CSBC, DS) need the list/
  // traitement view. They use it to validate/reject submissions from other
  // users. SG/PRESIDENT can also see it for their part of the signing chain.
  // Everyone else does NOT see this entry — they only have the "Demande de
  // Remboursement" form below to submit, not a list to manage.
  {
    label: "Remboursement",
    icon: "pi pi-credit-card",
    path: "/demande-remboursement",
    roles: [

      "ROLE_SBC",
      "ROLE_CSBC",
      "ROLE_DS",
      // "ROLE_SG",
      // "ROLE_PRESIDENT"


      // "ROLE_SAL",
      // "ROLE_SBC",
      // "ROLE_CSBC",
      // "ROLE_DFMG",
      // "ROLE_SG",
      // "ROLE_CA",
      // "ROLE_DS",
      // "ROLE_SBCC",
      // "ROLE_PRESIDENT",
    ],
    permission: PERM.REMBOURSEMENT_VOIR,
  },

  // EF14 — Gestion Prestataires
  {
    label: "Gestion des Prestataires",
    icon: "pi pi-building",
    path: "/gestion-prestataires",
    roles: ["ROLE_SAL", "ROLE_SBC"],
    permission: PERM.PRESTATAIRES_VOIR,
  },

  // EF15 — Reporting
  {
    label: "Reportings",
    icon: "pi pi-file-check",
    path: "/reporting",
    roles: ["ROLE_SAL"],
    permission: PERM.REPORTING_VOIR,
  },

  // EF16 — Ordres de Service
  {
    label: "Gestion Ordres de Service",
    icon: "pi pi-file-arrow-up",
    path: "/gestion-ordres-service",
    roles: ["ROLE_SAL"],
    permission: PERM.ORDRES_VOIR,
  },

  // EF17 — Notifications CA
  {
    label: "Notifications",
    icon: "pi pi-bell",
    path: "/ca-notifications",
    roles: ["ROLE_CA"],
    permission: PERM.NOTIFS_VOIR,
  },

  // EF18 — Historique Actions CA
  {
    label: "Historique de mes actions",
    icon: "pi pi-history",
    path: "/ca-historique-actions",
    roles: ["ROLE_CA"],
    permission: PERM.HISTORIQUE_VOIR,
  },



  // EF20 — Profil Prestataire
  {
    label: "Profil",
    icon: "pi pi-user",
    path: "/profile",
    roles: ["ROLE_PRESTATAIRE"],
    permission: PERM.PROFIL_VOIR,
  },

  // EF21 — Attestations de Références
  {
    label: "Attestations de référence",
    icon: "pi pi-verified",
    path: "/attestation-de-reference",
    roles: ["ROLE_DS"],
    permission: PERM.ATT_REF_VOIR,
  },

  // EF22 — Soumettre Demande (form route — submitting a new remboursement)
  //
  // Why this is a SEPARATE entry from EF13 "Remboursement":
  //   EF13 (path /demande-remboursement) → the list / history page (read).
  //   EF22 (path /soumettre-demande)     → the submission form (write).
  //   They are distinct routes with different components and different
  //   permission codes, so the same user can have one without the other.
  //   Matches feature/rembourssement-flow: SBC, DS, SG, PRESIDENT, CSBC,
  //   SAL all see both entries; others see only the list.
  {
    label: "Demande de Remboursement",
    icon: "pi pi-send",
    path: "/soumettre-demande",
    // Business rule: any internal user can submit a remboursement. Validators
    // (SBC, CSBC, DS, SG, PRESIDENT) ALSO see this entry alongside the
    // "Remboursement" traitement entry — so they can submit their own
    // demandes in addition to validating others'. PRESTATAIRE is excluded
    // (external users have their own profile flow).
    roles: [
      "ROLE_SAL",
      "ROLE_SBC",
      "ROLE_CSBC",
      "ROLE_DFMG",
      "ROLE_SG",
      "ROLE_CA",
      "ROLE_DS",
      "ROLE_SBCC",
      "ROLE_PRESIDENT",
    ],
    permission: PERM.SOUMETTRE_VOIR,
  },

  // EF23 — Administration
  {
    label: "Gestion Utilisateurs",
    icon: "pi pi-users",
    path: "/admin/utilisateurs",
    roles: ["ROLE_ADMIN_FACTURE"],
    permission: PERM.ADMIN_VOIR,
  },
  // {
  //   label: "Rôles & Permissions",
  //   icon: "pi pi-shield",
  //   path: "/admin/roles",
  //   roles: ["ROLE_ADMIN_FACTURE"],
  //   permission: PERM.ADMIN_VOIR_ROLES,
  // },

  // EF24 — Gestion Référentiel
  {
    label: "Gestion Référentiel",
    icon: "pi pi-database",
    path: "/gestion-referentiel",
    roles: ["ROLE_ADMIN_FACTURE"],
    permission: PERM.REFERENTIEL_VOIR,
  },

  // EF19 — Traçabilité
  {
    label: "Traçabilité Actions",
    icon: "pi pi-history",
    path: "/tracabilite-actions",
    roles: ["ROLE_ADMIN_FACTURE", "ROLE_SAL"],
    permission: PERM.TRACABILITE_AUDIT,
  },
  {
    label: "Journal Interne",
    icon: "pi pi-shield",
    path: "/tracabilite-interne",
    roles: ["ROLE_ADMIN_FACTURE", "ROLE_SAL"],
    permission: PERM.TRACABILITE_INTERNE,
  },

  // EF26 — Gestion des Rappels
  {
    label: "Gestion des Rappels",
    icon: "pi pi-bell",
    path: "/admin/rappels",
    roles: ["ROLE_ADMIN_FACTURE"],
    permission: PERM.RAPPELS_VOIR,
  },
];

@Injectable({ providedIn: "root" })
export class SidebarService {
  private _mobileOpen = signal(false);
  readonly mobileOpen = this._mobileOpen.asReadonly();

  constructor(private readonly permSvc: PermissionService) {}

  toggleMobile(): void {
    this._mobileOpen.update(v => !v);
  }
  closeMobile(): void {
    this._mobileOpen.set(false);
  }

  /**
   * Returns the sidebar items the current user can see,
   * based purely on their permissions[] and roles[].
   * Called with the user’s active roles to handle roleOnly entries.
   */
  getMenuItems(roles: UiRole[]): MenuItem[] {
    return ALL_NAV_ENTRIES.filter(entry => this.isVisible(entry, roles)).map(entry => ({
      label: entry.label,
      icon: entry.icon,
      routerLink: [entry.path],
    }));
  }

  /**
   * Groups visible items by role label for the multi-role sidebar UI.
   * Each role group shows only the items that belong to that role's permission set.
   */
  getMenuGroups(roles: UiRole[]): RoleMenuGroup[] {
    const userPerms = Array.from(this.permSvc.getAll());
    console.log("[Sidebar] getMenuGroups called");
    console.log("[Sidebar] user roles:", roles);
    console.log("[Sidebar] user permissions:", userPerms);

    const groups = roles
      .map(role => {
        const order = ROLE_MENU_ORDER[role] ?? [];

        const items = ALL_NAV_ENTRIES.filter(entry => this.isVisibleDebug(entry, [role]))
          .map(entry => ({ label: entry.label, icon: entry.icon, path: entry.path, role }))
          .sort((a, b) => {
            const ia = order.indexOf(a.path);
            const ib = order.indexOf(b.path);
            return (ia === -1 ? 999 : ia) - (ib === -1 ? 999 : ib);
          });

        console.log(
          `[Sidebar] role=${role} → ${items.length} items:`,
          items.map(i => i.path)
        );
        return { role, label: ROLE_LABELS[role] ?? role, items };
      })
      .filter(g => g.items.length > 0);

    console.log(
      "[Sidebar] final groups:",
      groups.map(g => ({ role: g.role, items: g.items.map(i => i.path) }))
    );
    return groups;
  }

  private isVisibleDebug(entry: NavEntry, roles: UiRole[]): boolean {
    if (entry.alwaysShow) return true;

    if (entry.permission && entry.roles) {
      const hasRole = entry.roles.some(r => roles.includes(r));
      const hasPerm = this.permSvc.has(entry.permission);
      const visible = hasRole && hasPerm;
      if (!visible) {
        console.log(
          `[Sidebar]   HIDE ${entry.path} — hasRole=${hasRole} (need [${entry.roles}]) hasPerm=${hasPerm} (need ${entry.permission})`
        );
      } else {
        console.log(`[Sidebar]   SHOW ${entry.path} — role ✅ perm ${entry.permission} ✅`);
      }
      return visible;
    }

    return false;
  }

  private isVisible(entry: NavEntry, roles: UiRole[]): boolean {
    if (entry.alwaysShow) return true;
    if (entry.permission && entry.roles) {
      const hasRole = entry.roles.some(r => roles.includes(r));
      return hasRole && this.permSvc.has(entry.permission);
    }
    return false;
  }
}
