import { Injectable } from "@angular/core";
import { Observable, of } from "rxjs";
import { UiRole } from "../../../modules/auth/services/auth.service";

// ─────────────────────────────────────────────────────────────────────────────
// PAGE TITLES — kept in sync with ALL_NAV_ENTRIES in sidebar.service.ts
// Key   = exact route path (no trailing slash)
// Value = title shown in the header
// ─────────────────────────────────────────────────────────────────────────────
const TITLES_BY_ROLE: Record<UiRole, Record<string, string>> = {
  ROLE_ADMIN_FACTURE: {
    "/dashboard": "Tableau de bord",
    "/tracabilite-actions": "Traçabilité Actions",
    "/tracabilite-interne": "Journal Interne",
    "/admin": "Administration",
    "/admin/utilisateurs": "Gestion des Utilisateurs",
    "/admin/roles": "Explorateur de rôles",
    "/gestion-referentiel": "Gestion du Référentiel",
  },

  ROLE_SAL: {
    "/dashboard": "Tableau de bord",
    "/actes-achat": "Gestion des Actes d'Achat",
    "/traitement-actes": "Traitement des dossiers de paiement",
    "/gestion-cautions": "Gestion des Cautions",
    "/documents": "Gestion des Documents",
    "/achats-par-caisse": "Achats par Caisse",
    "/gestion-decomptes": "Gestion des Décomptes",
    "/gestion-sources": "Gestion des Sources",
    "/traitement-factures-physiques": "Traitement de la Facture Physique",
    "/paiement-avance": "Paiement à l'Avance",
    "/demande-remboursement": "Demande de Remboursement",
    "/gestion-prestataires": "Gestion des Prestataires",
    "/reporting": "Reporting",
    "/gestion-ordres-service": "Gestion des Ordres de Service",
    // "/tracabilite-actions": "Traçabilité Actions",
    // "/tracabilite-interne": "Journal Interne",
  },

  ROLE_CA: {
    "/dashboard": "Tableau de bord",
    "/traitement-actes": "Traitement des dossiers de paiement",
    "/gestion-prestations": "Prestations à Réceptionner",
    "/paiement-avance": "Paiement à l'Avance",
    "/demande-remboursement": "Demande de Remboursement",
    "/ca-notifications": "Notifications",
    "/ca-historique-actions": "Historique de mes Actions",
  },

  ROLE_SIGNATAIRE: {
    "/dashboard": "Tableau de bord",
    "/signataire-prestations": "Prestations à Signer",
    "/demande-remboursement": "Demande de Remboursement",
  },

  ROLE_PRESTATAIRE: {
    "/dashboard": "Tableau de bord",
    "/actes-achat": "Gestion des Actes d'Achat",
    "/traitement-actes": "Traitement des dossiers de paiement",
    "/attestations": "Attestations",
    "/gestion-decomptes": "Gestion des Décomptes",
    "/demande-remboursement": "Demande de Remboursement",
    "/profile": "Mon Profil",
  },

  ROLE_SBCC: {
    "/dashboard": "Tableau de bord",
    "/traitement-actes": "Traitement des dossiers de paiement",
    "/attestations": "Attestations",
    "/paiement-avance": "Paiement à l'Avance",
    "/demande-remboursement": "Demande de Remboursement",
  },

  ROLE_SBC: {
    "/dashboard": "Tableau de bord",
    "/traitement-actes": "Traitement des dossiers de paiement",
    "/attestations": "Attestations",
    "/achats-par-caisse": "Achats par Caisse",
    "/paiement-avance": "Paiement à l'Avance",
    "/demande-remboursement": "Demande de Remboursement",
    "/gestion-prestataires": "Gestion des Prestataires",
    "/soumettre-demande": "Soumettre une Demande",
  },

  ROLE_CSBC: {
    "/dashboard": "Tableau de bord",
    "/traitement-actes": "Traitement des dossiers de paiement",
    "/attestations": "Attestations",
    "/paiement-avance": "Paiement à l'Avance",
    "/demande-remboursement": "Demande de Remboursement",
  },

  ROLE_DFMG: {
    "/dashboard": "Tableau de bord",
    "/demande-remboursement": "Demande de Remboursement",
  },

  ROLE_DS: {
    "/dashboard": "Tableau de bord",
    "/gestion-decomptes": "Gestion des Décomptes",
    "/demande-remboursement": "Demande de Remboursement",
    "/attestation-de-reference": "Attestations de Référence",
  },

  ROLE_SG: {
    "/dashboard": "Tableau de bord",
    "/gestion-decomptes": "Gestion des Décomptes",
    "/demande-remboursement": "Demande de Remboursement",
  },

  ROLE_PRESIDENT: {
    "/dashboard": "Tableau de bord",
    "/gestion-decomptes": "Gestion des Décomptes",
    "/demande-remboursement": "Demande de Remboursement",
  },
};

@Injectable({ providedIn: "root" })
export class PageTitlesService {
  getTitle(role: UiRole, url: string): Observable<string> {
    const cleanUrl = url.split("?")[0].split("#")[0];
    const title = TITLES_BY_ROLE[role]?.[cleanUrl] ?? "Page";
    return of(title);
  }
}
