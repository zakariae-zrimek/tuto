import { Component, EventEmitter, Input, Output } from "@angular/core";

@Component({
  selector: "alexsys-chat-drawer",
  standalone: false,
  templateUrl: "./chat-drawer.component.html",
  styleUrl: "./chat-drawer.component.scss",
})
export class ChatDrawerComponent {
  @Input() show = false;
  @Output() showChange = new EventEmitter<boolean>();

  onHide() {
    this.showChange.emit(false);
  }
}
