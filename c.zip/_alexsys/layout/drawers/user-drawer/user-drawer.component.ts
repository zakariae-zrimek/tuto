import { Component, Input, OnInit, ViewChild } from "@angular/core";
import { MenuItem } from "primeng/api";
import { Menu } from "primeng/menu";

@Component({
  selector: "alexsys-user-drawer",
  standalone: false,
  templateUrl: "./user-drawer.component.html",
  styleUrl: "./user-drawer.component.scss",
})
export class UserDrawerComponent implements OnInit {
  @ViewChild("userDrawer") userDrawer!: Menu;

  @Input() items: MenuItem[] | undefined = [];
  ngOnInit() {
    this.items = [
      {
        separator: true,
      },

      {
        label: "Profile",
        items: [
          {
            label: "Settings",
            icon: "pi pi-cog",
            shortcut: "⌘+O",
          },
          {
            label: "Messages",
            icon: "pi pi-inbox",
            badge: "2",
          },
          {
            label: "Logout",
            icon: "pi pi-sign-out",
            shortcut: "⌘+Q",
          },
        ],
      },
      {
        separator: true,
      },
    ];
  }

  toggle(event: Event) {
    this.userDrawer.toggle(event);
  }
}
