import { Component, OnDestroy, OnInit, computed, inject } from "@angular/core";
import { MenuItem, MessageService } from "primeng/api";
import { toAbsoluteUrl } from "../../../../_alexsys/helpers/toAbsoluteUrl";
import { PageTitlesService } from "../../services/pageTitles.service";
import { Subscription } from "rxjs";
import { filter } from "rxjs/operators";
import { Router, NavigationEnd } from "@angular/router";
import { AuthService, UiRole } from "../../../../modules/auth/services/auth.service";
import { SidebarService } from "../../services/sidebar.service";
import { NotificationService } from "../../../../services/notification.service";
import { NotificationDto } from "../../../../services/types/notifications.types";
import { RappelHttpService } from "../../../../services/rappel-http.service";

interface EventMeta { icon: string; bg: string; color: string; }

@Component({
  selector: "alexsys-header",
  standalone: false,
  templateUrl: "./header.component.html",
  styleUrl: "./header.component.scss",
})
export class HeaderComponent implements OnInit, OnDestroy {
  pageTitle = "Page";
  public readonly toAbsoluteUrl = toAbsoluteUrl;

  private sidebarService = inject(SidebarService);
  toggleMobileSidebar(): void { this.sidebarService.toggleMobile(); }

  currentUser = computed(() => this.auth.currentUser$());
  role = computed<UiRole | null>(() => this.auth.getActiveRole());

  userMenuItems: MenuItem[] = [
    { label: "Paramètres", icon: "pi pi-cog", command: () => this.openSettings() },
    { separator: true },
    { label: "Déconnexion", icon: "pi pi-sign-out", styleClass: "text-red-600", command: () => this.onLogout() },
  ];

  // ── Notifications ──────────────────────────────────────────────────────────
  notifications: NotificationDto[] = [];
  notifLoading   = false;
  notifPanelOpen = false;

  readonly skeletonItems = [1, 2, 3];

  private sub = new Subscription();

  /** Track which rappel stop is in progress: key = `${entityType}::${entityReference}::${event}` */
  rappelStopInProgress = new Set<string>();

  constructor(
    private router:           Router,
    private pageTitleService: PageTitlesService,
    private auth:             AuthService,
    public  notifService:     NotificationService,
    private messageService:   MessageService,
    private rappelSvc:        RappelHttpService,
  ) {}

  ngOnInit(): void {
    this.updateTitleFromUrl(this.router.url);

    this.sub.add(
      this.router.events
        .pipe(filter((e): e is NavigationEnd => e instanceof NavigationEnd))
        .subscribe(e => this.updateTitleFromUrl(e.urlAfterRedirects))
    );

    // Unlock AudioContext on first user interaction so sound is ready before any notification
    const unlockOnce = (event: Event) => {
      console.log("[Header] 🖱️ First user gesture detected:", event.type, "→ unlockAudio()");
      this.notifService.unlockAudio();
      document.removeEventListener("click",    unlockOnce);
      document.removeEventListener("keydown",  unlockOnce);
      document.removeEventListener("touchend", unlockOnce);
    };
    document.addEventListener("click",    unlockOnce);
    document.addEventListener("keydown",  unlockOnce);
    document.addEventListener("touchend", unlockOnce);

    // Real-time SSE notifications: prepend to list + show toast
    this.sub.add(
      this.notifService.incoming$.subscribe(dto => {
        console.log("[Header] 🔔 incoming$ received in header:", { id: dto.id, title: dto.titleFr });
        this.notifications = [dto, ...this.notifications];

        const time = dto.sentAt
          ? new Date(dto.sentAt).toLocaleTimeString("fr-MA", { hour: "2-digit", minute: "2-digit" })
          : new Date().toLocaleTimeString("fr-MA", { hour: "2-digit", minute: "2-digit" });

        console.log("[Header] 🍞 Calling messageService.add() for toast...");
        this.messageService.add({
          severity: "info",
          summary:  dto.titleFr  || "Nouvelle notification",
          detail:   `${dto.messageFr || ""}\n${time}`,
          life:     8000,
        });
        console.log("[Header] ✅ Toast added");
      })
    );
  }

  // ── Notification panel ─────────────────────────────────────────────────────

  toggleNotifPanel(): void {
    if (this.notifPanelOpen) {
      this.notifPanelOpen = false;
    } else {
      this.notifPanelOpen = true;
      this.loadNotifications();
    }
  }

  closeNotifPanel(): void {
    this.notifPanelOpen = false;
  }

  private loadNotifications(): void {
    this.notifLoading = true;
    this.notifService.loadList(false).subscribe({
      next: list => {
        this.notifications = list;
        this.notifLoading  = false;
        this.notifService.unreadCount$.next(list.filter(n => !n.read).length);
      },
      error: () => { this.notifLoading = false; },
    });
  }

  onMarkRead(notif: NotificationDto): void {
    if (notif.read) return;
    this.notifService.markRead(notif.id).subscribe({
      next: () => {
        notif.read = true;
        this.notifService.unreadCount$.next(
          Math.max(0, this.notifService.unreadCount$.value - 1)
        );
      },
    });
  }

  getEventMeta(eventType: string): EventMeta {
    const e = (eventType ?? "").toUpperCase();
    if (e.includes("SIGNATAIRE"))                           return { icon: "pi pi-pen-to-square", bg: "#ede9fe", color: "#7c3aed" };
    if (e.includes("REJET") || e.includes("REFUSE"))       return { icon: "pi pi-times-circle",  bg: "#fee2e2", color: "#dc2626" };
    if (e.includes("VALIDE") || e.includes("SIGNE") || e.includes("APPROUVE"))
                                                            return { icon: "pi pi-check-circle",  bg: "#dcfce7", color: "#16a34a" };
    if (e.includes("FACTURE"))                              return { icon: "pi pi-file-invoice",  bg: "#fef3c7", color: "#d97706" };
    if (e.includes("PV"))                                   return { icon: "pi pi-file-check",    bg: "#dbeafe", color: "#2563eb" };
    if (e.includes("RECEPTION"))                            return { icon: "pi pi-inbox",          bg: "#e0f2fe", color: "#0284c7" };
    if (e.includes("ACTE") || e.includes("ACHAT"))         return { icon: "pi pi-shopping-cart",  bg: "#ffedd5", color: "#ea580c" };
    return                                                         { icon: "pi pi-bell",           bg: "#f3f4f6", color: "#6b7280" };
  }

  formatDate(dateStr: string): string {
    if (!dateStr) return "";
    const d = new Date(dateStr);
    const diffMins = Math.floor((Date.now() - d.getTime()) / 60000);
    if (diffMins < 1)  return "À l'instant";
    if (diffMins < 60) return `il y a ${diffMins} min`;
    const diffH = Math.floor(diffMins / 60);
    if (diffH < 24)    return `il y a ${diffH} h`;
    const diffD = Math.floor(diffH / 24);
    if (diffD < 7)     return `il y a ${diffD} j`;
    return d.toLocaleDateString("fr-MA");
  }

  // ── Rappel stop ────────────────────────────────────────────────────────────

  getRappelMeta(notif: NotificationDto): { entityType: string; entityReference: string; event: string } | null {
    if (!notif.payloadJson) return null;
    try {
      const p = JSON.parse(notif.payloadJson) as Record<string, unknown>;
      const et  = p["_rappelEntityType"]      as string | undefined;
      const ref = p["_rappelEntityReference"] as string | undefined;
      const ev  = p["_rappelEvent"]           as string | undefined;
      return (et && ref && ev) ? { entityType: et, entityReference: ref, event: ev } : null;
    } catch {
      return null;
    }
  }

  isRappelStopInProgress(notif: NotificationDto): boolean {
    const m = this.getRappelMeta(notif);
    if (!m) return false;
    return this.rappelStopInProgress.has(`${m.entityType}::${m.entityReference}::${m.event}`);
  }

  stopRappel(notif: NotificationDto, domEvent: Event): void {
    domEvent.stopPropagation();
    const m = this.getRappelMeta(notif);
    if (!m) return;
    const key = `${m.entityType}::${m.entityReference}::${m.event}`;
    if (this.rappelStopInProgress.has(key)) return;
    this.rappelStopInProgress.add(key);

    this.rappelSvc.annulerParRef(m.entityType, m.entityReference, m.event).subscribe({
      next: () => {
        this.rappelStopInProgress.delete(key);
        // Mark all matching rappel notifications in the current list as stopped
        this.notifications = this.notifications.map(n => {
          const nm = this.getRappelMeta(n);
          if (nm && nm.entityType === m.entityType && nm.entityReference === m.entityReference && nm.event === m.event) {
            return { ...n, payloadJson: null }; // clear meta so button disappears
          }
          return n;
        });
        this.messageService.add({
          severity: "success",
          summary:  "Rappel arrêté",
          detail:   "Vous ne recevrez plus ce rappel.",
          life:      5000,
        });
      },
      error: () => {
        this.rappelStopInProgress.delete(key);
        this.messageService.add({
          severity: "error",
          summary:  "Erreur",
          detail:   "Impossible d'arrêter le rappel.",
          life:      5000,
        });
      },
    });
  }

  // ── Other ──────────────────────────────────────────────────────────────────

  private updateTitleFromUrl(url: string): void {
    const clean = url.split("?")[0].split("#")[0];
    const role = this.role();
    if (!role) { this.pageTitle = "Page"; return; }
    this.pageTitleService.getTitle(role, clean).subscribe(t => (this.pageTitle = t));
  }

  goBack(): void { this.router.navigateByUrl("/"); }
  openSettings(): void {}
  onLogout(): void { this.auth.logout(); }
  ngOnDestroy(): void { this.sub.unsubscribe(); }
}
