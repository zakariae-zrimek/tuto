import { Component } from "@angular/core";

@Component({
  selector: "alexsys-content",
  standalone: false,
  templateUrl: "./content.component.html",
  styleUrl: "./content.component.scss",
})
export class ContentComponent {}
