import { Component, HostBinding, OnDestroy, OnInit, computed } from "@angular/core";
import { MenuItem } from "primeng/api";
import { Router, NavigationEnd } from "@angular/router";
import { Subscription, filter } from "rxjs";
import { toAbsoluteUrl } from "../../../../_alexsys/helpers/toAbsoluteUrl";
import { RoleMenuGroup, SidebarService } from "../../services/sidebar.service";
import { AuthService, UiRole } from "../../../../modules/auth/services/auth.service";

@Component({
  selector: "alexsys-side-bar",
  templateUrl: "./side-bar.component.html",
  styleUrls: ["./side-bar.component.scss"],
  standalone: false,
})
export class SideBarComponent implements OnInit, OnDestroy {
  public readonly toAbsoluteUrl = toAbsoluteUrl;

  @HostBinding("class.collapsed-host") get hostCollapsed() { return this.isCollapsed; }

  @HostBinding("class.collapsed") isCollapsed = false;
  activeRoute = "";

  get isMobileOpen(): boolean { return this.sidebarService.mobileOpen(); }
  closeMobile(): void { this.sidebarService.closeMobile(); }

  bottomMenuItems: MenuItem[] = [
    // { label: "Aide", icon: "pi pi-question-circle", routerLink: "/help" },
    // { label: "À propos", icon: "pi pi-info-circle", routerLink: "/about" },
  ];

  currentUser = computed(() => this.auth.currentUser$());
  userRoles   = computed(() => this.auth.getUserRoles());
  activeRole  = computed(() => this.auth.getActiveRole());
  roleGroups  = computed<RoleMenuGroup[]>(() => this.sidebarService.getMenuGroups(this.userRoles()));

  private sub = new Subscription();

  constructor(
    private router: Router,
    private sidebarService: SidebarService,
    private auth: AuthService
  ) {}

  ngOnInit(): void {
    this.activeRoute = this.cleanUrl(this.router.url);

    this.sub.add(
      this.router.events
        .pipe(filter((e): e is NavigationEnd => e instanceof NavigationEnd))
        .subscribe(() => {
          this.activeRoute = this.cleanUrl(this.router.url);
          this.sidebarService.closeMobile();
        })
    );
  }

  ngOnDestroy(): void {
    this.sub.unsubscribe();
  }

  toggleCollapse(): void {
    this.isCollapsed = !this.isCollapsed;
  }

  navigateTo(path: string, role: UiRole): void {
    this.auth.setActiveRole(role);
    const targetPath = path.split("?")[0].split("#")[0];
    if (this.activeRoute === targetPath || this.activeRoute.startsWith(targetPath + "/")) {
      // Same URL — Angular ignores navigateByUrl, so force a reload via a detour
      this.router.navigateByUrl("/", { skipLocationChange: true }).then(() => {
        this.router.navigateByUrl(path);
      });
    } else {
      this.router.navigateByUrl(path);
    }
    this.sidebarService.closeMobile();
  }

  isActiveItem(path: string, role: UiRole): boolean {
    const routeMatches = this.activeRoute === path || this.activeRoute.startsWith(path + "/");
    if (this.userRoles().length <= 1) return routeMatches;
    return routeMatches && this.activeRole() === role;
  }

  onLogout(): void {
    this.auth.logout();
  }

  private cleanUrl(url: string): string {
    return url.split("?")[0].split("#")[0];
  }
}
