import { Component } from "@angular/core";

@Component({
  selector: "alexsys-topbar",
  standalone: false,
  templateUrl: "./topbar.component.html",
  styleUrl: "./topbar.component.scss",
})
export class TopbarComponent {}
