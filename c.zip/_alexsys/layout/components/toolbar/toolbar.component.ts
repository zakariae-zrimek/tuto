import { Component } from "@angular/core";

@Component({
  selector: "alexsys-toolbar",
  standalone: false,
  templateUrl: "./toolbar.component.html",
  styleUrl: "./toolbar.component.scss",
})
export class ToolbarComponent {}
