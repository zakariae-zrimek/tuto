import { Component, ViewChild } from "@angular/core";
import { UserDrawerComponent } from "../../drawers/user-drawer/user-drawer.component";

@Component({
  selector: "alexsys-user-inner",
  standalone: false,
  templateUrl: "./user-inner.component.html",
  styleUrl: "./user-inner.component.scss",
})
export class UserInnerComponent {
  @ViewChild("userDrawer") userDrawer!: UserDrawerComponent;

  toggleUserDrawer(event: Event) {
    this.userDrawer.toggle(event);
  }
}
