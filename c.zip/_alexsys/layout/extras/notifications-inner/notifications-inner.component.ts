import { Component } from "@angular/core";

@Component({
  selector: "alexsys-notifications-inner",
  standalone: false,
  templateUrl: "./notifications-inner.component.html",
  styleUrl: "./notifications-inner.component.scss",
})
export class NotificationsInnerComponent {}
