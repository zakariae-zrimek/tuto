import { Component } from "@angular/core";

@Component({
  selector: "alexsys-chat-inner",
  standalone: false,
  templateUrl: "./chat-inner.component.html",
  styleUrl: "./chat-inner.component.scss",
})
export class ChatInnerComponent {
  show = false;
  handleButtonClick() {
    this.show = !this.show;
  }
}
