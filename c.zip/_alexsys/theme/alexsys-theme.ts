import { definePreset } from "@primeng/themes";
import Theme from "@primeng/themes/material";

const AlexsysTheme = definePreset(Theme, {
  semantic: {
    primary: {
      50: "#ebf1f4",
      100: "#d8e2ea",
      200: "#b6c9d7",
      300: "#91aec3",
      400: "#6089a9",
      500: "#0b4a7a",
      600: "#0a416b",
      700: "#08385c",
      800: "#072c49",
      900: "#052137",
      950: "#031625",
    },

    // PrimeNG dark mode token overrides (this is the key)
    colorScheme: {
      light: {
        surface: {
          0: "#ffffff",
          50: "#f8fafc",
          100: "#f1f5f9",
        },
      },
      dark: {
        surface: {
          0: "#0b1220",
          50: "#0f172a",
          100: "#111c33",
        },
      },
    },
  },
});

export default AlexsysTheme;
