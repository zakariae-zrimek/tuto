// theme.service.ts
import { Injectable } from "@angular/core";

@Injectable({ providedIn: "root" })
export class ThemeService {
  private mq = window.matchMedia("(prefers-color-scheme: dark)");

  init() {
    this.apply(this.mq.matches);
    this.mq.addEventListener("change", (e) => this.apply(e.matches));
  }

  setDark(forceDark: boolean) {
    this.apply(forceDark);
  }

  private apply(isDark: boolean) {
    document.documentElement.classList.toggle("dark", isDark);
    document.documentElement.style.colorScheme = isDark ? "dark" : "light";
  }
}
