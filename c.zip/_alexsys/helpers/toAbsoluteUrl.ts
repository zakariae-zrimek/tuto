export function toAbsoluteUrl(relativeUrl: string): string {
  const baseUrl = "";
  return baseUrl + relativeUrl;
}
